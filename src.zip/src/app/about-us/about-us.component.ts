import { Component, OnInit } from '@angular/core';
import { CommonService} from '../services/common.service';
@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.css']
})
export class AboutUsComponent implements OnInit {
  routeFolderName:string;
  appUrl:string;
  constructor() { }

  ngOnInit() {
    this.routeFolderName=CommonService.ROUTING_FOLDER_NAME;
    this.appUrl=CommonService.APP_URL;
  }

}
