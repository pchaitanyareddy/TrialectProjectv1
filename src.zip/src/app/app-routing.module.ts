import { NgModule } from '@angular/core';
import { Routes, RouterModule, Router, NavigationEnd } from '@angular/router';
// import { AuthGuard } from './guards/auth.guard';
import { HomepageComponent } from './homepage/homepage.component';
import { TraineeshipComponent } from './traineeship/traineeship.component';
import { ContactComponent } from './contact/contact.component';
import { ProgramListComponent } from './program-list/program-list.component';
import { ProgramDetailsComponent } from './program-details/program-details.component'
import { ProgramCreationComponent } from './program-creation/program-creation.component'
import {OnlineMentorshipdetailPageComponent} from './online-mentorshipdetail-page/online-mentorshipdetail-page.component'
import {OnlineTraineeshipDetailPageComponent} from './online-traineeship-detail-page/online-traineeship-detail-page.component'
import {OnsiteTraineeshipDetailPageComponent} from './onsite-traineeship-detail-page/onsite-traineeship-detail-page.component'
import {ApplicationProcessComponent} from './application-process/application-process.component'
import {GrantsAndOpportunitiesComponent} from './grants-and-opportunities/grants-and-opportunities.component'
import {WhyToApplyTraineeshipComponent} from './why-to-apply-traineeship/why-to-apply-traineeship.component'
import {WhyToHostTraineeshipComponent} from './why-to-host-traineeship/why-to-host-traineeship.component'
import {AboutUsComponent} from './about-us/about-us.component'
import {CertificationComponent} from './certification/certification.component'
import {DosAndDontsComponent} from './dos-and-donts/dos-and-donts.component'
import {MembersComponent} from './members/members.component'
import{PaymentGatewayComponent} from  './payment-gateway/payment-gateway.component'
import {TermsAndServicesComponent} from './terms-and-services/terms-and-services.component'
import {PrivacyPolicyComponent} from './privacy-policy/privacy-policy.component'
import{ProgramCreationOnsiteTraineeshipComponent} from './program-creation-onsite-traineeship/program-creation-onsite-traineeship.component'
import {ApplicantListComponent} from './applicant-list/applicant-list.component'
import {ProgramDetailBreifComponent} from './program-detail-breif/program-detail-breif.component'
import {OnlineMentorshipCreationComponent} from './online-mentorship-creation/online-mentorship-creation.component'
import {ErrorPageComponent} from './error-page/error-page.component'
import {TraineeshipsComponent} from './traineeships/traineeships.component'
import {ProgramGrantsCreationComponent} from './program-grants-creation/program-grants-creation.component'
import {TemplateNavigationComponent} from './template/template-navigation.component'
import { HowtraineeshipWorksComponent } from './howtraineeship-works/howtraineeship-works.component'
import { from } from 'rxjs';
import { WhyComponent } from './why/why.component';
import { CommonService} from '../app/services/common.service';
const routes: Routes = [
  {path:'',component:HomepageComponent},
  {path:'index',component:HomepageComponent},
  {path:'login',component:HomepageComponent,data: {title: 'Login'}},
  {path:'traineeship',component:TraineeshipComponent,data: {title: 'traineeship'}},
  {path:'traineeships',component:TraineeshipsComponent,data: {title: 'traineeships'}},
  // {path:'how-traineeships-works',component:HowtraineeshipWorksComponent},
  {path:'contact',component:ContactComponent,data: {title: 'contact'}},
  {path:'program-list',component:ProgramListComponent,data: {title: 'Program List'}},
  {path:'program-list/:intrestTypeName/:typeid',component:ProgramListComponent},
  {path:':id/program-details',component:ProgramDetailsComponent,data: {title: 'Program Details'}},
  {path:'program-creation/:id',component:ProgramCreationComponent},
 // {path:':id/program-creation-data',component:ProgramCreationComponent},
  {path:'program-creation-data/:id/:programtypeid',component:ProgramCreationComponent},
  {path:'online-mentorship-detail',component:OnlineMentorshipdetailPageComponent},
  {path:'online-traineeship-detail',component:OnlineTraineeshipDetailPageComponent},
  {path:'onsite-traineeship-detail',component:OnsiteTraineeshipDetailPageComponent},
  {path:'application-process',component:ApplicationProcessComponent},
  {path:'grants-opportunities',component:GrantsAndOpportunitiesComponent},
  {path:'why-to-apply-traineeship',component:WhyToApplyTraineeshipComponent},
  {path:'why-to-host-traineeship',component:WhyToHostTraineeshipComponent},
  {path:'about-us',component:AboutUsComponent},
  {path:'certificate',component:CertificationComponent},
  {path:'dos-donts',component:DosAndDontsComponent},
  {path:'members',component:MembersComponent},
  {path:'payment-gateway',component:PaymentGatewayComponent},
  {path:'terms-services',component:TermsAndServicesComponent},
  {path:'privacy-policy',component:PrivacyPolicyComponent},
  {path:'program-creation-onsite',component:ProgramCreationOnsiteTraineeshipComponent},
  {path:'application-list',component:ApplicantListComponent},
  {path:':id/program-details-brief',component:ProgramDetailBreifComponent},
  {path:':id/program-creation-data',component:ProgramCreationComponent},
  {path:'onlinementorship-creation',component:OnlineMentorshipCreationComponent},
  {path:'program-grants-creation/:id/:programtypeid',component:ProgramGrantsCreationComponent},
  {path: 'why',component:WhyComponent},
  {path: '**',component:ErrorPageComponent},
  
  ];


@NgModule({
  imports: [RouterModule.forRoot(routes,{ useHash: true ,scrollPositionRestoration: 'top'})],
  exports: [RouterModule]
})
export class AppRoutingModule { 
  constructor(private router: Router,
	) {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    router.events.subscribe((val) => {
      if(val instanceof NavigationEnd && val.url.indexOf('/login')>-1)
     setTimeout(() => {
      $('#signIn').click()
     }, 400); 

  });
	}
  
}
