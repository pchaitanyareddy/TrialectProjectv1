import { BrowserModule,Title  } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import * as $ from 'jquery';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ContactComponent } from './contact/contact.component';
import { TraineeshipComponent } from './traineeship/traineeship.component';
import { HomepageComponent } from './homepage/homepage.component';
import { TemplateNavigationComponent } from './template/template-navigation.component';
import { TraineeshipService} from './services/traineeship.service';
import { HttpModule, Http, XHRBackend,RequestOptions } from '@angular/http';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpService } from './services/http.service';
import { ProgramListComponent } from './program-list/program-list.component';
import { ProgramDetailsComponent } from './program-details/program-details.component';
import { Select2Module } from 'ng2-select2';
import { FormsModule, ReactiveFormsModule,FormControl,FormGroup } from '@angular/forms';
import { ProgramCreationComponent } from './program-creation/program-creation.component';
import { MyDatePickerModule } from 'mydatepicker';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { OnlineTraineeshipDetailPageComponent } from './online-traineeship-detail-page/online-traineeship-detail-page.component';
import { OnsiteTraineeshipDetailPageComponent } from './onsite-traineeship-detail-page/onsite-traineeship-detail-page.component';
import { OnlineMentorshipdetailPageComponent } from './online-mentorshipdetail-page/online-mentorshipdetail-page.component';
import { ApplicationProcessComponent } from './application-process/application-process.component';
import { GrantsAndOpportunitiesComponent } from './grants-and-opportunities/grants-and-opportunities.component';
import { WhyToHostTraineeshipComponent } from './why-to-host-traineeship/why-to-host-traineeship.component';
import { WhyToApplyTraineeshipComponent } from './why-to-apply-traineeship/why-to-apply-traineeship.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { MembersComponent } from './members/members.component';
import { PaymentGatewayComponent } from './payment-gateway/payment-gateway.component';
import { CertificationComponent } from './certification/certification.component';
import { TermsAndServicesComponent } from './terms-and-services/terms-and-services.component';
import { DosAndDontsComponent } from './dos-and-donts/dos-and-donts.component';
import { PrivacyPolicyComponent } from './privacy-policy/privacy-policy.component';
import { FooterTemplateNavigationComponent } from './footer-template-navigation/footer-template-navigation.component';
import { ProgramCreationOnsiteTraineeshipComponent } from './program-creation-onsite-traineeship/program-creation-onsite-traineeship.component';
import { ApplicantListComponent } from './applicant-list/applicant-list.component';
import { WhyComponent } from './why/why.component';
import { CKEditorModule } from 'ng2-ckeditor';
import {SelectModule} from 'ng2-select';
import {MyInterceptor} from './services/Interceptor';
import { ProgramDetailBreifComponent } from './program-detail-breif/program-detail-breif.component';
import { NgxGalleryModule } from 'ngx-gallery';
import { OnlineMentorshipCreationComponent } from './online-mentorship-creation/online-mentorship-creation.component';
import {MyAutoSelectComponent} from './shared/my-auto-select/my-auto-select.component'
import { MySelectComponent } from './shared/user-controls/my-select/my-select.component';
import { PriorityWeekSelectComponent } from './shared/user-controls/priority-week-select/priority-week-select.component';
import { ErrorPageComponent } from './error-page/error-page.component';
import { WriteReviewComponent } from './write-review/write-review.component';
import {NgxPaginationModule} from 'ngx-pagination';
import { NgxCaptchaModule } from 'ngx-captcha';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { PrePriorityWeekSelectComponent } from './shared/user-controls/pre-priority-week-select/pre-priority-week-select.component';
import { HowtraineeshipWorksComponent } from './howtraineeship-works/howtraineeship-works.component';
import { TraineeshipsComponent } from './traineeships/traineeships.component';
import { ProgramGrantsCreationComponent } from './program-grants-creation/program-grants-creation.component';
import { ProgramGrantsListComponent } from './program-grants-list/program-grants-list.component';
import { ProgramGrantsDetailComponent } from './program-grants-detail/program-grants-detail.component';
export function httpFactory(xhrBackend: XHRBackend, requestOptions: RequestOptions): Http {
	return new HttpService(xhrBackend, requestOptions);
}
const APP_PROVIDERS = [
  TraineeshipService
  //,
  // {
	// 	provide: Http,
	// 	useFactory: httpFactory,
	// 	deps: [XHRBackend, RequestOptions]
  //   }
];
@NgModule({
  declarations: [
    AppComponent,
    ContactComponent,
    TraineeshipComponent,
    HomepageComponent,
    TemplateNavigationComponent,
    ProgramListComponent,
    ProgramDetailsComponent,
    ProgramCreationComponent,
    OnlineTraineeshipDetailPageComponent,
    OnsiteTraineeshipDetailPageComponent,
    OnlineMentorshipdetailPageComponent,
    ApplicationProcessComponent,
    GrantsAndOpportunitiesComponent,
    WhyToHostTraineeshipComponent,
    WhyToApplyTraineeshipComponent,
    AboutUsComponent,
    MembersComponent,
    PaymentGatewayComponent,
    CertificationComponent,
    TermsAndServicesComponent,
    DosAndDontsComponent,
    PrivacyPolicyComponent,
    FooterTemplateNavigationComponent,
    ProgramCreationOnsiteTraineeshipComponent,
    ApplicantListComponent,
    WhyComponent,
    ProgramDetailBreifComponent,
    OnlineMentorshipCreationComponent,
 
    MySelectComponent,
 
    PriorityWeekSelectComponent,
 
    ErrorPageComponent,
    MyAutoSelectComponent,
 
    WriteReviewComponent,
 
    PrePriorityWeekSelectComponent,
 
    HowtraineeshipWorksComponent,
 
    TraineeshipsComponent,
 
    ProgramGrantsCreationComponent,
 
    ProgramGrantsListComponent,
 
    ProgramGrantsDetailComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpModule,
    HttpClientModule,
    Select2Module,
    FormsModule,
    OwlDateTimeModule,
    OwlNativeDateTimeModule,
    ReactiveFormsModule,
    MyDatePickerModule,
    BrowserAnimationsModule,
    CKEditorModule,
    SelectModule,
    NgxGalleryModule,
    NgxPaginationModule,
    NgxCaptchaModule,
    BsDatepickerModule.forRoot()
  ],
  providers: [APP_PROVIDERS,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: MyInterceptor,
      multi: true
  },Title 
  ],
  bootstrap: [AppComponent]
})


export class AppModule { }
