
export class PaginationModel {
    currentPage: number;
    itemsPerPage: number;
    totalItems: number;
  } 