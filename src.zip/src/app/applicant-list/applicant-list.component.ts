import { Component, OnInit } from '@angular/core';
import { CommonService} from '../services/common.service';
import { TraineeshipService} from '../services/traineeship.service';
import { DomSanitizer } from '@angular/platform-browser';
import * as ProgramModel from './applicant-list-modal';
@Component({
  selector: 'app-applicant-list',
  templateUrl: './applicant-list.component.html',
  styleUrls: ['./applicant-list.component.css']
})
export class ApplicantListComponent implements OnInit {
  appUrl:string;
  errorMessage:any;
  allApplicantList:any;
  PaginationOptions: ProgramModel.PaginationModel = new ProgramModel.PaginationModel();
  PageIndex: number;
  otherdocData:any;
  selectedSorting: string;
  submitApplicantListRequest:any;
  selectedApplicantId:any;
  selectAll:boolean;
  programStatus:string;
  paymentStatus:string;
  loggedInUserRole:string;
  isLoading:boolean;
  submitApplicantSendAllRequest:any;
  resultsFound: number = null;
  results: any;
  submitApplicantStatusRequest:any;
  submitApplicantotherRelaventFilesRequest:any;
  submitApplicantAproveRequest:any;
  constructor(private traineeshipService:TraineeshipService) { }

  ngOnInit() {
    this.selectAll = false;
    this.appUrl= CommonService.APP_URL;
    this.loggedInUserRole=localStorage.getItem("role")
    this.submitApplicantListRequest=
    {
      "program_id":''+localStorage.getItem("programID")+'',
      "username":localStorage.getItem("email"),
      "token":localStorage.getItem("token_Id"),//"3vuamdaytkg0o4w4ooosk400g8kcosk",
      "login_status": localStorage.getItem("status"),
      
    }
    this.PaginationOptions = {
      currentPage: 1,
      itemsPerPage: 5,
      totalItems: 0,
    };
    if (this.PageIndex && this.PageIndex > 0){
      this.PaginationOptions.currentPage = this.PageIndex;
    }

    this.FetchPrograms(this.PaginationOptions.currentPage, this.PaginationOptions.itemsPerPage, true);
// this.applicantDispay();
      
  }

  FetchPrograms(pageIndex: number, pageSize: number, fetchAll: boolean) {

    this.selectedSorting = $("#ddlSorting option:selected").text();
   
   
    if (this.selectedSorting == null || this.selectedSorting == "")
      this.selectedSorting = "all"
    if (this.selectedSorting == "All") {
      this.selectedSorting = "all"
    }
    else if (this.selectedSorting == "Approved") {
      this.selectedSorting = "approved"
    }
    else if (this.selectedSorting == "Completed") {
      this.selectedSorting = "completed"
    }
    else if (this.selectedSorting == "Paid") {
      this.selectedSorting = "paid"
    }
    else if (this.selectedSorting == "Pending") {
      this.selectedSorting = "pending"
    }
    else if (this.selectedSorting == "Scheduled") {
      this.selectedSorting = "scheduled"
    }
    else if (this.selectedSorting == "Partial paid") {
      this.selectedSorting = "partialpaid"
    }
   


    this.submitApplicantListRequest =
      {
        "program_id":''+localStorage.getItem("programID")+'',
      "username":localStorage.getItem("email"),
      "token":localStorage.getItem("token_Id"),//"3vuamdaytkg0o4w4ooosk400g8kcosk",
      "login_status": localStorage.getItem("status"),
      "filter": this.selectedSorting,
        "fetchall": fetchAll,
        "pageindex": pageIndex,
        "pagesize": pageSize,
      }
      this.traineeshipService.applicantList(''+JSON.stringify(this.submitApplicantListRequest)+'').subscribe(
        (response) => {

          if(response.message== "Admin credentials required"){
              alert("Please Login With Admin Credentials")
              return;
          }
          else{
          var count = 0;
            this.allApplicantList=response.dataRows;
            this.allApplicantList.map(a=>{a.otherdoc=""; return a;})
            if (this.allApplicantList && this.allApplicantList.length > 0) {
              this.allApplicantList.forEach(element => {
                count = count + 1;
              });
            }
            this.PaginationOptions.totalItems = response.totalcount;
            this.results = response
            this.resultsFound = this.results.resultcount;
          }
        },
        (err) => {
            this.errorMessage = err;
  
        }); 
       
  }


  public applicantDispay(){
    this.traineeshipService.applicantList(''+JSON.stringify(this.submitApplicantListRequest)+'').subscribe(
      (response) => {
       
          this.allApplicantList=response.dataRows;
          this.allApplicantList.map(a=>{a.otherdoc=""; return a;})
          
      },
      (err) => {
          this.errorMessage = err;

      });
  }
  changeCheckBox(applicantslistData){
 
    let checkAll = true;
    applicantslistData.isSelected = !applicantslistData.isSelected;
    var filteredData = this.allApplicantList.filter(item => {
     if(!item.isSelected){
      this.selectedApplicantId=item.id;
        return item;
     }
    });
    if(filteredData.length!=0){
      this.selectAll = false;
    }else{
      this.selectAll = true;
    }
    var checkedData = this.allApplicantList.filter(item =>item.id)
   
    alert(this.selectedApplicantId)
  }
  statusChange(value){
   
    let applicantId=this.allApplicantList.filter(a=>a.isSelected).map(m=>m.id);
    let selectedUserId=this.allApplicantList.filter(b=>b.isSelected).map(n=>n.user_id)
    let selectedUserName=this.allApplicantList.filter(b=>b.isSelected).map(n=>n.name)
    this.submitApplicantListRequest=
    {
      "id":''+applicantId.join(',')+'',
      "program_id":''+localStorage.getItem("programID")+'',
      "username":localStorage.getItem("email"),
      "token":localStorage.getItem("token_Id"),//"3vuamdaytkg0o4w4ooosk400g8kcosk",
      "login_status": localStorage.getItem("status"),
      "program_status":''+value+'',
      "user_id":''+selectedUserId+''
    }
    if(applicantId==""||applicantId==null){
      $('#programStatusId').val('0: undefined');
      alert("Please select atleast one applicant");
      
    }
    else if((value!=undefined && applicantId!="" )&& applicantId!=null){
      let selectedNamesData=selectedUserName.join(',');
       
        if(confirm("Are you sure want to change program status for following Applicants to "+value+" \n \n"+selectedNamesData.split(",").join("\n"))){
          this.isLoading=true;
        this.traineeshipService.applicantStatus(''+JSON.stringify(this.submitApplicantListRequest)+'').subscribe(
          (response) => {
            this.isLoading=false;
            applicantId="";
            $('#programStatusId').val('0: undefined');
          alert(response.message);
          if (this.PageIndex && this.PageIndex > 0)
            this.PaginationOptions.currentPage = this.PageIndex;

          this.FetchPrograms(this.PaginationOptions.currentPage, this.PaginationOptions.itemsPerPage, true);
          //this.applicantDispay();
            // this.otherdocData=response.dataRows;
              
          },
          (err) => {
            this.isLoading=false;
              this.errorMessage = err;

          });
        
        }
        else{
          this.isLoading=false;
        }
      
      }

  }
  paymentStatusChange(value){

  }
  onChange(id){
    let applicantId=this.allApplicantList.filter(a=>a.isSelected).map(m=>m.id);
    //let selectedUserId=this.allApplicantList.filter(b=>b.isSelected).map(n=>n.user_id)
    
    this.submitApplicantStatusRequest=
    {
      "applicant_id":''+applicantId.join(',')+'',
      "program_id":''+localStorage.getItem("programID")+'',
      "username":localStorage.getItem("email"),
      "token":localStorage.getItem("token_Id"),//"3vuamdaytkg0o4w4ooosk400g8kcosk",
      "login_status": localStorage.getItem("status"),
     
    }

    this.traineeshipService.applicantStatus(''+JSON.stringify(this.submitApplicantStatusRequest)+'').subscribe(
      (response) => {
    
      
       
         // this.otherdocData=response.dataRows;
          
      },
      (err) => {
          this.errorMessage = err;

      });
  }
  selectAllApplicants(event,selectAll){
    this.allApplicantList.forEach(item => {
      item.isSelected = !selectAll;
    });
    
  }
  otherRelavent(rdata){
   
    this.submitApplicantotherRelaventFilesRequest=
    {
      "applicant_id":''+rdata.id+'',
      "program_id":''+localStorage.getItem("programID")+'',
      "username":localStorage.getItem("email"),
      "token":localStorage.getItem("token_Id"),//"3vuamdaytkg0o4w4ooosk400g8kcosk",
      "login_status": localStorage.getItem("status"),
      
    }

      this.traineeshipService.otherRelaventFiles(''+JSON.stringify(this.submitApplicantotherRelaventFilesRequest)+'').subscribe(
        (response) => {
       
          rdata.otherdoc=response.dataRows;
         
           // this.otherdocData=response.dataRows;
            
        },
        (err) => {
            this.errorMessage = err;
  
        });

  }
  ProgramApprove(){
    this.isLoading=true;;

let checkListId=this.allApplicantList.filter(a=>a.isSelected).map(m=>m.id);
let selectedUserId=this.allApplicantList.filter(b=>b.isSelected).map(n=>n.user_id)


if(!checkListId.length){
  this.isLoading=false;
  alert("No ID selected")
}
    this.submitApplicantAproveRequest=
    {
      "applicant_id":''+checkListId.join(',')+'',
      "program_id":''+localStorage.getItem("programID")+'',
      "username":localStorage.getItem("email"),
      "token":localStorage.getItem("token_Id"),//"3vuamdaytkg0o4w4ooosk400g8kcosk",
      "login_status": localStorage.getItem("status"),
      "user_id":''+selectedUserId.join(',')+'',
    }

    this.traineeshipService.applicantAprove(''+JSON.stringify(this.submitApplicantAproveRequest)+'').subscribe(
      (response) => {
        this.isLoading=false;
      alert(response.message)
	   if (this.PageIndex && this.PageIndex > 0)
            this.PaginationOptions.currentPage = this.PageIndex;

        this.FetchPrograms(this.PaginationOptions.currentPage, this.PaginationOptions.itemsPerPage, true);
         // this.otherdocData=response.dataRows;
          
      },
      (err) => {
        this.isLoading=false;
          this.errorMessage = err;

      });
  }
  ProgramSendAll(){
    this.isLoading=true;

    let checkListId=this.allApplicantList.filter(a=>a.isSelected).map(m=>m.id);
    let selectedUserId=this.allApplicantList.filter(b=>b.isSelected).map(n=>n.user_id)
  
    if(!checkListId.length){
      this.isLoading=false;
      alert("No ID selected")
      return
    }
        this.submitApplicantSendAllRequest=
        {
          "applicant_id":''+checkListId.join(',')+'',
          "program_id":''+localStorage.getItem("programID")+'',
          "username":localStorage.getItem("email"),
          "token":localStorage.getItem("token_Id"),//"3vuamdaytkg0o4w4ooosk400g8kcosk",
          "login_status": localStorage.getItem("status"),
          "user_id":''+selectedUserId.join(',')+'',
          
        }
    
        this.traineeshipService.applicantSendAll(''+JSON.stringify(this.submitApplicantSendAllRequest)+'').subscribe(
          (response) => {
            this.isLoading=false;
          alert(response.message)
		   if (this.PageIndex && this.PageIndex > 0)
            this.PaginationOptions.currentPage = this.PageIndex;

            this.FetchPrograms(this.PaginationOptions.currentPage, this.PaginationOptions.itemsPerPage, true);
             // this.otherdocData=response.dataRows;
              
          },
          (err) => {
            this.isLoading=false;
              this.errorMessage = err;
    
          });
      }

      onChange_SortBy(){
        this.selectedSorting = $("#ddlSorting option:selected").text();
        if (this.PageIndex && this.PageIndex > 0)
          this.PaginationOptions.currentPage = this.PageIndex;

          if (this.selectedSorting == null || this.selectedSorting == "")
          this.selectedSorting = "all"
        if (this.selectedSorting == "All") {
          this.selectedSorting = "all"
        }
        else if (this.selectedSorting == "Approved") {
          this.selectedSorting = "approved"
        }
        else if (this.selectedSorting == "Completed") {
          this.selectedSorting = "completed"
        }
        else if (this.selectedSorting == "Paid") {
          this.selectedSorting = "paid"
        }
        else if (this.selectedSorting == "Pending") {
          this.selectedSorting = "pending"
        }
        else if (this.selectedSorting == "Scheduled") {
          this.selectedSorting = "scheduled"
        }
        else if (this.selectedSorting == "Partial paid") {
          this.selectedSorting = "partialpaid"
        }
    this.FetchPrograms(this.PaginationOptions.currentPage, this.PaginationOptions.itemsPerPage, true);
      }
      OnPageChange(page: number): void {
        this.FetchPrograms(page, this.PaginationOptions.itemsPerPage, false);
        this.PaginationOptions.currentPage = page;
      }

}
