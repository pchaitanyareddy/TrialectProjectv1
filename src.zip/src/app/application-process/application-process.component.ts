import { Component, OnInit } from '@angular/core';
import { CommonService} from '../services/common.service';

@Component({
  selector: 'app-application-process',
  templateUrl: './application-process.component.html',
  styleUrls: ['./application-process.component.css']
})
export class ApplicationProcessComponent implements OnInit {

  appUrl:string;
  routeFolderName:string;
  constructor() { }

  ngOnInit() {
    this.appUrl=CommonService.APP_URL;
    this.routeFolderName=CommonService.ROUTING_FOLDER_NAME;

  }

}
