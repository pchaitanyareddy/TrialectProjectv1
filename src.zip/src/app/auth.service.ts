import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
@Injectable()
export class AuthService {
  constructor(private myRoute: Router) { }
  sendToken(token: string) {
    localStorage.setItem("LoggedInUserService", token)
  }
  getToken() {
    return localStorage.getItem("LoggedInUserService")
  }
  isLoggedIn() {
    return this.getToken() !== null;
  }
  logout() {
    //ocalStorage.removeItem("LoggedInUser");
    //this.myRoute.navigate(["Login"]);
  }
}
