import { Component, OnInit } from '@angular/core';
import { CommonService} from '../services/common.service';
@Component({
  selector: 'app-certification',
  templateUrl: './certification.component.html',
  styleUrls: ['./certification.component.css']
})
export class CertificationComponent implements OnInit {
  appUrl:string;
  routeFolderName:string;
  constructor() { }

  ngOnInit() {
    this.appUrl= CommonService.APP_URL;
    this.routeFolderName=CommonService.ROUTING_FOLDER_NAME;

  }

}
