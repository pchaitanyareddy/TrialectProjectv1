import { Component, OnInit,HostListener,ChangeDetectorRef ,ElementRef, ViewChild,Renderer2 } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { CommonService} from '../services/common.service';
import { TraineeshipService} from '../services/traineeship.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  appUrl:string;
  captchaFailureMessage:any;
  contactDetails:any;
  isLoading:boolean;
  contactUsForm:FormGroup;
  errorMessage:any;
submitted = false;
  constructor(private router: Router,private formBuilder: FormBuilder,private traineeshipService:TraineeshipService) { }

  ngOnInit() {
    this.appUrl= CommonService.APP_URL;
    window.scrollTo(0,0);
    this.contactUsForm = this.formBuilder.group({
      contactEmail:['',[Validators.required, Validators.email,Validators.pattern('[a-zA-Z0-9.-]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,4}')]],
			contactName: ['', Validators.required],
			contactSubject: ['', Validators.required],
			contactMessage:['', Validators.required]

		});
  }
  get f() { return this.contactUsForm.controls; }

  submitContactUs(){
    this.isLoading = true;
    this.submitted = true;
   

    this.contactDetails =

			{
        "contactEmail":this.contactUsForm.value.contactEmail,
        "contactName":this.contactUsForm.value.contactName,
        "contactSubject":this.contactUsForm.value.contactSubject,
        "contactMessage":this.contactUsForm.value.contactMessage,
        "username":""+localStorage.getItem("email")+"",
        "token":""+localStorage.getItem("token_Id")+"",
        "login_status":""+localStorage.getItem("status")+"",
			}

		if (this.contactUsForm.invalid) {
      this.isLoading = false;		
      return;	
		
    }
    else  if(!$('#contactSection').html()){
			this.captchaFailureMessage="Please select Captcha";
			return;
    }
		else {
			
			// this.loginService.validateLoginUser('{"username":"santosh.d@smartims.com","password":"FAmYzqi2wVoXIg67aariZETDn+DQwwBpyPNERw+NHOCVkAc0HsAdNAw4N+FO1gF//ZhhHWLulEM5DOXx7hzjlg=="}').subscribe(
			this.traineeshipService.contactUs('' + JSON.stringify(this.contactDetails) + '').subscribe(
				(response) => {
          this.isLoading = false;
          this.contactUsForm.reset();
      alert(response.message);
      this.router.navigate(['/']);
					
				},
				(err) => {
          this.isLoading = false;	
					this.errorMessage = err;
				
		
        });
      }
    
  }

}
