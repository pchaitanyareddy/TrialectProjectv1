import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dos-and-donts',
  templateUrl: './dos-and-donts.component.html',
  styleUrls: ['./dos-and-donts.component.css']
})
export class DosAndDontsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
