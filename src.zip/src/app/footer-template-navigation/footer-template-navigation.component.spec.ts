import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FooterTemplateNavigationComponent } from './footer-template-navigation.component';

describe('FooterTemplateNavigationComponent', () => {
  let component: FooterTemplateNavigationComponent;
  let fixture: ComponentFixture<FooterTemplateNavigationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FooterTemplateNavigationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FooterTemplateNavigationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
