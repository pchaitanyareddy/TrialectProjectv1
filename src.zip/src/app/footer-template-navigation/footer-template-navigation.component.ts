import { Component, OnInit } from '@angular/core';
import { CommonService} from '../services/common.service';
@Component({
  selector: 'footer-template-navigation',
  templateUrl: './footer-template-navigation.component.html',
  styleUrls: ['./footer-template-navigation.component.css']
})
export class FooterTemplateNavigationComponent implements OnInit {
  appUrl:string;
  rootFolderName:string;
  constructor() { }

  ngOnInit() {
    this.appUrl= CommonService.APP_URL;
    this.rootFolderName=CommonService.ROUTING_FOLDER_NAME;
    $("#hide").click(function(){
			$(".faq-div").hide();
		});
		$("#show").click(function(){
      
			$(".faq-div").show();
		});
	
		//Close on click body
	$("#show").click(function () {
			$(".btn-faq").show();
	});
	
	$(document).click(function (e) {
			if (!$(e.target).hasClass("btn-faq") 
					&& $(e.target).parents(".faq").length === 0) 
			{
					$(".faq").hide();
			}
	});
	}
	public ngAfterViewInit(): void{
		$(document).ready(function(){
			$("#close").click(function(){
				$("footer").hide();
			});
			$("#copyright").click(function(){
				$("footer").show();
			});
		});
	}
	exploreTrainee(){
        sessionStorage.setItem('selectedTraineeship','');
        sessionStorage.setItem('programListIsDefault','')
      }

}
