import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GrantsAndOpportunitiesComponent } from './grants-and-opportunities.component';

describe('GrantsAndOpportunitiesComponent', () => {
  let component: GrantsAndOpportunitiesComponent;
  let fixture: ComponentFixture<GrantsAndOpportunitiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GrantsAndOpportunitiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GrantsAndOpportunitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
