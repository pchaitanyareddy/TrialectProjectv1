import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grants-and-opportunities',
  templateUrl: './grants-and-opportunities.component.html',
  styleUrls: ['./grants-and-opportunities.component.css']
})
export class GrantsAndOpportunitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
