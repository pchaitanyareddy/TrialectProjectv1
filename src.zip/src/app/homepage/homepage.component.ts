import { Component, OnInit, ViewChild, HostListener } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap';
import { Router, NavigationEnd } from '@angular/router';
import '../../assets/js/crawler.js';
import { CommonService} from '../services/common.service';
import { TraineeshipService} from '../services/traineeship.service'

var marqueeInit
@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  @ViewChild('loginDetails') public loginModal: ModalDirective; 
  appUrl:string; 
  recentPost:any;
  errorMessage:any;
  userDetails:any;
  ShowModalPopUp:boolean=false;
  loggedInUserRole:string;
  loggedInUserName:string;
  recentReviews:any;
  UserRating:any;
  isLoading:boolean;
  ProgramId:number;
  PrograType:string;
  isAgree: boolean = false;
  checkTerms:boolean=false;
  fieldOfintrestList:any;
  constructor(private traineeshipService:TraineeshipService,private router: Router) { }

  ngOnInit() {
    this.appUrl= CommonService.APP_URL;
    $(window).scrollTop(5);
    (<any>$('#myCarousel')).carousel('pause');
    window.scrollTo(0,0);
    localStorage.setItem("traineeshipTypeonline","")
    localStorage.setItem("traineeshipTypeOnsite","")
    localStorage.setItem("traineeshipTypeOnlineMentor","")
    this.userDetails=		
       {
         "username":""+localStorage.getItem("email")+"",
         "token":""+localStorage.getItem("token_Id")+"",
         "login_status":""+localStorage.getItem("status")+"",
       
       }
       this.getRecentPosts();
    this.getRecentReviews();
    this.getFieldOfIntrestHome();
  }
  
    public ngAfterViewInit(): void {
      this.loggedInUserRole=localStorage.getItem("role")
      this.loggedInUserName=localStorage.getItem("email")
      

      this.userDetails=		
      {
        "username":""+localStorage.getItem("email")+"",
        "token":""+localStorage.getItem("token_Id")+"",
        "login_status":""+localStorage.getItem("status")+"",
      
      }
   

     
    }
    getRecentPosts()
    {
     let userDetails1=		
      {
        "id":"",
        "username":""+localStorage.getItem("email")+"",
        "token":""+localStorage.getItem("token_Id")+"",
        "login_status":""+localStorage.getItem("status")+"",
        "traineeship_type":""
      
      }
      
      this.isLoading = true;
       //this.traineeshipService.getLocations('{"username":"santosh.d@smartims.com"}').subscribe(
        this.traineeshipService.recentPost(''+JSON.stringify(userDetails1)+'').subscribe(
        (response) => {
          this.isLoading = false;
            this.recentPost=response.dataRows;
            
        },
        (err) => {
          this.isLoading = false;
            this.errorMessage = err;
  
        });
  
    }
    getRecentReviews()
    {
      
      this.isLoading = true;
       //this.traineeshipService.getLocations('{"username":"santosh.d@smartims.com"}').subscribe(
        this.traineeshipService.recentReviews(''+JSON.stringify(this.userDetails)+'').subscribe(
        (response) => {
          this.isLoading = false;
            this.recentReviews=response.dataRows;
           
            
        },
        (err) => {
          this.isLoading = false;
            this.errorMessage = err;
  
        });
  
    }
    getFieldOfIntrestHome()
    {
      
      this.isLoading = true;
       //this.traineeshipService.getLocations('{"username":"santosh.d@smartims.com"}').subscribe(
        this.traineeshipService.fieldOfIntrestHome(''+JSON.stringify(this.userDetails)+'').subscribe(
        (response) => {
          this.isLoading = false;
            this.fieldOfintrestList=response.dataRows;
           
            
        },
        (err) => {
          this.isLoading = false;
            this.errorMessage = err;
  
        });
  
    }



    
    onintrestfieldclick(intrestTypeName: any, typeid: number): void {
      // {path:'program-list/:intrestTypeName/:typeid',component:ProgramListComponent},
      // this.router.navigate(['/','program-creation-data'], navigationExtras);
      sessionStorage.setItem('programListIsDefault','FeaturedAreaOfInterest');
      this.router.navigate(['/', 'program-list',  intrestTypeName,typeid])
      //this.router.navigate(['program-creation-data'])
      }
      exploreTrainee(){
        sessionStorage.setItem('selectedTraineeship','');
        sessionStorage.setItem('programListIsDefault','')
      }
      onChangetermsCheckbox($event) {
        this.checkTerms = $event.target.checked;
      }
      readMoreClick(programID, programType) {
        localStorage.setItem("programID", programID);
        localStorage.setItem("programType", programType);
         
          var policy_check: any = localStorage.getItem("policy_check")
          if (policy_check=="yes") {
            this.ShowModalPopUp = false;
            this.router.navigate(['/', localStorage.getItem("programID"), 'program-details'])
          } 
          else{
            // alert("no policy check")
            this.ShowModalPopUp = true;
            // this.router.navigate(['/', localStorage.getItem("programID"), 'program-details'])
          }
            this.ProgramId=programID; 
            this.PrograType=programType
      }
      OnModelClose() {
        this.ShowModalPopUp = false;
      }
      
  OnAgreeSave(item: any): void {
    if (localStorage.getItem("userId")) {
      this.isAgree = item;
      if (item) {

        this.traineeshipService.agreesavepost('' + JSON.stringify(this.getAgreeUserJsonData()) + '').subscribe(
          (response) => {
            // alert(response.message)
            if (response.message == "Successfully updated") {
              this.ShowModalPopUp = false;
              localStorage.setItem("policy_check", 'yes')
              //program-details page
              this.router.navigate(['/',this.ProgramId , 'program-details'])
            }
            
          });
      }
    }
    else{
      //  alert("else on Agreesave")
        //program-details brief page
    // this.router.navigate(['/',this.ProgramId , 'program-details-brief'])
    this.router.navigate(['/',this.ProgramId , 'program-details'])
    }
  }
  
  getAgreeUserJsonData(): any {
    var atext = "";
    if (this.isAgree) {
      atext = "yes"
    } else {
      atext = "no"
    }
    this.userDetails =
      {
        "user_id": localStorage.getItem("userId"),
        "username": "" + localStorage.getItem("email") + "",
        "token": "" + localStorage.getItem("token_Id") + "",
        "login_status": "" + localStorage.getItem("status") + "",

        "policy_check": "" + atext + "",
      }
    return this.userDetails;
  }

  exploreTraineeship(type){
    if(type)
			sessionStorage.setItem("selectedTraineeship",type);
		else
		sessionStorage.setItem("selectedTraineeship",'');
   
    
 
  }
}
