import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HowtraineeshipWorksComponent } from './howtraineeship-works.component';

describe('HowtraineeshipWorksComponent', () => {
  let component: HowtraineeshipWorksComponent;
  let fixture: ComponentFixture<HowtraineeshipWorksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HowtraineeshipWorksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HowtraineeshipWorksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
