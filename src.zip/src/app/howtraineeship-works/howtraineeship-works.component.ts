import { Component, OnInit } from '@angular/core';
import { CommonService} from '../services/common.service';
@Component({
  selector: 'app-howtraineeship-works',
  templateUrl: './howtraineeship-works.component.html',
  styleUrls: ['./howtraineeship-works.component.css']
})
export class HowtraineeshipWorksComponent implements OnInit {
  appUrl:string; 
  constructor() { }

  ngOnInit() {
    this.appUrl= CommonService.APP_URL;
  }

}
