import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnlineMentorshipCreationComponent } from './online-mentorship-creation.component';

describe('OnlineMentorshipCreationComponent', () => {
  let component: OnlineMentorshipCreationComponent;
  let fixture: ComponentFixture<OnlineMentorshipCreationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnlineMentorshipCreationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnlineMentorshipCreationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
