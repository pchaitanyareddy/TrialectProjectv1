import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit,ChangeDetectionStrategy ,ChangeDetectorRef,ViewChild} from '@angular/core';
import { IMyInputFieldChanged, IMyOptions } from 'mydatepicker';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { CommonService} from '../services/common.service';
import {TraineeshipService} from '../services/traineeship.service';
import {Select2OptionData} from 'ng2-select2';
import { from } from 'rxjs';
export class questionModal {
  question: string="";
  answer:string="";
  category:string="general";
  qa_id:string="";
}
export class careermodel {
  career_id: string="";
  career:string="";
  cr_id:string="";
}
export class prefferedmodel {
  startDatePreferred: string="";
  endDatePreferred:string="";
  
};

@Component({
  selector: 'app-online-mentorship-creation',
  templateUrl: './online-mentorship-creation.component.html',
  styleUrls: ['./online-mentorship-creation.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class OnlineMentorshipCreationComponent implements OnInit {

  appUrl:string;
  public exampleData: Array<Select2OptionData>;
  public options: Select2Options;
  public value: any;
  urls = [];
  fileNames=[];
  urlsForLogo= [];
  word: string;
  name = 'ng2-ckeditor';
  ckeConfig: any;
  mycontent: string;
  log: string = '';
  submitCreationRequest:any;
  errorMessage:any;
  pNamemsg:any;
  allCreationList:any;
  certification_type:string;
  certification:any;
  typeOfProgram:string;
  selectedCountry:string;
  userDetails:any;
  countryList:any;
  careerLevelList:any;
  careerSelected:string;
  selectedCountryId:number;
  public current: string;
  public current1: string;
  @ViewChild("myckeditor") ckeditor: any;
  public uploadImage = '';
	public uploadImageBase64: string;
  public creationstep1: FormGroup;
  submitted = false;
  public questionsList:FormArray;
  public questionArray: questionModal[]=[];
  public preferredSlotArray:prefferedmodel[]=[];
  public careerArray: careermodel[]=[];
  public program_carrers:[]=[];
constructor(
  private fb: FormBuilder,
  private traineeshipService:TraineeshipService,
  private changeDetectorRef: ChangeDetectorRef,private router: Router,
  private route: ActivatedRoute){
    let s = new questionModal();
  
    this.questionArray.push(s);
    let c=new careermodel();
  
    let preferDate = new prefferedmodel();
    this.preferredSlotArray.push(preferDate)
  
  }
  get questionsFormGroup() {
    return this.creationstep1.get('questions') as FormArray;
  }
 
    ngOnInit() {
      this.appUrl= CommonService.APP_URL;
      this.ckeConfig = {
        allowedContent: false,
        extraPlugins: 'divarea',
        forcePasteAsPlainText: true,
        removePlugins: 'horizontalrule,about',
        removeButtons: 'Save,NewPage,Preview,Print,Templates,ImageButton,Replace,SelectAll,Subscript,Superscript,Form,Checkbox,Radio,TextField,Textarea,Find,Select,Button,HiddenField,CopyFormatting,CreateDiv,BidiLtr,BidiRtl,Language,Flash,Smiley,PageBreak,Iframe,TextColor,BGColor,ShowBlocks,Cut,Copy,Paste,Table,Format,Source,Maximize,Anchor,SpecialChar,PasteFromWord,PasteText,Scayt,Undo,Redo,Strike,RemoveFormat,Blockquote'
      };
      this.creationstep1 = this.fb.group({
        programName: ['', Validators.required],
        uploadImage:['',Validators.required],
        briefDescription:['',Validators.required],
        universitySponsorLogo:['',Validators.required],
        certification:['',Validators.required],
        isTrialectChecked:['',Validators.required],
        isHostMonterChekced:['',Validators.required],
        numberOfSessions:['',Validators.required],
        durationOfEachSession:['',Validators.required],
        numberofSlots:['',Validators.required],
        contractStartDate:['',Validators.required],
        contractYears:['',Validators.required],
        hostAvailability:[],
        deactivatePost:['',Validators.required],
        merit:['',Validators.required],
        actualCost:['',Validators.required],
        discount:['',Validators.required],
        sponsorCost:['',Validators.required],
        // isRoundTheYear:['',Validators.required],
        startDatePreferredTimeSlots:['',Validators.required],
        endDatePreferredTimeSlots:['',Validators.required],
        myckeditorBriefDescription:[],
        myckeditorMainAreas:[],
        myckeditorTechniques:[],
        myckeditorCurriculum:[],
        myckeditorAccommodation:[],
        feature1:[],
        feature2:[],
        feature3:[],
        feature4:[],
        feature5:[],
        feature6:[],
        eligibilityCriteria:[],
        eligibleCountry:[],
        educationCareer:[],
        fieldOfInterest:[],
        clinicalTraineeship:[],
        clinicalResearchTraineeship:[],
        translationalTraineeship:[],
        basicTranslationalTraineeship:[],
        doctorCheck:[],
        biomedicalCheck:[],
        otherMedicalCheck:[],
        nGGrants:[],
        nPGrants:[],
        disclaimerText:[],
        trainerName:[],
        depname:[],
        hospName:[],
        hostEmail:[],
        address:[],
        country:[],
        websiteLink:[],
        tagLine:[],
        trainerNameCheck:[],
        question1:[],
        answer1:[],
  
        
        
      });
       
      this.userDetails=		
      {
        "username":""+localStorage.getItem("email")+"",
        "token":""+localStorage.getItem("token_Id")+"",
        "login_status":""+localStorage.getItem("status")+"",
       
       
      }
      this.value = [];
  
      this.options = {
        multiple: true
      }
      $(document).ready(function() {
        $("input[name$='cars']").click(function() {
          var test = $(this).val();
      
          $("div.desc").hide();
          $("#Cars" + test).show();
        });
      });
      $(document).ready(function() {
        var max_fields      = 10; //maximum input boxes allowed
        var wrapper   		= $(".input_fields_wrap"); //Fields wrapper
        var add_button      = $(".add_field_button"); //Add button ID
        
        var x = 1; //initlal text box count
        $(add_button).click(function(e){ //on add input button click
          e.preventDefault();
          if(x < max_fields){ //max input box allowed
            x++; //text box increment
            $(wrapper).append('<div class="row dateDiv"><div class="col-md-5"><div class="input-group date"><input type="text" class="form-control" /><span class="input-group-addon"><span class="fa fa-calendar"></span></span></div></div><div class="col-md-5"><div class="input-group date"><input type="text" class="form-control" /><span class="input-group-addon"><span class="fa fa-calendar"></span></span></div></div><div class="col-md-2"><div class="input-group date"><a  class="remove_field"><i class="fa fa-minus" aria-hidden="true"></i></a></div></div></div>');
            
            //add input box
            //$(wrapper).append('<div class="row dateDiv"><input type="text" name="mytext[]"/><a href="#" class="remove_field">Remove</a></div>'); 
          }
        });
        
        $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
          e.preventDefault(); $(this).parent().parent().parent('div').remove(); x--;
        })
      });
      this.getLocations();
      this.getCareerLevelsAPI();
      this.getFieldInterest();
    }
get f(){
  return this.creationstep1.controls;
}
onSubmit(){
  this.submitted = true;
alert("hi");
  if(this.creationstep1.errors){
    return;
  }
  alert('success'+ JSON.stringify(this.creationstep1.value));
}
    getFieldInterest()
    {
      
  
      // this.traineeshipService.getSearchFieldOfIntrest('{"username":"santosh.d@smartims.com","token":"1nuorlia58ckckoosskw4c448kwsg8w","login_status":"1"}').subscribe(
        this.traineeshipService.getSearchFieldOfIntrest(''+JSON.stringify(this.userDetails)+'').subscribe(
        (response) => {
         
            this.exampleData=response.dataRows;
            //alert(JSON.stringify(this.exampleData));
            
        },
        (err) => {
            this.errorMessage = err;
            this.pNamemsg = err;
  
        });
        
  
    }
    preferredTimeAction1(index,value){
      if(value){
      let preferDate = new prefferedmodel();
      this.preferredSlotArray.push(preferDate);
    }
    else{
      this.persons.splice(index,1);
      
    }
    }
    get persons() {
      return (<FormArray>this.creationstep1.get('persons')).controls;
    }
    preferredTimeAction() {
      alert("Wlecome");
      (<FormArray>this.creationstep1.get('persons')).push(this.fb.group({
        startDatePreferredTimeSlots:[],
        endDatePreferredTimeSlots:[],
      
      }
      ));
    }
    
    questions_Click(){
      let  questionModal1 =new questionModal();
      
      
      this.questionArray.push( questionModal1);
  
    }
    carrer_Click(){
      this.careerSelected = this.careerLevelList.filter(x=>x.selected).map(y=> y.carreers+","+y.id).join('/');
      let  careerModal1 =new careermodel();
      
      this.careerArray.push(careerModal1);
  
    }
   
    removeQuestion(index){
      
      this.questionArray.splice(index)
    }
    getLocations()
    {
      
            
       //this.traineeshipService.getLocations('{"username":"santosh.d@smartims.com"}').subscribe(
        this.traineeshipService.getLocations(''+JSON.stringify(this.userDetails)+'').subscribe(
        (response) => {
         
            this.countryList=response.dataRows;
            
        },
        (err) => {
            this.errorMessage = err;
            this.pNamemsg = err;
  
        });
  
    }
    onChange1(selectedValue)
    {
      this.selectedCountry=selectedValue;
    
  
    }
    public fileChange(input) {
        
      this.processImage(input.target.files);
    }
    hidepopup(target){
      $('#hidepopup').hide();
      //document.getElementById(target).style.display = 'none';
    }
  
    
    private processImage(files, index = 0) {
      let reader = new FileReader();
  
      if (index in files) {
              this.readFile(files[index], reader, (result) => {
                  
          // Create an img element and add the image file data to it
          let img = document.createElement('img');
          img.src = result;
  
          // Send this img to the resize function (and wait for callback)
          this.traineeshipService.resizeImage(img, (croppedImage) => {
  
            // This is the file you want to upload.
            // Either as a base64 string or img.src = croppedImage if you prefer a file.
            this.uploadImage = croppedImage;
            this.uploadImageBase64 = croppedImage;
          });
        });
      } else {
        // When all files are done this forces a change detection
        this.changeDetectorRef.detectChanges();
      }
    }
  
    private readFile(file, reader, callback) {
      reader.onload = () => {
        callback(reader.result);
      };
  
      reader.readAsDataURL(file);
      }
  
    removeSelectedImage(selectedFileName,i)
    {
      //alert(selectedFileName);
      // $('#id_drugs.jpg').empty();
      $( "p[id='id_"+selectedFileName+"']" ).empty();
      //$( "button[id='btnId_"+selectedFileName+"']" ).remove();
      $( "img[id='imgId_"+i+"']" ).attr("src","");
      var x;
      x = $("button[id='btnId_"+selectedFileName+"']").detach();
      $("body").prepend(x);
      //$( "p[id='id_"+selectedFileName+"'" ).empty();
      //$( "p[id='id_drugs.jpg'" ).empty();
    }
   
    public startDateOptions: IMyOptions = {
      dateFormat: 'yyyy/mm/dd',
    };
    public endDateOptions: IMyOptions = {
        dateFormat: 'yyyy/mm/dd',
    };
   
    nextEvent()
    {
      
        var $active = $('.wizard .nav-tabs li.active');
        $active.next().removeClass('disabled');
        this.nextTab($active);
  
    }
  
    previousButtonEvent()
    {
  
      var $active = $('.wizard .nav-tabs li.active');
      this.prevTab($active);
    }
  
     public nextTab(elem) {
      $(elem).next().find('a[data-toggle="tab"]').click();
    }
  
    public  prevTab(elem) {
      $(elem).prev().find('a[data-toggle="tab"]').click();
    }
    
    private convertDate(date: any): string {
      return (date) ? date.year + '-' + date.month + '-' + date.day : '';
  }
  public alertClosed(): void {
    // this.successMessage = null;
    this.errorMessage = null;
    this.pNamemsg = null;
    
  }

  submitCreationData()
{
  this.submitted = true;

    
  if(this.creationstep1.value.certification==true){
    if(this.creationstep1.value.isHostMonterChekced==true){
      
      this.certification_type="hostmentor"

    }
    else if(this.creationstep1.value.isTrialectChecked==true){
      this.certification_type="trialect"
    }
    else if(this.creationstep1.value.isTrialectChecked==true && this.creationstep1.value.isHostMonterChekced==true){
      this.certification_type="both"
    }

  }
  if(this.creationstep1.value.certification==true){
    this.creationstep1.value.certification="yes";
  }
  else{
    this.creationstep1.value.certification="no"
  }
  if(this.creationstep1.value.hostAvailability==true){
    this.creationstep1.value.hostAvailability="round_the_year";
  }
  else{
    this.creationstep1.value.hostAvailability="preferred_time_slots";
  }

  this.submitCreationRequest=
  {
    "id":"",
    "traineeship_type":"onlinetraineeship",
    "partial_program":"no",
    "slug":'',
    "program_name":this.creationstep1.value.programName,
    "brief_description":this.creationstep1.value.briefDescription,
    "sponsor_logo":this.uploadImageBase64,
    "certification":this.creationstep1.value.certification,
    "certification_type":this.certification_type,
    "no_of_sessions":this.creationstep1.value.numberOfSessions,
    "duration_of_sessions":this.creationstep1.value.durationOfEachSession,
    "applicants_count":'',
    "total_spots":this.creationstep1.value.numberofSlots,
    "contract_startdate":this.convertDate(this.creationstep1.value.contractStartDate.date),
    "years_of_contract":this.creationstep1.value.noOfYearsContract,
    "priority_merit_cost":this.creationstep1.value.actualCost,
    "priority_merit_discount":this.creationstep1.value.discount,
    "deactivate_post":this.creationstep1.value.deactivatePost,
    "sponsor_cost":this.creationstep1.value.sponsorCost,
    "host_availability":'',
    "full_description":'',
    "techniques":'',
    "curriculumn":'',
    "accommodation":'',
    "top_clinical_traineeship":'',
    "top_clinical_res_traineeship":'',
    "top_bas_translational":'',
    "top_translational":'',
    "profession_doctor":'',
    "profession_biomedical":'',
    "profession_others":'',
    "field_of_interests":'',
    "eligibility_criteria":'',
    "eligible_countries":'',
    "feature1":'',
    "feature2":'',
    "feature3":'',
    "feature4":'',
    "feature5":'',
    "feature6":'',
    "trainer_name":'',
    "trainer_name_check":'',
    "department_name":'',
    "hospital_name":'',
    "address":'',
    "trainer_country_id":'',
    "trainer_country_name":'',
    "website_link":'',
    "nih_grants":'',
    "non_profit_grants":'',
    "host_affiliation":'',
    "tagline":'',
    "draft":'',
    "deadline":'',
    "published_date":'',
    "created_date":'',
    "status":'',
    "username":""+localStorage.getItem("email")+"",
    "token":""+localStorage.getItem("token_Id")+"",
    "login_status":""+localStorage.getItem("status")+"",
    "step":"1"
  }


  if((this.creationstep1.value.programName==""||this.creationstep1.value.programName==undefined)||
  (this.creationstep1.value.briefDescription==""||this.creationstep1.value.briefDescription==undefined)||
  (this.creationstep1.value.numberOfSessions==""||this.creationstep1.value.numberOfSessions==undefined)||
  (this.creationstep1.value.durationOfEachSession==""||this.creationstep1.value.durationOfEachSession==undefined)||
  (this.creationstep1.value.numberofSlots==""||this.creationstep1.value.numberofSlots==undefined)||
  (this.convertDate(this.creationstep1.value.contractStartDate.date)==""||this.convertDate(this.creationstep1.value.contractStartDate.date)==undefined)||
  (this.creationstep1.value.contractYears==""||this.creationstep1.value.contractYears==undefined)||
  (this.creationstep1.value.actualCost==""||this.creationstep1.value.actualCost==undefined)||
  (this.creationstep1.value.discount==""||this.creationstep1.value.discount==undefined)||
  (this.creationstep1.value.sponsorCost==""||this.creationstep1.value.sponsorCost==undefined)
  
  ){
      
   
    window.scroll(0,0)
    
  }
  else{
  this.traineeshipService.programCreation(''+JSON.stringify(this.submitCreationRequest)+'').subscribe(
    (response) => {
     
        this.allCreationList=response.dataRows;
        // this.nextEvent();
    },
    (err) => {
        this.errorMessage = err;

    });
    this.nextEvent();
  }
}
submitStep1(){

}
submitStep2()
{
  this.submitCreationRequest=
  {
    "id":"",
    "full_description":this.creationstep1.value.myckeditorMainAreas,
    "techniques":this.creationstep1.value.myckeditorTechniques,
    "curriculumn":this.creationstep1.value.myckeditorCurriculum,
    "accommodation":this.creationstep1.value.myckeditorAccommodation,
    "username":""+localStorage.getItem("email")+"",
    "token":""+localStorage.getItem("token_Id")+"",
    "login_status":""+localStorage.getItem("status")+"",
    "step":"2"
  }

  //alert(this.traineeship);
  if((this.creationstep1.value.myckeditorMainAreas==""||this.creationstep1.value.myckeditorMainAreas==undefined)||
  (this.creationstep1.value.myckeditorTechniques==""||this.creationstep1.value.myckeditorTechniques==undefined)||
  (this.creationstep1.value.myckeditorCurriculum==""||this.creationstep1.value.myckeditorCurriculum==undefined)||
  (this.creationstep1.value.myckeditorAccommodation==""||this.creationstep1.value.myckeditorAccommodation==undefined)
  
  ){

    
    if(this.creationstep1.value.myckeditorAccommodation==""||this.creationstep1.value.myckeditorAccommodation==undefined){
      window.scroll(0,0)
    this.errorMessage = "Please enter Accommodation"
    }
    
    else if(this.creationstep1.value.myckeditorCurriculum==""||this.creationstep1.value.myckeditorCurriculum==undefined){
      window.scroll(0,0)
      this.errorMessage = "Please enter Curriculum"
    }
    else if(this.creationstep1.value.myckeditorTechniques==""||this.creationstep1.value.myckeditorTechniques==undefined){
      window.scroll(0,0)
      this.errorMessage = "Please enter Techniques"
    }
    else if(this.creationstep1.value.myckeditorMainAreas==""||this.creationstep1.value.myckeditorMainAreas==undefined){
      window.scroll(0,0)
      this.errorMessage = "Please enter MainAreas"
    }
    
    else{
    window.scroll(0,0)
    this.errorMessage = "Please fill all the required fields"
    }
  }
  else{
  this.traineeshipService.programCreation(''+JSON.stringify(this.submitCreationRequest)+'').subscribe(
    (response) => {
     
        this.allCreationList=response.dataRows;
        // this.nextEvent();
    },
    (err) => {
        this.errorMessage = err;

    });
    this.nextEvent();
  }
}
submitStep3()
{
  
  let selectedFieldOfInterest= this.getSelectedFieldOfInterest();
    let selectedCountry=$("#ddlCountry option:selected").text();
 
  this.submitCreationRequest=
  {
    "id":"",
    "field_of_interests":selectedFieldOfInterest,
    "eligibility_criteria":this.creationstep1.value.eligibilityCriteria,
    "eligible_countries":selectedCountry,
    "program_carrers":this.careerSelected,
    "feature1":this.creationstep1.value.feature1,
    "feature2":this.creationstep1.value.feature2,
    "feature3":this.creationstep1.value.feature3,
    "feature4":this.creationstep1.value.feature4,
    "feature5":this.creationstep1.value.feature5,
    "feature6":this.creationstep1.value.feature6,
    "username":""+localStorage.getItem("email")+"",
    "token":""+localStorage.getItem("token_Id")+"",
    "login_status":""+localStorage.getItem("status")+"",
    "step":"3"
  }

  if((selectedFieldOfInterest==""||selectedFieldOfInterest==undefined)||
  (this.creationstep1.value.eligibilityCriteria==""||this.creationstep1.value.eligibilityCriteria==undefined)||
  (this.creationstep1.value.eligibleCountry==""||this.creationstep1.value.eligibleCountry==undefined)||
 
  (this.creationstep1.value.feature1==""||this.creationstep1.value.feature1==undefined)||
  (this.creationstep1.value.feature2==""||this.creationstep1.value.feature2==undefined)||
  (this.creationstep1.value.feature3==""||this.creationstep1.value.feature3==undefined)||
  (this.creationstep1.value.feature4==""||this.creationstep1.value.feature4==undefined)||
  (this.creationstep1.value.feature5==""||this.creationstep1.value.feature5==undefined)||
  (this.creationstep1.value.feature6==""||this.creationstep1.value.feature6==undefined)
  
  ){

    
    if(this.creationstep1.value.fieldOfInterest==""||this.creationstep1.value.fieldOfInterest==undefined){
      window.scroll(0,0)
    this.errorMessage = "Please enter fieldOfInterest"
    }
    else if(this.creationstep1.value.eligibilityCriteria==""||this.creationstep1.value.eligibilityCriteria==undefined){
      window.scroll(0,0)
      this.errorMessage = "Please enter eligibility Criteria "
    }
    else if(this.creationstep1.value.eligibleCountry==""||this.creationstep1.value.eligibleCountry==undefined){
      window.scroll(0,0)
      this.errorMessage = "Please enter eligible Country"
    }
    
    else if(this.creationstep1.value.educationCareer==""||this.creationstep1.value.educationCareer==undefined){
      window.scroll(0,0)
      this.errorMessage = "Please enter education Career"
    }
    else if(this.creationstep1.value.feature1==""||this.creationstep1.value.feature1==undefined){
      window.scroll(0,0)
      this.errorMessage = "Please enter feature1"
    }
    else if(this.creationstep1.value.feature2==""||this.creationstep1.value.feature2==undefined){
      window.scroll(0,0)
      this.errorMessage = "Please enter feature2"
    }
    else if(this.creationstep1.value.feature3==""||this.creationstep1.value.feature3==undefined){
      window.scroll(0,0)
      this.errorMessage = "Please enter feature 3"
    }
    else if(this.creationstep1.value.feature4==""||this.creationstep1.value.feature4==undefined){
      window.scroll(0,0)
      this.errorMessage = "Please enter feature 4"
    }
    else if(this.creationstep1.value.feature5==""||this.creationstep1.value.feature5==undefined){
      window.scroll(0,0)
      this.errorMessage = "Please enter feature 5"
    }
    
    else{
    window.scroll(0,0)
    this.errorMessage = "Please fill all the required fields"
    }
  }
  else{
  this.traineeshipService.programCreation(''+JSON.stringify(this.submitCreationRequest)+'').subscribe(
    (response) => {
     
        this.allCreationList=response.dataRows;
        // this.nextEvent();
    },
    (err) => {
        this.errorMessage = err;

    });
    this.nextEvent();
  }
}

  submitStep4()
{
  let selectedCountry=$("#ddlCountry option:selected").text();
  if(this.creationstep1.value.otherMedicalCheck==true){
    this.creationstep1.value.otherMedicalCheck="yes"
  }
  else{
    this.creationstep1.value.otherMedicalCheck="no"
  }
  if(this.creationstep1.value.doctorCheck==true){
    this.creationstep1.value.doctorCheck="yes"
  }
  else{
    this.creationstep1.value.doctorCheck="no"
  }
  if(this.creationstep1.value.biomedicalCheck==true){
    this.creationstep1.value.biomedicalCheck="yes"
  }
  else{
    this.creationstep1.value.biomedicalCheck="no"
  }
  if(this.creationstep1.value.clinicalTraineeship==true){
    this.creationstep1.value.clinicalTraineeship="yes"
  }
  else{
    this.creationstep1.value.clinicalTraineeship="no"
  }
  if(this.creationstep1.value.clinicalResearchTraineeship==true){
    this.creationstep1.value.clinicalResearchTraineeship="yes"
  }
  else{
    this.creationstep1.value.clinicalResearchTraineeship="no"
  }
  if(this.creationstep1.value.translationalTraineeship==true){
    this.creationstep1.value.translationalTraineeship="yes"
  }
  else{
    this.creationstep1.value.translationalTraineeship="no"
  }
  if(this.creationstep1.value.basicTranslationalTraineeship==true){
    this.creationstep1.value.basicTranslationalTraineeship="yes"
  }
  else{
    this.creationstep1.value.basicTranslationalTraineeship="no"
  }
  

  this.submitCreationRequest=
  {
    "id":"",
    "trainer_name":this.creationstep1.value.trainerName,
    "trainer_name_check":this.creationstep1.value.trainerNameCheck,
    "department_name":this.creationstep1.value.depname,
    "hospital_name":this.creationstep1.value.hospName,
    "address":this.creationstep1.value.address,
    "trainer_country_id":this.selectedCountry,
    "trainer_country_name":selectedCountry,
    "website_link":this.creationstep1.value.websiteLink,
    "nih_grants":this.creationstep1.value.nGGrants,
    "non_profit_grants":this.creationstep1.value.nPGrants,
    "host_affiliation":this.creationstep1.value.disclaimerText,
    "tagline":this.creationstep1.value.tagLine,
    "top_clinical_traineeship":this.creationstep1.value.clinicalTraineeship,
    "top_clinical_res_traineeship":this.creationstep1.value.clinicalResearchTraineeship,
    "top_bas_translational":this.creationstep1.value.basicTranslationalTraineeship,
    "top_translational":this.creationstep1.value.translationalTraineeship,
    "profession_doctor":this.creationstep1.value.doctorCheck,
    "profession_biomedical":this.creationstep1.value.biomedicalCheck,
    "profession_others":this.creationstep1.value.otherMedicalCheck,
    "username":""+localStorage.getItem("email")+"",
    "token":""+localStorage.getItem("token_Id")+"",
    "login_status":""+localStorage.getItem("status")+"",
    "step":"4"
  }

  if((this.creationstep1.value.trainerName==""||this.creationstep1.value.trainerName==undefined)||
  //(this.creationstep1.value.trainerNameCheck==""||this.creationstep1.value.trainerNameCheck==undefined)||
  (this.creationstep1.value.depname==""||this.creationstep1.value.depname==undefined)||
  (this.creationstep1.value.hospName==""||this.creationstep1.value.hospName==undefined)||
  (selectedCountry==""||selectedCountry==undefined)||
  (this.creationstep1.value.disclaimerText==""||this.creationstep1.value.disclaimerText==undefined)||
  (this.creationstep1.value.websiteLink==""||this.creationstep1.value.websiteLink==undefined)
  
  ){
    if(this.creationstep1.value.trainerName==""||this.creationstep1.value.trainerName==undefined){
      window.scroll(0,0)
    this.errorMessage = "Please trainer name"
    }
    else if(this.creationstep1.value.depname==""||this.creationstep1.value.depname==undefined){
      window.scroll(0,0)
      this.errorMessage = "Please department name"
    }
    else if(this.creationstep1.value.hospName==""||this.creationstep1.value.hospName==undefined){
      window.scroll(0,0)
      this.errorMessage = "Please hospital name"
    }
    else if(selectedCountry==""||selectedCountry==undefined){
      window.scroll(0,0)
      this.errorMessage = "Please select country"
    }
    else if(this.creationstep1.value.disclaimerText==""||this.creationstep1.value.disclaimerText==undefined){
      window.scroll(0,0)
      this.errorMessage = "Please type disclaimer Text message"
    }
    else if(this.creationstep1.value.websiteLink==""||this.creationstep1.value.websiteLink==undefined){
      window.scroll(0,0)
      this.errorMessage = "Please type websiteLink name"
    }
    
    else{
    window.scroll(0,0)
    this.errorMessage = "Please fill all the required fields"
    }
  }
  else{
  this.traineeshipService.programCreation(''+JSON.stringify(this.submitCreationRequest)+'').subscribe(
    (response) => {
     
        this.allCreationList=response.dataRows;
        // this.nextEvent();
    },
    (err) => {
        this.errorMessage = err;

    });
    this.nextEvent();
  }
}
submitStep5()
{
  
  this.submitCreationRequest=
  {
    "id":"",
    
    "questions":this.questionArray,
    //"answer":this.creationstep1.value.answer1,
    "username":""+localStorage.getItem("email")+"",
    "token":""+localStorage.getItem("token_Id")+"",
    "login_status":""+localStorage.getItem("status")+"",
    "step":"5"
  }


//   if((this.creationstep1.value.question1==""||this.creationstep1.value.question1==undefined)||
//   (this.creationstep1.value.answer1==""||this.creationstep1.value.answer1==undefined)
  
//   ){
//     console.log(this.creationstep1.value)
//     //alert(this.creationstep1.value.answer1)
//     if(this.creationstep1.value.question1==""||this.creationstep1.value.question1==undefined){
//       window.scroll(0,0)
//       this.errorMessage = "Please fill question fields"
//     }
//     else if(this.creationstep1.value.answer1==""||this.creationstep1.value.answer1==undefined){
      
//       window.scroll(0,0)
//       this.errorMessage = "Please fill answer fields"
//     }
// else{
//     window.scroll(0,0)
//     this.errorMessage = "Please fill all the required fields"
//   }
//   }
//   else{
//   this.traineeshipService.programCreation(''+JSON.stringify(this.submitCreationRequest)+'').subscribe(
//     (response) => {
     
//         this.allCreationList=response.dataRows;
//         // this.nextEvent();
//     },
//     (err) => {
//         this.errorMessage = err;

//     });
//     this.nextEvent();
//   }

  this.traineeshipService.programCreation(''+JSON.stringify(this.submitCreationRequest)+'').subscribe(
    (response) => {
     
        this.allCreationList=response.dataRows;
        // this.nextEvent();
    },
    (err) => {
        this.errorMessage = err;

    });
    this.nextEvent();

}
getCareerLevelsAPI()
  {
    
          
     //this.traineeshipService.getLocations('{"username":"santosh.d@smartims.com"}').subscribe(
      this.traineeshipService.programCareerlevelCreate(''+JSON.stringify(this.userDetails)+'').subscribe(
      (response) => {
       
        response.dataRows.forEach(o=>{
          o.selected = o.selected == '0' ? false : true;
        });

          this.careerLevelList=response.dataRows;
          
      },
      (err) => {
          this.errorMessage = err;

      });

  }

  checkIfAllSelected(e) {
    // this.selectedAll = this.careerLevelList.every(function(item:any) {
    //     return item.selected ;
    //   })

     this.careerSelected = this.careerLevelList.filter(x=>x.selected).map(y=>({...y,'id':""}));
      //this.careerSelected = this.careerLevelList.filter(x=>x.selected).map(y=> "{ name:"+y.carreers+",career_id:"+y.id+",'id:''}").join(',');
     // this.careerSelected = this.careerLevelList.filter(x=>x.selected).map(y=>"'"+ y.carreers+"'").join(',');
      //this.program_carrers.push(this.careerSelected)
  }
  changed(info: {data: any,value: string}) {
    if(info!=null && info.value!= null){
      
      this.word='+';
     
     for (let i = 0; i < info.data.length; i++) {
          this.current = (info.data[i].text);
          if(this.current.indexOf(' ')>= 0){
              this.current="'"+this.current+"'"
          }
         
          this.word=this.word+" +"+this.current;
    
      }
     
    

   
    }
    else{
     
      this.word=""
    }
    
  }
  getSelectedFieldOfInterest()
  {
      
      
    let selectedFieldOfInterest=this.word.substring(1).trim();
    let finalString="";
    
      finalString=selectedFieldOfInterest.split("+").join("");
      
    
    
    return finalString;

  }
}
