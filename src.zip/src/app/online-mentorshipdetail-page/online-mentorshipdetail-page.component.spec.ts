import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnlineMentorshipdetailPageComponent } from './online-mentorshipdetail-page.component';

describe('OnlineMentorshipdetailPageComponent', () => {
  let component: OnlineMentorshipdetailPageComponent;
  let fixture: ComponentFixture<OnlineMentorshipdetailPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnlineMentorshipdetailPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnlineMentorshipdetailPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
