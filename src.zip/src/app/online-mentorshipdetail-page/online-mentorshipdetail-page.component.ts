import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService} from '../services/common.service';
@Component({
  selector: 'app-online-mentorshipdetail-page',
  templateUrl: './online-mentorshipdetail-page.component.html',
  styleUrls: ['./online-mentorshipdetail-page.component.css']
})
export class OnlineMentorshipdetailPageComponent implements OnInit {
  appUrl:string;
  constructor(private router: Router,
		private route: ActivatedRoute) { }

  ngOnInit() {
    this.appUrl= CommonService.APP_URL;
  }
  exploreTraineeship(){
    
    localStorage.setItem("traineeshipTypeOnlineMentor","onlinementorshipDetailpage")
    sessionStorage.setItem('programListIsDefault','exploreTraineship');
    this.router.navigate(['/', 'program-list']);
  }
}
