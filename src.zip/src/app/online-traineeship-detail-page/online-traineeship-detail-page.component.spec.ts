import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnlineTraineeshipDetailPageComponent } from './online-traineeship-detail-page.component';

describe('OnlineTraineeshipDetailPageComponent', () => {
  let component: OnlineTraineeshipDetailPageComponent;
  let fixture: ComponentFixture<OnlineTraineeshipDetailPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnlineTraineeshipDetailPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnlineTraineeshipDetailPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
