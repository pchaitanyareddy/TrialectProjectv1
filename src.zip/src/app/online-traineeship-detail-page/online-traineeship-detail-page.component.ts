import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService} from '../services/common.service';
@Component({
  selector: 'app-online-traineeship-detail-page',
  templateUrl: './online-traineeship-detail-page.component.html',
  styleUrls: ['./online-traineeship-detail-page.component.css']
})
export class OnlineTraineeshipDetailPageComponent implements OnInit {
  appUrl:string;
  constructor(private router: Router,
		private route: ActivatedRoute) { }

  ngOnInit() {
    this.appUrl= CommonService.APP_URL;
  }
  exploreTraineeship(){
    sessionStorage.setItem('programListIsDefault','exploreTraineship');
    localStorage.setItem("traineeshipTypeonline","onlineTraineeshipDetailpage")
    this.router.navigate(['/', 'program-list']);
  }

}
