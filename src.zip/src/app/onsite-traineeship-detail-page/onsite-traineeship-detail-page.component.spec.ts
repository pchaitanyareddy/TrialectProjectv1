import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnsiteTraineeshipDetailPageComponent } from './onsite-traineeship-detail-page.component';

describe('OnsiteTraineeshipDetailPageComponent', () => {
  let component: OnsiteTraineeshipDetailPageComponent;
  let fixture: ComponentFixture<OnsiteTraineeshipDetailPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnsiteTraineeshipDetailPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnsiteTraineeshipDetailPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
