import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService} from '../services/common.service';
@Component({
  selector: 'app-onsite-traineeship-detail-page',
  templateUrl: './onsite-traineeship-detail-page.component.html',
  styleUrls: ['./onsite-traineeship-detail-page.component.css']
})
export class OnsiteTraineeshipDetailPageComponent implements OnInit {
  appUrl:string;
  constructor(private router: Router,
		private route: ActivatedRoute) { }

  ngOnInit() {
    this.appUrl= CommonService.APP_URL;
  }
  exploreTraineeship(){
    sessionStorage.setItem('programListIsDefault','exploreTraineship');
    localStorage.setItem("traineeshipTypeOnsite","onsiteTraineeshipDetailpage")
    this.router.navigate(['/', 'program-list']);
  }

}
