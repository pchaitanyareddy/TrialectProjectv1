import { Component, OnInit } from '@angular/core';
import { CommonService} from '../services/common.service';
@Component({
  selector: 'app-payment-gateway',
  templateUrl: './payment-gateway.component.html',
  styleUrls: ['./payment-gateway.component.css']
})
export class PaymentGatewayComponent implements OnInit {
  appUrl:string;
  constructor() { }

  ngOnInit() {
    this.appUrl= CommonService.APP_URL;
  }

}
