import { Component, OnInit,HostListener,ChangeDetectorRef ,ElementRef, ViewChild,Renderer2} from '@angular/core';
import { CommonService} from '../services/common.service';
@Component({
  selector: 'app-privacy-policy',
  templateUrl: './privacy-policy.component.html',
  styleUrls: ['./privacy-policy.component.css']
})
export class PrivacyPolicyComponent implements OnInit {
  @HostListener('window:scroll', ['$event'])
  appUrl:string;
   
  constructor() { }

  ngOnInit() {
    this.appUrl= CommonService.APP_URL;
  }
  moveScroll(el: HTMLElement){
    var top = el.offsetTop;
    //el.scrollTop = 400;
    //el.scroll(0, 200);
    // el.scroll({
    //   top: top,
    //   behavior: 'smooth'
    // });
   el.scrollIntoView();
  }

}
