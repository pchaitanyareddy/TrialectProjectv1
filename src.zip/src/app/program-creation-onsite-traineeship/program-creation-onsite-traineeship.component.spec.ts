import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProgramCreationOnsiteTraineeshipComponent } from './program-creation-onsite-traineeship.component';

describe('ProgramCreationOnsiteTraineeshipComponent', () => {
  let component: ProgramCreationOnsiteTraineeshipComponent;
  let fixture: ComponentFixture<ProgramCreationOnsiteTraineeshipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProgramCreationOnsiteTraineeshipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProgramCreationOnsiteTraineeshipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
