import { Component, OnInit ,ChangeDetectionStrategy} from '@angular/core';
import { IMyInputFieldChanged, IMyOptions } from 'mydatepicker';
import { CommonService} from '../services/common.service';
@Component({
  selector: 'app-program-creation-onsite-traineeship',
  templateUrl: './program-creation-onsite-traineeship.component.html',
  styleUrls: ['./program-creation-onsite-traineeship.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProgramCreationOnsiteTraineeshipComponent implements OnInit {
  appUrl:string;
  constructor() { }

  ngOnInit() {
    this.appUrl= CommonService.APP_URL;
  }
  public startDateOptions: IMyOptions = {
    dateFormat: 'yyyy/mm/dd',
  };

  nextEvent()
  {
    
      var $active = $('.wizard .nav-tabs li.active');
      $active.next().removeClass('disabled');
      this.nextTab($active);

  }

  previousButtonEvent()
  {

    var $active = $('.wizard .nav-tabs li.active');
    this.prevTab($active);
  }

   public nextTab(elem) {
    $(elem).next().find('a[data-toggle="tab"]').click();
  }

  public  prevTab(elem) {
    $(elem).prev().find('a[data-toggle="tab"]').click();
  }

}
