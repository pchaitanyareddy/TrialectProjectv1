export class questionModal {
  question: string = "";
  answer: string = "";
  category: string = "general";
  qa_id: string = "";
}

export class careermodel {
  career_id: string = "";
  career: string = "";
  cr_id: string = "";
}
export class preffered_datesmodel {
  id: number = 0;
  start_date: string="";
  end_date: string="";
  program_id: number;

  start_date_Local: Date;
  end_date_Local: Date;
  flag: boolean = false;
};
export class PriorityMeritmodel {
  id: number = 0;
  priority_merit_weeks: string="";
  priority_merit_cost: string="";
  priority_merit_discount: string="";
  merit_cost: string='';
  flag: boolean = true;
  Add:boolean=true;
  sponsor: string='';
  priority_merit_weeks_valid: boolean=true;
  priority_merit_cost_valid: boolean=true;
  priority_merit_discount_valid: boolean=true;
  merit_cost_week:string="";
  sponsor_week:string="";
};

export interface IFileReaderEventTarget extends EventTarget {
  result:string;
  files:any;
}

export interface IFileReaderEvent extends Event {
  target: IFileReaderEventTarget;
  getMessage():string;
  
}


export class ProgramType {
  id: number;
  Name: string;
  Code: string;
  RouthPath: string;
}

enum certification{
    
}
 
export enum TraineeshipType {
  onlinetraineeship,
  onlinementorship,
  onsitetraineeship

}

export class FileModel {
  id: number = 0;
  program_id: string;
  url: string;
  name: string;
  imagename: string;
  uploadFileBase64: string;
  flag: boolean = false;
  uploadrelatedFileBase64: string;

};

export class UserModel {
  id: number = 0;
  username: string;
  token: string;
  login_status: string;


};


export class QuestionsModel {
  id: number = 0;
  program_id: string;
  question: string;
  answer: string;
  status: string;
  flag: boolean = true;
  category:string="general";
  

};



export class CarreersModel {
  id: number = 0;
  program_id: string;
  career_id: number;
  name: string;
   
};
 



export class image_urlModel {
  id: number = 0;
  program_id: string;
  imagename:string;
  url: string;
   
};
 

export class meshtermModel {
  meshterm_id: number;
  name: string;
  id: number = -1;
  flag: boolean = false;
}



export class program_countriesModel {
  program_id:number;
  country_id: number;
  name: string;
  id: number = -1;
  flag: boolean = false;
}

 


