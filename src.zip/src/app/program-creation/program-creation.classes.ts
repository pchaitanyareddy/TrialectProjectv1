export class questionModal {
  question: string = "";
  answer: string = "";
  category: string = "general";
  qa_id: string = "";
}
export class careermodel {
  career_id: string = "";
  career: string = "";
  cr_id: string = "";
}
export class preffered_datesmodel {
  id: number = 0;
  start_date: string="";
  end_date: string="";
  program_id: number;

  start_date_Local: any;
  end_date_Local: any;
  flag: boolean = false;
};
export class PriorityMeritmodel {
  id: number = 0;
  priority_merit_weeks: string="";
  priority_merit_cost: string="";
  priority_merit_discount: string;
  merit_cost: string='';
  flag: boolean = false;
  Add:boolean=true;
  sponsor: string='';
};

export interface IFileReaderEventTarget extends EventTarget {
  result:string;
  files:any;
}

export interface IFileReaderEvent extends Event {
  target: IFileReaderEventTarget;
  getMessage():string;
  
}
export enum TraineeshipType {
  onlinementorship,
  OnlineTraineeship,
  OnsiteTraineeship

}