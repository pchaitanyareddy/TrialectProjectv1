import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProgramDetailBreifComponent } from './program-detail-breif.component';

describe('ProgramDetailBreifComponent', () => {
  let component: ProgramDetailBreifComponent;
  let fixture: ComponentFixture<ProgramDetailBreifComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProgramDetailBreifComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProgramDetailBreifComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
