import { Component, OnInit,HostListener,ElementRef,Renderer2 } from '@angular/core';
import { Router, NavigationEnd,ActivatedRoute, } from '@angular/router';
import { TemplateNavigationComponent} from '../template/template-navigation.component';
import { TraineeshipService} from '../services/traineeship.service';
import { CommonService} from '../services/common.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import {LoginService} from '../services/login.service';
import {ProgramCreationRequest} from '../request/programCreation-request';
import { NgxGalleryOptions, NgxGalleryImage, NgxGalleryAnimation } from 'ngx-gallery';
import * as programcreationModel from '../program-creation/program-creation-classes';
@Component({
  selector: 'app-program-detail-breif',
  templateUrl: './program-detail-breif.component.html',
  styleUrls: ['./program-detail-breif.component.css']
})
export class ProgramDetailBreifComponent implements OnInit {

  allmedicationTypeList:any;
  errorMessage:any;
  loginFailureMessage:string="";
  forgotResponse:any;
  loginErrorMessage:any;
  programDetails:any;
  traineeshipType:any;
  public preferredDatesList: programcreationModel.preffered_datesmodel[] = [];
  programViewReviews:any;
  programViewQuestions:any;
  noQuestions:boolean=false;
  countryList:any;
  certifications:any;
  selectedCountry:string;
  isCertified:string;
  title:string;
  searchQAText:string="";
  userDetails:any;
	username:any;
	loggedInUserName:string;
  loggedInUserRole:string;
  selectedCountryId:number;
  appUrl:string;
  selectedProgramId:string;
  urlImages:any;
  programImages:any;
  programImages_count:any;
  program_countries:any;
  carreerslistdata:any;
  round_the_yearselected: boolean = false;
  preferred_time_slotsselected: boolean = false;
  recentPost:any;
  galleryOptions: NgxGalleryOptions[];
    galleryImages: NgxGalleryImage[];
  public signin: FormGroup;
  @HostListener('window:scroll', ['$event']) 
      doSomething(event) {
        if(window.pageYOffset>2){
          document.querySelector('.details-nav').classList.add('scrollTop');
          document.querySelector('.program-detail-breif-right').classList.add('scrollTopRight');
        }
        else{
          document.querySelector('.details-nav').classList.remove('scrollTop');
          document.querySelector('.program-detail-breif-right').classList.remove('scrollTopRight');
        } 
  }
  constructor(private router: Router, 
    private route: ActivatedRoute,
    private traineeshipService:TraineeshipService,
    private loginService:LoginService,
    private fb: FormBuilder,
    private elRef:ElementRef,
    private renderer: Renderer2) { }
  
  ngOnInit() {
    this.loggedInUserName=localStorage.getItem("firstname");
    
    this.appUrl= CommonService.APP_URL;
    this.signin = this.fb.group({
      email: ['', Validators.required],
      password: ['', Validators.required],
      
    });
    window.scrollTo(0,0);


    this.selectedProgramId="";
    this.route.params.subscribe(params => {
      this.selectedProgramId = params['id'];
      
  });
    
    this.getProgramView(this.selectedProgramId);
    this.getProgramViewReviews(this.selectedProgramId);
    this.getProgramViewQuestions(this.selectedProgramId);
    this.getLocations();
  
    // alert(localStorage.getItem("programType"))
    if(this.loggedInUserName!=null){
      this.router.navigate(['/', this.selectedProgramId, 'program-details'])
    }
    this.galleryOptions = [
      {
          width: '900px',
          height: '500px',
          thumbnailsColumns: 8,
          imageAnimation: NgxGalleryAnimation.Slide
      },
      // max-width 800
      {
          breakpoint: 800,
          width: '100%',
          height: '600px',
          imagePercent: 80,
          thumbnailsPercent: 20,
          thumbnailsMargin: 20,
          thumbnailMargin: 20
      },
      // max-width 400
      {
          breakpoint: 400,
          preview: false
      }
  ];

  }
  moveScroll(el: HTMLElement){
    var top = el.offsetTop;
    //el.scrollTop = 400;
    //el.scroll(0, 200);
    // el.scroll({
    //   top: top,
    //   behavior: 'smooth'
    // });
   el.scrollIntoView();
  }

  getLocations()
{
  this.userDetails=		
    {
      "username":""+localStorage.getItem("email")+"",
      "token":""+localStorage.getItem("token_Id")+"",
      "login_status":""+localStorage.getItem("status")+"",
     
    }
    this.traineeshipService.getLocations(''+JSON.stringify(this.userDetails)+'').subscribe(
    (response) => {
     
        this.countryList=response.dataRows;
        
    },
    (err) => {
        this.errorMessage = err;

    });

}
onChange(selectedValue)
{
  this.selectedCountry=selectedValue;


}
check(){
  //alert("first");
  $(".faq-div").show();
  $('#myModalLabel2').html("<strong>Questions & Answers.</strong>");
  $('#faqflag').val("individual");
  $('#programid').val(this.selectedProgramId); 
  $('#searchfield').val("");
  //alert("last");
}
searchQA(qa){

  this.programViewQuestions.forEach(srch => {
    srch.Flag = (srch.question.indexOf(qa) > -1 || srch.answer.indexOf(qa) > -1);
  });  

  this.noQuestions=!this.programViewQuestions.filter(p=>p.Flag).length;
}
  getProgramView(programId)
  {
   
      // this.traineeshipService.getProgramView('{"Id":'+programId+',"username":"santosh.d@smartims.com","token":"'+localStorage.getItem("token_Id")+'","login_status":"'+localStorage.getItem("status")+'"}').subscribe(
        this.traineeshipService.getProgramView('{"Id":'+programId+',"username":"'+localStorage.getItem("email")+'","token":"'+localStorage.getItem("token_Id")+'","login_status":"'+localStorage.getItem("status")+'"}').subscribe(
      (response) => {
       
          this.programDetails=response.dataRows;
          this.traineeshipType=response.dataRows[0].traineeship_type;
          this.preferredDatesList = response.preffered_dates;
          this.isCertified=this.programDetails[0].certification;
          if (response.dataRows[0].host_availability == "round_the_year") {
            this.round_the_yearselected = true;
          }
          if (response.dataRows[0].host_availability == "preferred_time_slots") {
            this.preferred_time_slotsselected = true;
          }
          this.programImages=response.url;
          this.programImages_count=response.url.length;
          this.program_countries=response.countries;
          this.carreerslistdata=response.carreers
          this.getRecentPosts(this.selectedProgramId);
          localStorage.setItem("imagescount",this.programImages_count);
           this.isCertified=this.programDetails[0].certification;
          //alert(JSON.stringify(this.programImages[0]));
          var newlist_final=[];
          var newlist;
          var array_final =[];
         for (let i = 0; i < this.programImages_count; i++) 
           {
             
             let array_list =
               { 
                 small: this.programImages[i].url_images,
                   medium: this.programImages[i].url_images, 
                   big: this.programImages[i].url_images, 
                 };
               //console.log(array_list);
               newlist =array_list;
               newlist_final[i]= newlist;
               }
               this.galleryImages=newlist_final
               },
       (err) => {
           this.errorMessage = err;
 
       });
      
  }
  getProgramViewReviews(programId)
  {
    // this.traineeshipService.getProgramViewReviews('{"Id":'+programId+',"username":"santosh.d@smartims.com","token":"cumoxebu67kswososk4socsksgg48wg","login_status":"0"}').subscribe(
      this.traineeshipService.getProgramViewReviews('{"Id":'+programId+',"username":"'+localStorage.getItem("email")+'","token":"'+localStorage.getItem("token_Id")+'","login_status":"'+localStorage.getItem("status")+'"}').subscribe(
      (response) => {
       
          this.programViewReviews=response.dataRows;
          
      },
      (err) => {
          this.errorMessage = err;

      });


  }
  getProgramViewQuestions(programId)
  {
    // this.traineeshipService.getProgramViewQuestions('{"Id":'+programId+',"username":"santosh.d@smartims.com","token":"cumoxebu67kswososk4socsksgg48wg","login_status":"0"}').subscribe(
      this.traineeshipService.getProgramViewQuestions('{"Id":'+programId+',"username":"'+localStorage.getItem("email")+'","token":"'+localStorage.getItem("token_Id")+'","login_status":"'+localStorage.getItem("status")+'"}').subscribe(
      (response) => {
        this.programViewQuestions= response.dataRows.map((q)=>{q.Flag=true; return q;})
         // this.programViewQuestions=response.dataRows;
         
      },
      (err) => {
          this.errorMessage = err;

      });


  }
  public loginDetailPage(){
    this.loginErrorMessage="";
      //alert("Welcome to details page");
      // if(!$('#testlogin').html()){
      //   this.loginErrorMessage="Please select Captcha";
      //   return;
      // }
    let request = new ProgramCreationRequest(
      this.signin.value.email,
      this.signin.value.password
        );
         this.username=
          
          {
            
          //   "username":"santosh.d@smartims.com",
       
          // "password":"FAmYzqi2wVoXIg67aariZETDn+DQwwBpyPNERw+NHOCVkAc0HsAdNAw4N+FO1gF//ZhhHWLulEM5DOXx7hzjlg=="

               "username":""+this.signin.value.email+"",
							"password":""+this.signin.value.password+""
          }
      



    // this.loginService.validateLoginUser('{"username":"santosh.d@smartims.com","password":"FAmYzqi2wVoXIg67aariZETDn+DQwwBpyPNERw+NHOCVkAc0HsAdNAw4N+FO1gF//ZhhHWLulEM5DOXx7hzjlg=="}').subscribe(
      this.traineeshipService.validateLoginUser(''+JSON.stringify(this.username)+'').subscribe(
      (response) => {
        // this.userDetails=response.dataRows;
        this.userDetails=response;
          
          localStorage.setItem("email",this.userDetails.email);
          localStorage.setItem("token_Id",this.userDetails.token)
          localStorage.setItem("status",this.userDetails.status)
          localStorage.setItem("fieldOfIntrest",this.userDetails.foi)
          localStorage.setItem("firstname", this.userDetails.firstname);
          localStorage.setItem("role",this.userDetails.role);
          localStorage.setItem("policy_check", this.userDetails.policy_check);
          localStorage.setItem("session_check", "true");
          this.loggedInUserRole=localStorage.getItem("role")
          this.loggedInUserName=localStorage.getItem("email");

        // alert(localStorage.getItem("role"));
        this.redirectPage();
        
        
      },
      (err) => {
          this.errorMessage = err;

      });
      
  }
  redirectPage(){
    this.router.navigate(['/', this.selectedProgramId, 'program-details'])
    location.reload();
  }
  programListClear(){
    sessionStorage.setItem('selectedTraineeship','');
    sessionStorage.setItem('programListIsDefault','');
  }
  getRecentPosts(id)
    {
      this.userDetails=		
    {
      "username":""+localStorage.getItem("email")+"",
      "token":""+localStorage.getItem("token_Id")+"",
      "login_status":""+localStorage.getItem("status")+"",
      "traineeship_type": ""+this.traineeshipType+"",
      "program_id":""+id+""
     
    }
      // this.isLoading = true;
       //this.traineeshipService.getLocations('{"username":"santosh.d@smartims.com"}').subscribe(
        this.traineeshipService.recentPostProgramWise(''+JSON.stringify(this.userDetails)+'').subscribe(
        (response) => {
          // this.isLoading = false;
            this.recentPost=response.dataRows;
          
										 
								
            
        },
        (err) => {
          // this.isLoading = false;
            this.errorMessage = err;
  
        });
  
    }

    OnSignIn(){
     this.loginFailureMessage="";
     console.log(this.loginFailureMessage)
      
      this.forgotResponse="";
    }

}
