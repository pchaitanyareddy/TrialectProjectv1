import { Component, OnInit,HostListener,ChangeDetectorRef ,ElementRef, ViewChild,Renderer2 } from '@angular/core';
import { Router, NavigationEnd,ActivatedRoute, } from '@angular/router';
import { TemplateNavigationComponent} from '../template/template-navigation.component';
import { TraineeshipService} from '../services/traineeship.service';
import { CommonService} from '../services/common.service';
import { NgxGalleryOptions, NgxGalleryImage, NgxGalleryAnimation } from 'ngx-gallery';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NumberValueAccessor } from '@angular/forms/src/directives';
import * as programcreationModel from '../program-creation/program-creation-classes';
declare var $: any;

export class FileModel {
  Id: number = 0;
  program_id: string;
  url: string;
  name: string;
  uploadLOIFileBase64: string;
  flag: boolean = false;
  uploadCVFileBase64: string;
  uploadrelatedFileBase64: string;
  
};
@Component({
    selector: 'app-traineeship',
    templateUrl: './program-details.component.html',
    styleUrls: ['./program-details.component.css']
  })

  export class ProgramDetailsComponent implements OnInit {
    carreerslistdata: programcreationModel.CarreersModel[] = [];
    urls = new Array<string>();
  urls1 = new Array<string>();
    allmedicationTypeList:any;
    recentPostList:any;
    reviewDetails:any;
    errorMessage:any;
    programDetails:any;
    programViewReviews:any;
    uploadedFileListdata:any;
    programViewQuestions:any;
    countryList:any;
    fileCountCV:any;
    countryName:any;
    fileCountLOI:any;
    clicked = false;
    uploadedFileRelatedListdata:programcreationModel.FileModel[]=[];
    public preferredDatesList: programcreationModel.preffered_datesmodel[] = [];
    traineeshipType:any;
    selectedCountry:string;
    selectedCountryToApply:string;
    isCertified:string;
    title:string;
    userDetails:any;
    appUrl:string;
    loggedInUserRole:string;
    loggedInUserName:string;
    programImages:any;
    programImages_count:any;
    program_countries:any;
    agreementCheck:boolean;
    termsCheck:boolean;
    galleryOptions: NgxGalleryOptions[];
    galleryImages: NgxGalleryImage[];
    checkModel:boolean;
    uploadLOIErrorMessage:any;
    uploadCVErrorMessage:any;
    checkTerms:boolean=false;
    uploadCVFileBase64:string;
    applyingform:any;
    askQuestionForm:any;
    searchQAText:string="";
    CVfileFormat:any;
    reviewId:any;
    uploadrelatedFileBase64:string;
    relatedfileFormat:any;
    askQuestionFormEdit:any;
    reviewEditForm:any;
    uploadLOIFileBase64:string;
    LOIfileFormat:any;
    submitApplicationForm:any;
    askQuestionRequest:any;
    userID:any;
    selectedCountryId:number;
    applyingFormList:any;
    errorMsgData:string;
    selectedProgramType:string;
    programWiseLogistics:any=[];
    merit_cost_week:any;
    selectedPriorityWeek1;
    sponsor_week:any;
    merit_cost:any;
    sponsor:any;
    priorityWeekCost:any;
    applyErrorMessage:string="";
    actualCost:any;
    priority_merit_weeks:any;
    priorityWeekCostApply:any;
   selectedProgramId='';
   selectedWeek:number;
   isLoading:boolean;
   submitted = false;
   selectedPriorityWeek:any;
   IsHeaderCover:boolean=false;
   round_the_yearselected: boolean = false;
   preferred_time_slotsselected: boolean = false;
   certificationsScoll:any;
   questionAskedit:any;
   questionEditId:any;
   selectedPriorityWeekApply:any;
   answeraskedit:any;
   dataLoad:boolean=false;
   reviewComment:any;
   reviewGood:any;
   reviewImprovement:any;
   reviewImage:any;
   reviewImageId:any;
   emailstring:any;
   emailstringFacebook:any;
   emailstringTwitter:any;
   emailstringLinkedIn:any;
   emailstringGmail:any;
   title1:any;
   title2:any;
  phonenumber2:any;
  phonenumber1:any;
  //  selectedPriorityWeek={};
    @ViewChild('fileInput') fileInput: ElementRef ;
    @ViewChild('fileInputLOI') fileInputLOI: ElementRef;
     @HostListener('window:scroll', ['$event']) 
      doSomething(event) {
        if(window.pageYOffset>2){
          document.querySelector('.details-nav').classList.add('scrollTop');
          // document.querySelector('.program-detail-breif-right').classList.add('scrollTopRight');
        }
        else{
          document.querySelector('.details-nav').classList.remove('scrollTop');
          // document.querySelector('.program-detail-breif-right').classList.remove('scrollTopRight');
        } 
  }
    constructor(private router: Router,
      private route: ActivatedRoute,
      private traineeshipService:TraineeshipService,
      private changeDetectorRef: ChangeDetectorRef,
      private formBuilder: FormBuilder,
      private elRef:ElementRef,
      private renderer: Renderer2) {
        
       }
    
    ngOnInit() {
      $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip();   
      });
      this.loggedInUserName=localStorage.getItem("firstname");
      this.loggedInUserName=localStorage.getItem("email")
      this.appUrl= CommonService.APP_URL;
    //  $('#checkAgree')
      window.scrollTo(0,0);
      this.askQuestionForm=this.formBuilder.group({
        questionAsk:[],
      })
      this.askQuestionFormEdit=this.formBuilder.group({
        questionAskedit:[],
        answeraskedit:[]
      })
      this.reviewEditForm=this.formBuilder.group({
        reviewComment:[],
        reviewGood:[],
        improvement:[]
      })
      this.applyingform = this.formBuilder.group({
        applicantName:['',Validators.required],
        age:['',Validators.required],
        gender:['',Validators.required],
        affiliation1:['',Validators.required],
        // title1:['',Validators.required],
        Name1:['',Validators.required],
        email1:['',[Validators.required, Validators.email,Validators.pattern('[a-zA-Z0-9.-]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,4}')]],
        // phonenumber1:['',Validators.required],
        affiliation2:['',Validators.required],
        // title2:['',Validators.required],
        Name2:['',Validators.required],
        email2:['',[Validators.required, Validators.email,Validators.pattern('[a-zA-Z0-9.-]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,4}')]],
        country:['',Validators.required],
        // phonenumber2:['',Validators.required],
        applicantEmail:['',[Validators.required, Validators.email,Validators.pattern('[a-zA-Z0-9.-]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,4}')]]
        
        

      })

     
      
      this.route.params.subscribe(params => {
        this.selectedProgramId = params['id'];
        
        
    });
 
    // if(this.loggedInUserName==null){
    //   this.router.navigate(['/', this.selectedProgramId, 'program-details-brief'])
    // }
    this.galleryOptions = [
      {
          width: '900px',
          height: '500px',
          thumbnailsColumns: 8,
          imageAnimation: NgxGalleryAnimation.Slide
      },
      // max-width 800
      {
          breakpoint: 800,
          width: '100%',
          height: '600px',
          imagePercent: 80,
          thumbnailsPercent: 20,
          thumbnailsMargin: 20,
          thumbnailMargin: 20
      },
      // max-width 400
      {
          breakpoint: 400,
          preview: false
      }
  ];

  

      
      this.getProgramView(this.selectedProgramId);
      this.getProgramViewReviews(this.selectedProgramId);
      this.getProgramViewQuestions(this.selectedProgramId);
      this.getLocations();
      this.getProgramWiseLogistics(this.selectedProgramId);
      
      //alert(localStorage.getItem("imagescount"));
    let finalCount=localStorage.getItem("imagescount");
    
    }
    
  
    get f() { return this.applyingform.controls; }
    public ngAfterViewInit(): void {        
    
      this.loggedInUserRole=localStorage.getItem("role")
      this.loggedInUserName=localStorage.getItem("email")
      this.userID=localStorage.getItem("userId")
      

      //$("#stickysidebarscroll").offset({"top":140,"bottom":1580});
      $("#stickysidebarscroll",{offset: {top:140, bottom:1580}});
      if($('#checkAgree').val()==true){
        this.agreementCheck=true;
      }
      else{
        this.agreementCheck=false
      }
    }
     moveScroll(el: HTMLElement){
    var top = el.offsetTop;
    //el.scrollTop = 400;
    //el.scroll(0, 200);
    // el.scroll({
    //   top: top,
    //   behavior: 'smooth'
    // });
   el.scrollIntoView();
  }

    getLocations()
  {
    this.isLoading=true;
    this.userDetails=		
      {
        "username":""+localStorage.getItem("email")+"",
        "token":""+localStorage.getItem("token_Id")+"",
        "login_status":""+localStorage.getItem("status")+"",
       
      }
      this.traineeshipService.getLocations(''+JSON.stringify(this.userDetails)+'').subscribe(
      (response) => {
       this.isLoading=false;
          this.countryList=response.dataRows;
          
      },
      (err) => {
        this.isLoading=false;
          this.errorMessage = err;

      });

  }
  check(){
    $(".faq-div").show();
    $('#myModalLabel2').html("<strong>Questions & Answers.</strong>");
    $('#faqflag').val("individual");
    $('#programid').val(this.selectedProgramId); 
    $('#searchfield').val("");
    $('#loadFAQ').click();
  }
  otherPostClick(ProgramId){

    this.router.navigate(['/',ProgramId,'program-details'])
    location.reload();
  }
  getProgramRecentPosts(programtype){
    this.isLoading=true;
    this.userDetails=		
      {
        "traineeship_type":""+programtype+"",
        "username":""+localStorage.getItem("email")+"",
        "token":""+localStorage.getItem("token_Id")+"",
        "login_status":""+localStorage.getItem("status")+"",
        "Id":""+this.selectedProgramId+"",      
      }
      this.traineeshipService.recentPostProgramWise(''+JSON.stringify(this.userDetails)+'').subscribe(
      (response) => {
       this.isLoading=false;
          this.recentPostList=response.dataRows;
          
      },
      (err) => {
        this.isLoading=false;
          this.errorMessage = err;

      });

  }
  onChange(selectedValue)
  {
    this.selectedCountryId=selectedValue;
    

  }
  onChangeCountryApply(selectedValue)
  {
    this.selectedCountryToApply=selectedValue;
 
  // alert(this.countryList.filter(m=>m.selectedValue).map(n=>n.text))
  // alert(this.countryList.filter(x => x.selectedValue).map(y => y.text)) 
  for (var i = 0; i < this.countryList.length; i++) {
    if (this.countryList[i].id == selectedValue) {
      this.countryName= this.countryList[i].text;
    }
}

  }
  onChangeCheckbox($event) {
    this.checkModel = $event.target.checked;
  }
  onChangetermsCheckbox($event) {
    this.checkTerms = $event.target.checked;
  }

  searchQA(qa){
    this.programViewQuestions.forEach(srch => {
      srch.Flag = (srch.question.indexOf(qa) > -1 || srch.answer.indexOf(qa) > -1);
    });  
  }

    getProgramView(programId)
    {
      this.isLoading=true;
        this.traineeshipService.getProgramView('{"Id":'+programId+',"username":"'+localStorage.getItem("email")+'","token":"'+localStorage.getItem("token_Id")+'","login_status":"'+localStorage.getItem("status")+'"}').subscribe(
        (response) => {
          this.isLoading=false;
         if(response.message=="No data found"){
           this.router.navigate(['**'], { skipLocationChange: true });
         }
         else{
            this.programDetails=response.dataRows;
            this.emailstring='mailto:test@example.com?Subject= Trialect : Trainee Fellowships Program&body= Program Name:'+this.programDetails[0].program_name +'%0D https://beta.trialect.com/#/'+this.programDetails[0].id+'/program-details';
            this.emailstringFacebook='http://www.facebook.com/share.php?u=https://beta.trialect.com/%23%2F'+this.programDetails[0].id+'/program-details&title='+this.programDetails[0].program_name;
            this.emailstringTwitter='http://twitter.com/share?text='+this.programDetails[0].program_name+'&url=https://beta.trialect.com/%23/'+this.programDetails[0].id+'/program-details %0D';
            this.emailstringLinkedIn='http://www.linkedin.com/shareArticle?mini=true&url=https://beta.trialect.com/%23%2F'+this.programDetails[0].id+'/program-details';
            this.emailstringGmail='https://plus.google.com/share?url=https://beta.trialect.com/%23%2F'+this.programDetails[0].id+'/program-details';
            // https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fwww.google.com&title=This+is+google+a+search+engine
            this.carreerslistdata = response.carreers;
            this.errorMsgData=response.message;
           this.programImages=response.url;
           this.programImages_count=response.url.length;
           this.program_countries=response.countries;
           this.preferredDatesList = response.preffered_dates;
           if (response.dataRows[0].host_availability == "preferred_time_slots") {
            this.preferred_time_slotsselected = true;
          }
  
          if (response.dataRows[0].host_availability == "round_the_year") {
            this.round_the_yearselected = true;
          }
           localStorage.setItem("imagescount",this.programImages_count);
           this.traineeshipType=response.dataRows[0].traineeship_type;
           this.getProgramRecentPosts(this.traineeshipType)
            this.isCertified=this.programDetails[0].certification;
           
           var newlist_final=[];
           var newlist;
           var array_final =[];
          for (let i = 0; i < this.programImages_count; i++) 
            {
              
              let array_list =
                { 
                  small: this.programImages[i].url_images,
                    medium: this.programImages[i].url_images, 
                    big: this.programImages[i].url_images, 
                  };
                //console.log(array_list);
                newlist =array_list;
                newlist_final[i]= newlist;
                }
                this.galleryImages=newlist_final
                 this.dataLoad=true;

                 
                }
              },
        (err) => {
          this.isLoading=false;
          this.dataLoad=true;

            this.errorMessage = err;
  
        });
    }
    getProgramViewReviews(programId)
    {this.isLoading=true;
      this.traineeshipService.getProgramViewReviews('{"Id":'+programId+',"username":"'+localStorage.getItem("email")+'","token":"'+localStorage.getItem("token_Id")+'","userid":"'+localStorage.getItem("userId")+'","login_status":"'+localStorage.getItem("status")+'"}').subscribe(
        (response) => {
          this.isLoading=false;
            this.programViewReviews=response.dataRows;
            
        },
        (err) => {
          this.isLoading=false;
            this.errorMessage = err;
  
        });


    }
    getProgramViewQuestions(programId)
    {
      this.isLoading=true;
      this.traineeshipService.getProgramViewQuestions('{"Id":'+programId+',"username":"'+localStorage.getItem("email")+'","token":"'+localStorage.getItem("token_Id")+'","login_status":"'+localStorage.getItem("status")+'"}').subscribe(
        (response) => {
          this.isLoading=false;
          this.programViewQuestions= response.dataRows.map((q)=>{q.Flag=true; return q;})
        },
        (err) => {
          this.isLoading=false;
            this.errorMessage = err;
  
        });


    }
    getProgramWiseLogistics(programId)
    {
      this.isLoading=true;
      this.traineeshipService.ProgramBasedLogistics('{"id":'+programId+',"username":"'+localStorage.getItem("email")+'","token":"'+localStorage.getItem("token_Id")+'","login_status":"'+localStorage.getItem("status")+'"}').subscribe(
        (response) => {
          this.isLoading=false;
            this.programWiseLogistics=response.dataRows;
            if (this.programWiseLogistics && this.programWiseLogistics.length > 0){
            var logisticsData = this.programWiseLogistics[0];
            this.merit_cost_week = logisticsData.merit_cost_week;
            this.sponsor_week = logisticsData.sponsor_week;
            this.selectedPriorityWeek= logisticsData.priority_merit_weeks;
            this.selectedPriorityWeek1=logisticsData.priority_merit_weeks;
        }
          this.onChangeWeek(this.selectedPriorityWeek);
this.onChangeWeekApply(this.selectedPriorityWeek1);
        },
        (err) => {
          this.isLoading=false;
            this.errorMessage = err;
  
        });


    }


  onChangeWeek(item: number) {
    {
      
      if (item && item > 0) {
        var filteredArray = this.programWiseLogistics.filter(f => f.priority_merit_weeks == item);

        if (filteredArray.length) {
          var value = filteredArray[0];
          this.priority_merit_weeks = value.priority_merit_weeks;
          //this.priorityWeekCost=item.priority_merit_cost;
          this.actualCost = value.priority_merit_cost;
          // this.priorityWeekCost = value.priority_merit_cost - value.priority_merit_discount;
          this.priorityWeekCost = value.priority_merit_discount;
        }
      }else{
          this.priority_merit_weeks = '';
          //this.priorityWeekCost=item.priority_merit_cost;
          this.actualCost = '';
          this.priorityWeekCost = '';
        }
    }
  }
  onChangeWeekApply(item: number) {
    {
      
      if (item && item > 0) {
        var filteredArray = this.programWiseLogistics.filter(f => f.priority_merit_weeks == item);

        if (filteredArray.length) {
          var value = filteredArray[0];
          this.priority_merit_weeks = value.priority_merit_weeks;
          //this.priorityWeekCost=item.priority_merit_cost;
          this.actualCost = value.priority_merit_cost;
          this.priorityWeekCostApply = value.priority_merit_cost - value.priority_merit_discount;
        }
      }else{
          this.priority_merit_weeks = '';
          //this.priorityWeekCost=item.priority_merit_cost;
          this.actualCost = '';
          this.priorityWeekCostApply = '';
        }
    }
  }
    applyFormData(){
     
      this.clicked = true;
    //  alert("uploadCVFileBase64 "+ this.uploadCVFileBase64);
    //  alert("uploadLOIFileBase64 "+ this.uploadLOIFileBase64);
    //  alert("uploadedFileRelatedListdata "+ this.uploadedFileRelatedListdata);
    //  alert(this.uploadrelatedFileBase64==null)
     this.applyErrorMessage="";
   
      this.submitted = true;
      this.isLoading=true;
 
      this.IsHeaderCover = false;

      // if(this.applyingform.value.isSponsership==true){
      //   this.applyingform.value.isSponsership=true
        

      // }
      // else if(this.applyingform.value.isSponsership==null || this.applyingform.value.isSponsership==undefined){
       
      //   this.applyingform.value.isSponsership=false
      // }

      // if(this.uploadCVFileBase64==""|| this.uploadCVFileBase64==undefined){
      //   this.uploadCVFileBase64=""

      // }
      //  if(this.uploadLOIFileBase64==""|| this.uploadLOIFileBase64==undefined){

      //   this.uploadLOIFileBase64=""

      // }
      //  if(this.uploadrelatedFileBase64==""|| this.uploadrelatedFileBase64==undefined){
      //   this.uploadrelatedFileBase64=""

      // }
      if(this.selectedCountryToApply==""|| this.selectedCountryToApply==undefined){
        this.selectedCountryToApply=""

      }
      let selectedCountry=$("#ddlCountry option:selected").text();
   
      this.submitApplicationForm=
      {
        "program_id":this.selectedProgramId,
        "user_id":localStorage.getItem("userId"),
        "name":this.applyingform.value.applicantName,
        "dob":this.applyingform.value.age,
        "gender":this.applyingform.value.gender,
        "country_name":this.countryName,
        "country":this.selectedCountryToApply,
        "cv_url":this.uploadCVFileBase64,
        // "cvFileFormat":this.CVfileFormat,
        "loi_url":this.uploadLOIFileBase64,
        // "loiFileFormat":this.LOIfileFormat,
        "other_url":this.uploadedFileRelatedListdata,
        // "otherFileformat":this.relatedfileFormat,
        "ref1_name":this.applyingform.value.Name1,
        "ref2_name":this.applyingform.value.Name2,
        "ref1_aff":this.applyingform.value.affiliation1,
        "ref2_aff":this.applyingform.value.affiliation2,
        "ref1_title":$('#title1').val(),
        "ref2_title":$('#title2').val(),
        "ref1_email":this.applyingform.value.email1,
        "ref2_email":this.applyingform.value.email2,
        "ref1_phone":$('#phonenumber1').val(),
        "ref2_phone":$('#phonenumber2').val(),
        "ishavingSponser":this.applyingform.value.isSponsership,
        "username":localStorage.getItem("email"),
        "token":localStorage.getItem("token_Id"),//"3vuamdaytkg0o4w4ooosk400g8kcosk",
        "login_status": localStorage.getItem("status"),
        "email":this.applyingform.value.applicantEmail,
        "week":this.selectedPriorityWeek1,
        "cost":this.priorityWeekCostApply
       
      }
      //alert(JSON.stringify(this.submitApplicationForm));
      
     
      //  else if(this.uploadrelatedFileBase64==null|| this.uploadrelatedFileBase64==undefined){
      //   this.isLoading=false;
   
      //   this.applyErrorMessage="Please upload relavent documents";
      //   alert("Please upload relavent documents");
      //   return;
      // }
       if (this.applyingform.invalid) {
        this.isLoading=false;
        this.clicked = false;
        alert(
          "Please fill all the details correctly"
        );
        
        setTimeout(function() {
          $('#Applynow').scrollTop(0,0);
         }, 30);
       
        return;
    }
    else if(this.uploadCVFileBase64==""|| this.uploadCVFileBase64==undefined || this.fileCountCV<1){
      this.isLoading=false;
      
      this.uploadCVErrorMessage="Please upload CV";
      alert("Please upload CV");
      this.clicked = false;
    
      return;

    }
     else if(this.uploadLOIFileBase64==""|| this.uploadLOIFileBase64==undefined|| this.fileCountLOI<1){
      this.isLoading=false;

      this.uploadLOIErrorMessage="Please upload LOI ";
      alert("Please upload LOI");
      this.clicked = false;
      return;
    }
    else if(!$('#programDetailSection').html()){
      this.clicked = false;
      this.applyErrorMessage="Please select Captcha";
			return;
     }

   else if((this.applyingform.value.applicantEmail==this.applyingform.value.email1)){
      this.isLoading=false;
      this.clicked = false;
        this.applyErrorMessage="Applicant email ID should be different from reference emails ";
        alert("Applicant email ID should be different from reference emails");
        return;
      }
      else if(this.applyingform.value.email1==this.applyingform.value.email2){
        this.isLoading=false;
        this.clicked = false;
        this.applyErrorMessage="Reference email ID should be different from other reference email ID ";
        alert("Applicant email ID should be different from reference emails");
        return;
      }
      else if(this.applyingform.value.applicantEmail==this.applyingform.value.email2){
        this.isLoading=false;
        this.clicked = false;
        this.applyErrorMessage="Applicant email ID should be different from reference emails ";
        alert("Applicant email ID should be different from reference emails");
        return;
      }
    
  else{
    // alert("else");
      this.traineeshipService.applyingForm(''+JSON.stringify(this.submitApplicationForm)+'').subscribe(
        (response) => {
          this.isLoading=false;
          this.clicked = false;
            this.applyingFormList=response.dataRows;
            // alert(response.message)
            $("#ApplyNow .close").click();
            if(response.message=="Application recieved and an email has been sent"){
              
            $("#ApplyThankyou").modal('show');
            this.applyingform.reset();
            this.uploadLOIFileBase64="";
            this.uploadCVFileBase64="";
            this.uploadedFileRelatedListdata=[];
            this.fileInput.nativeElement.value = "";
            this.fileInputLOI.nativeElement.value="";
            $('#title1').val("");
            $('#title2').val("");
            $('#phonenumber2').val("");
            $('#phonenumber1').val("");
	    this.submitted=false;
            this.uploadCVErrorMessage="";
            this.uploadLOIErrorMessage="";
              // Object.keys(this.applyingform.controls).forEach(key => {
              //   this.applyingform.controls[key].setErrors(null)
              // });
           }
           else{
            this.clicked = false;
             alert(response.message)
           }
            // $("#Thankyou").modal('show');
        },
        (err) => {
          this.clicked = false;
          this.isLoading=false;
            this.errorMessage = err;
  
        });



    }
  }
    onFileChange(event) {
      this.uploadCVErrorMessage=""
      let reader = new FileReader();
     this.fileCountCV=event.target.files.length
      if(event.target.files &&this.fileCountCV > 0) {
        let file = event.target.files[0];
        reader.readAsDataURL(file);
        reader.onload = () => {
          
          // this.applyingform.get('UploadCV').setValue({
          //   filename: file.name,
          //   filetype: file.type,
          //  value: reader.result.toString().split(',')[1]
            
          // })
          this.CVfileFormat=file.type
          this.uploadCVFileBase64=reader.result.toString().split(',')[1]
          this.uploadCVErrorMessage="";
        };
      }
    }
    onFileChangeLOI(event) {
      this.uploadLOIErrorMessage="";
      let reader = new FileReader();
     this.fileCountLOI=event.target.files.length;
      if(event.target.files && event.target.files.length > 0) {
        let file = event.target.files[0];
        reader.readAsDataURL(file);
        reader.onload = () => {
          
          // this.applyingform.get('UploadCV').setValue({
          //   filename: file.name,
          //   filetype: file.type,
          //  value: reader.result.toString().split(',')[1]
            
          // })
          this.LOIfileFormat=file.type
          this.uploadLOIFileBase64=reader.result.toString().split(',')[1];
          this.uploadLOIErrorMessage="";
        };
      }
    }
    // onFileChangeRelated(event) {
    //   let reader = new FileReader();
     
    //   if(event.target.files && event.target.files.length > 0) {
    //     let file = event.target.files[0];
    //     reader.readAsDataURL(file);
    //     reader.onload = () => {
          
    //       // this.applyingform.get('UploadCV').setValue({
    //       //   filename: file.name,
    //       //   filetype: file.type,
    //       //  value: reader.result.toString().split(',')[1]
            
    //       // })
    //       this.relatedfileFormat=file.type
    //       this.uploadrelatedFileBase64=reader.result.toString().split(',')[1]
    //     };
    //   }
    // }


    onFileChangeRelated(event) {
      let reader = new FileReader();
  
      if (event.target.files && event.target.files.length > 0) {
        for (var i: number = 0; i < event.target.files.length; i++) {
          let reader = new FileReader();
  
          let file = event.target.files[i];
        reader.readAsDataURL(file);
        reader.onload = (e: any) => {
  
          // this.applyingform.get('UploadCV').setValue({
          //   filename: file.name,
          //   filetype: file.type,
          //  value: reader.result.toString().split(',')[1]
  
          // })
          this.relatedfileFormat = file.type
          this.uploadrelatedFileBase64 = reader.result.toString().split(',')[1];
          this.urls.push(e.target.result);
          this.urls1.push(reader.result.toString().split(',')[1]);
          var relatedbase64data = reader.result.toString().split(',')[1];
          //  console.log console.log(this.uploadLOIFileBase64);
          var uploadedRelatedFiledata: programcreationModel.FileModel = new  programcreationModel.FileModel();
  
          uploadedRelatedFiledata.uploadrelatedFileBase64 = relatedbase64data;
          uploadedRelatedFiledata.name = file.name;
          if (this.uploadedFileRelatedListdata == null) {
            uploadedRelatedFiledata.id = -1;
            this.uploadedFileRelatedListdata = [];
          } else if (this.uploadedFileRelatedListdata != null && this.uploadedFileRelatedListdata.length > 0) {
            var min: number = 0;
            this.uploadedFileRelatedListdata.forEach(element => {
              if (min > element.id) {
                min = element.id;
              }
            });
            uploadedRelatedFiledata.id = min;
          }
          this.uploadedFileRelatedListdata.push(uploadedRelatedFiledata);
  
  
  
        };
      }
      } else {
        event.srcElement.value = null;
      }
    }
    onApply(){
  
      this.IsHeaderCover=true;

    }
    // onTerms(){
    //   this.IsHeaderCover=false;

    // }

    fileremove(file: programcreationModel.FileModel, index): void {

      if (file.id < 1) {
        this.uploadedFileRelatedListdata.splice(index, 1);
        if (this.uploadedFileRelatedListdata.length < 1)
          this.fileInput.nativeElement.value = "";
  
        // if (this.myInput.nativeElement.files && this.myInput.nativeElement.files.length > 0) {
        //   for (var i: number = 0; i < this.myInput.nativeElement.files.length; i++) {
        //     var filesss = this.myInput.nativeElement.files;
        //     console.log();
        //     // this.myInput.nativeElement.files.forEach((element, i) => {
        //       this.uploadedFileListdata.forEach(fileelement => {
        //         if (fileelement.name == this.myInput.nativeElement.files[i].name) {
        //          // this.myInput.nativeElement.files.splice(i, 1);
        //           this.myInput.nativeElement.files.slice(i, 1);
  
        //         }
        //       });
  
        //     // });
        //     //  this.uploadedFileListdata.splice(index, 1);
        //   }
        //}
      }
  
      else {
        file.flag = true;
        // console.log(this.fileInput.nativeElement.files);
        // this.myInput.nativeElement.value = "";
        this.uploadedFileRelatedListdata.forEach(fileelement => {
          if (fileelement.imagename == file.imagename) {
            fileelement.flag = true;
          }
        });
       
      }
  
  
    }

    askQuestion(){
    

        this.traineeshipService.askQuestion('{"program_id":'+this.selectedProgramId+',"username":"'+localStorage.getItem("email")+'","token":"'+localStorage.getItem("token_Id")+'","category":"individual","question":"'+this.askQuestionForm.value.questionAsk+'","answer":"","id":"","login_status":"'+localStorage.getItem("status")+'"}').subscribe(
          (response) => {
            this.isLoading=false;
            this.getProgramViewQuestions(this.selectedProgramId);
              
           
             
          },
          (err) => {
            this.isLoading=false;
              this.errorMessage = err;
    
          });

    }
    OnClose(){
      
    }
    /* To copy any clip board */
copyText(val: string){
  let selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = val;
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
  }
  programListClear(){
    sessionStorage.setItem('selectedTraineeship','');
    sessionStorage.setItem('programListIsDefault','');
  }

  askQuestionedit(id,question){
    this.questionAskedit=question;
    this.questionEditId=id;


  }
  askQuestionUpdate(){
    this.traineeshipService.askQuestionUpdate('{"program_id":'+this.selectedProgramId+',"username":"'+localStorage.getItem("email")+'","token":"'+localStorage.getItem("token_Id")+'","category":"individual","question":"'+this.questionAskedit+'","answer":"'+this.answeraskedit+'","id":"'+this.questionEditId+'","login_status":"'+localStorage.getItem("status")+'"}').subscribe(
      (response) => {
        this.isLoading=false;
          // alert(response.message)
          this.getProgramViewQuestions(this.selectedProgramId);
         
      },
      (err) => {
        this.isLoading=false;
          this.errorMessage = err;

      });
  }
  approveImage(id){

    this.traineeshipService.reviewImagesAprove('{"program_id":'+this.selectedProgramId+',"username":"'+localStorage.getItem("email")+'","token":"'+localStorage.getItem("token_Id")+'","id":"'+id+'","login_status":"'+localStorage.getItem("status")+'"}').subscribe(
      (response) => {
        this.isLoading=false;
           alert(response.message)
          // this.getProgramViewQuestions(this.selectedProgramId);
         
      },
      (err) => {
        this.isLoading=false;
          this.errorMessage = err;

      });

  }
  deleteImage(id,i){


    this.traineeshipService.reviewImagesDelete('{"program_id":'+this.selectedProgramId+',"username":"'+localStorage.getItem("email")+'","token":"'+localStorage.getItem("token_Id")+'","id":"'+id+'","login_status":"'+localStorage.getItem("status")+'"}').subscribe(
      (response) => {
        this.isLoading=false;
           alert(response.message)
          // this.getProgramViewQuestions(this.selectedProgramId);
         
      },
      (err) => {
        this.isLoading=false;
          this.errorMessage = err;

      });
  }
  ReviewEdit(id,good,comment,improvement,file){
    this.reviewId=id;
    this.reviewGood=good;
    this.reviewComment=comment;
    this.reviewImprovement=improvement;
    this.uploadedFileListdata=file;
    // this.reviewImage=image.url;
    // this.reviewImageId=image.id;


  }
  checkStatus(){
    this.checkTerms=false;
    this.submitted=false;
    $('#Non-Cir').modal('hide')
    $('#ApplyNow').modal('show')
    // Object.keys(this.applyingform.controls).forEach(key => {
    //   this.applyingform.controls[key].setErrors(null)
    // });
  }
  OnProgramedit(PrograType: any, ProgramId: number): void {
  
    this.router.navigate(['/', 'program-creation-data', ProgramId, PrograType])
      //this.router.navigate(['program-creation-data'])
    }


    reviewUpdate(){
      this.reviewDetails=		
      {
        "program_id":""+this.selectedProgramId+"",
        "username":""+localStorage.getItem("email")+"",
        "token":""+localStorage.getItem("token_Id")+"",
        "login_status":""+localStorage.getItem("status")+"",
        "id":""+this.reviewId+"",
        "experience":this.reviewGood,
        "improvemts":this.reviewImprovement,
        "comments" :this.reviewComment     
      }
      this.traineeshipService.reviewAprove(''+JSON.stringify(this.reviewDetails)+'').subscribe(
      // this.traineeshipService.reviewAprove('{"program_id":'+this.selectedProgramId+',"username":"'+localStorage.getItem("email")+'","token":"'+localStorage.getItem("token_Id")+'","id":"'+this.reviewId+'","login_status":"'+localStorage.getItem("status")+'"}').subscribe(
        (response) => {
          this.isLoading=false;
        alert(response.message)
            // this.getProgramViewQuestions(this.selectedProgramId);
           
        },
        (err) => {
          this.isLoading=false;
            this.errorMessage = err;
  
        });
    }
    exploreTrianeeship(){
      sessionStorage.setItem("selectedTraineeship",'');
    }
    removeDarkness(){
      $("#Non-Cir .close").click();
    }
    showPopup(){
      $('#openShareLinks').show();
    }
    hidepopup(){
      $('#openShareLinks').hide();
    }
  }