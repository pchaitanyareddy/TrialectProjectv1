import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProgramGrantsCreationComponent } from './program-grants-creation.component';

describe('ProgramGrantsCreationComponent', () => {
  let component: ProgramGrantsCreationComponent;
  let fixture: ComponentFixture<ProgramGrantsCreationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProgramGrantsCreationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProgramGrantsCreationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
