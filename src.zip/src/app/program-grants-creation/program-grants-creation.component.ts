import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, ViewChild, ElementRef } from '@angular/core';
import { IMyInputFieldChanged, IMyOptions, IMyDateModel } from 'mydatepicker';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { CommonService } from '../services/common.service';
import { TraineeshipService } from '../services/traineeship.service';
import { Select2OptionData } from 'ng2-select2';
import { Router, NavigationEnd, ActivatedRoute, } from '@angular/router';
import * as programcreationModel from '../program-creation/program-creation-classes';
import { NgxGalleryOptions, NgxGalleryImage, NgxGalleryAnimation } from 'ngx-gallery';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import * as AppModel from '../shared/shared-classes';
import * as AppMethodModel from '../shared/shared-methods';

@Component({
  selector: 'app-program-grants-creation',
  templateUrl: './program-grants-creation.component.html',
  styleUrls: ['./program-grants-creation.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProgramGrantsCreationComponent implements OnInit {

  nextClicked=false;
  galleryOptions: NgxGalleryOptions[];
  imageSrc: string;
  minDate:Date;
  galleryImages: NgxGalleryImage[];
  merit_cost: string = '';
  sponsor: string = '';
  ParentName: any;
  countryName:any;
  selectedTraineeshipType: string;
  Programid: number;
  traineeship_type: any;
  ContractstartDateOptions: any;
  selectedAll: boolean = false;
  merit_cost_week: string = "";
  sponsor_logo_check:boolean=true;
  sponsor_logo_image:any;
  programDetails: any;
  hostAvailability: string = 'round_the_year';
  //uploadLOIFileBase64: string[];
  uploadedFileListdata: programcreationModel.FileModel[];
  sponsor_logo: string;
  displayImage:string;
  PriorityMeritListData: programcreationModel.PriorityMeritmodel[];
  priority_merit_cost: any;
  trialect_email:any;
  appUrl: string;
  public exampleData: Array<Select2OptionData>;
  //public exampleData: Array<Select2OptionData>;
  public options: Select2Options;
  priorityWeekCost: any;
  public value: any;
   tempcareerLevelList: any = []
  //urls = [];
  fileNames = [];
  urlsForLogo = [];
  word: string;
  //name = 'ng2-ckeditor';
  ckeConfig: any;
  mycontent: string;
  log: string = '';
  submitCreationRequest: any;
  errorMessage: any;
  allCreationList: any;
  certification_type: string;
  typeOfProgram: string;
  selectedCountry: string;
  selectedCountryId: any;
  userDetails: any;
  countryList: any;
  public countryListData: Array<Select2OptionData>;
  careerLevelList: any;
  certification: boolean;
  certificationShow:boolean;
  nGGrants: boolean = false;
  nPGrants: boolean = false;
  nGGrantsData: string;
  nPGrantsData: string;
  careerSelected: string;
  public current: string;
  public current1: string;
  isOnlineTraineeShip: boolean;
  isOnlineMentorship: boolean;
  isOnsitetraineeship: boolean;
  actualCost:any;
  isLoading: boolean;
  programImages: any;
  programImages_count: any;
  isCertified: string;
  errorMsgData: string;
  top_bas_translational: any;
  top_clinical_traineeship: any;
  top_clinical_res_traineeship: any;
  top_bas_translationalchecked: boolean=false;
  top_clinical_res_traineeshipchecked: boolean=false;
  top_clinical_traineeshipchecked: boolean=false;
  top_translationalchecked: boolean=false;
  top_translational: any;
  profession_doctor: any;
  profession_biomedical: any;
  profession_doctorchecked: boolean=false;
  profession_biomedicalchecked: boolean=false;
  created_date: any;
  programPreviewDetails: any;
  @ViewChild("myckeditor") ckeditor: any;
  @ViewChild('myInput') myInput: ElementRef;
  public uploadImage = '';
  public uploadImageBase64: string;
  public creationstep1: FormGroup;
  public publishDateCalanderForm:FormGroup;
  public questionsList: FormArray;
  // public questionArray: programcreationModel.QuestionsModel[] = [];
  public questionArray: programcreationModel.QuestionsModel[] = [];
  public QAquestionArray: any;
  public RemoveQuestionVisible:boolean=false;
  public preferredDatesList: programcreationModel.preffered_datesmodel[] = [];
  public careerArray: programcreationModel.careermodel[] = [];
  public program_carrers: any[] = [];
  programCreationExtraList: any;
  programEditDetails: any;
  publishProgramDetails:any;
  name: any = 'Angular 4';
  urls: any = [];
  reponseId: number;
  hostmailResponse:any;
  no_of_sessions: any;
  duration_of_sessions: any;
  applicants_count: any;
  contract_startdate_format:any;
  total_spots: any;
  brief_description: any;
  host_email: any;
  website_link: any;
  host_affiliation: any="It is mandatory that all applicants carry workplace liability insurance, e.g., https://www.protrip-world-liability.com (Erasmus students use this package and typically costs around 5  €   per month - please check) in addition to health insurance when you join any of the onsite Trialect partnered fellowships ";
  funding_amount1:any;
  funding_amount2:any;
  funding_amount3:any;
  non_profit_grants: any;
  nih_grants: any;
  contract_startdate: any;
  publish_startdate:any;
  contract_enddate: any;
  contract_startdate_local: any = "";
  contract_enddate_local: any;
  noOfYearsContract: any;
  full_description: any;
  years_of_contract: any;
  course_link: any;
  accommodation: any;
  curriculumn: any;
  techniques: any;
  feature1: any="Collaboration";
  feature2: any="International";
  feature3: any="Early Career";
  feature4: any="Preliminary Data Ideal";
  feature5: any="Telephone Support";
  feature6: any="Results Transparency";
  eligibility_criteria: any;
  public currentcountry: string;
  selectedcountries: string;
  position: string;
  specificfields: any;
  status:any;
  specialty: any;
  specality:any;
  trainer_name: any;
  trainer_name_check: any;
  department_name: string;
  hospital_name: string;
  address: string;
  trainer_country_id: string;
  trainer_country_name: string;
  programPreviewLogisticData: any;
  programPreviewQuestion: any;
  programPreviewindividualquestions: any;
  programPreviewCareer: any;
  program_name: string;
  deactivate_post: any;
  deactivate_post_local: Date;
  decision_date: any;
  affiliation: any;
  tagline: any;
  selectedPriorityWeek:number=6;
  sponsor_week: string = '';
  carreerslistdata: programcreationModel.CarreersModel[] = [];
  selectedcarreerslistdata: programcreationModel.CarreersModel[] = [];
  eligible_countries: any;
  individual_questions: programcreationModel.QuestionsModel[] = [];
  image_urllistdata: programcreationModel.image_urlModel[] = [];
  meshtermlistdata: programcreationModel.meshtermModel[] = [];
  program_countries: programcreationModel.program_countriesModel[] = [];
  baseprogram_countries: programcreationModel.program_countriesModel[] = [];
  trialectselected: boolean = false;
  hostmentorselected: boolean = false;
  preferred_time_slotsselected: boolean = false;
  round_the_yearselected: boolean = true;
  HostEmail: string;
  nih_grantschecked: boolean = false;
  non_profit_grantschecked: boolean = false;
  updatedProgramid: number;
  profession_otherschecked: boolean=false;
  profession_others: any;
  mylevdateOptions: any;
  deadline_format:any;
  decision_format;
  loggedInUserRole:string;
  bootstrapdatepickerOptions: any;
  AccountEmployerNameData: AppModel.DDLData[];
  SelectedAccountEmployerData: AppModel.DDLData[];
  CountryLookupData: AppModel.DDLData[];
  SelectedCountryLookupData: AppModel.DDLData[];
  searchtext: string;
  Countrysearchtext: string;
  programWiseLogistics:any=[];
  priority_merit_weeks:any;
  constructor(
    private fb: FormBuilder,
    private traineeshipService: TraineeshipService,
    private changeDetectorRef: ChangeDetectorRef, private router: Router,
    private route: ActivatedRoute) {
    this.createdefaultQuestion();
    this.minDate = new Date();
    let c = new programcreationModel.careermodel();

    let preferDate = new programcreationModel.preffered_datesmodel();
    preferDate.id = -1;
    this.preferredDatesList.push(preferDate)

 
  }


  get questionsFormGroup() {
    return this.creationstep1.get('questions') as FormArray;
  }
  ngOnInit() {
    this.bootstrapdatepickerOptions = {
      showWeekNumbers:false ,
      dateInputFormat: 'YYYY-MM-DD',
      containerClass: 'theme-dark-blue'
    }
    this.mylevdateOptions = {
      todayBtnTxt: 'Today',
      dateFormat: 'DD/MM/YYYY',
      firstDayOfWeek: 'su',
      sunHighlight: false,
      height: '34px',
      width: '180px',
      inline: false,
      selectionTxtFontSize: '12px',
      showClearDateBtn: false,
    };
    this.PriorityMeritListData = [];
    var BasePriorityMeritData = new programcreationModel.PriorityMeritmodel();
    BasePriorityMeritData.id = -1;
    this.PriorityMeritListData.push(BasePriorityMeritData);
    this.appUrl = CommonService.APP_URL;
    
    this.ckeConfig = {
      allowedContent: false,
      extraPlugins: 'divarea',
      forcePasteAsPlainText: true,
      removePlugins: 'horizontalrule,about',
      removeButtons: 'Save,NewPage,Preview,Print,Templates,ImageButton,Replace,SelectAll,Subscript,Superscript,Form,Checkbox,Radio,TextField,Textarea,Find,Select,Button,HiddenField,CopyFormatting,CreateDiv,BidiLtr,BidiRtl,Language,Flash,Smiley,PageBreak,Iframe,TextColor,BGColor,ShowBlocks,Cut,Copy,Paste,Table,Format,Source,Maximize,Anchor,SpecialChar,PasteFromWord,PasteText,Scayt,Undo,Redo,Strike,RemoveFormat,Blockquote,Image'
    };
    this.publishDateCalanderForm=this.fb.group({
      publish_startdate:[]
    });
    this.creationstep1 = this.fb.group({
      programName: ['', Validators.required],
      uploadImage: ['', Validators.required],
      briefDescription: ['', Validators.required],
      universitySponsorLogo: ['', Validators.required],
      certification: ['', Validators.required],
      isTrialectChecked: ['', Validators.required],
      isHostMonterChekced: ['', Validators.required],
      numberOfSessions: ['', Validators.required],
      durationOfEachSession: ['', Validators.required],
      numberofSlots: ['', Validators.required],
      contractStartDate: ['', Validators.required],
      noOfYearsContract: ['', Validators.required],
      hostAvailability: [],
      deactivatePost: ['', Validators.required],
      merit: [{value: 'Free',disabled: true}, Validators.required],
      actualCost: ['', Validators.required],
      discount: ['', Validators.required],
      sponsorCost: ['', Validators.required],
      partialprogramchecked:[],
      // priority_merit_weeks:[],
      // merit_cost_week:[],
      // sponsor_week:[],
      // isRoundTheYear:['',Validators.required],
      startDatePreferredTimeSlots: ['', Validators.required],
      endDatePreferredTimeSlots: ['', Validators.required],
      myckeditorBriefDescription: [],
      myckeditorMainAreas: [],
      myckeditorTechniques: [],
      myckeditorCurriculum: [],
      myckeditorAccommodation: [],
      feature1: [],
      feature2: [],
      feature3: [],
      feature4: [],
      feature5: [],
      feature6: [],
      eligibilityCriteria: [],
      eligibleCountry: [],
      educationCareer: [],
      fieldOfInterest: [],
      clinicalTraineeship: [],
      clinicalResearchTraineeship: [],
      translationalTraineeship: [],
      basicTranslationalTraineeship: [],
      doctorCheck: [],
      biomedicalCheck: [],
      otherMedicalCheck: [],
      nGGrants: [],
      nPGrants: [],
      disclaimerText: [],
      trainerName: [],
      depname: [],
      trialectAllocatedEmail:[],
      hospName: [],
      hostEmail: ['', [Validators.required, Validators.pattern('[a-zA-Z0-9.-]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,4}')]],
      address: [],
      country: [],
      websiteLink: [],
      courseLink: [],
      tagLine: [],
      trainerNameCheck: [],
      //questions: [this.fb.array([this.createQuestions()])],
      // question1:[],
      // answer1:[],
      careerLevel: [],
      position: [],
      specificfields: [],
      specialty: [],
      endDate: ['', Validators.required],
      // affiliation: [],
      persons: this.fb.array([])



    });

    this.userDetails =
      {
        "username": "" + localStorage.getItem("email") + "",
        "token": "" + localStorage.getItem("token_Id") + "",
        "login_status": "" + localStorage.getItem("status") + "",


      }
      this.loggedInUserRole=localStorage.getItem("role")
    this.value = [];

    this.options = {
      multiple: true
    }
    this.getLocations();
    this.getCareerLevelsAPI();
    //this.getFieldInterest();

    this.route.params.subscribe(params => {

      this.Programid = params['id'];

      this.selectedTraineeshipType = params['programtypeid'];

      // alert(this.selectedTraineeshipType);
      // alert(this.Programid);
      if (this.selectedTraineeshipType == programcreationModel.TraineeshipType[programcreationModel.TraineeshipType.onlinetraineeship]) {
        this.isOnlineTraineeShip = true;

      } else
        if (this.selectedTraineeshipType == programcreationModel.TraineeshipType[programcreationModel.TraineeshipType.onlinementorship]) {
          this.isOnlineMentorship = true;

        } else
          if (this.selectedTraineeshipType == programcreationModel.TraineeshipType[programcreationModel.TraineeshipType.onsitetraineeship]) {
            this.isOnsitetraineeship = true;
            
          }

    });

    //this.showControls();
    if (this.Programid != null && this.Programid > 0)
      this.getProgrameditdata(this.Programid);
    this.galleryOptions = [
      {
        width: '900px',
        height: '500px',
        thumbnailsColumns: 8,
        imageAnimation: NgxGalleryAnimation.Slide
      },
      // max-width 800
      {
        breakpoint: 800,
        width: '100%',
        height: '600px',
        imagePercent: 80,
        thumbnailsPercent: 20,
        thumbnailsMargin: 20,
        thumbnailMargin: 20
      },
      // max-width 400
      {
        breakpoint: 400,
        preview: false
      }
    ];

    //alert(this.selectedTraineeshipType);


    $(document).ready(function () {
      $("input[name$='cars']").click(function () {
        var test = $(this).val();

        $("div.desc").hide();
        $("#Cars" + test).show();
      });
    });
    $(document).ready(function () {
      var max_fields = 10; //maximum input boxes allowed
      var wrapper = $(".input_fields_wrap"); //Fields wrapper
      var add_button = $(".add_field_button"); //Add button ID

      var x = 1; //initlal text box count
      $(add_button).click(function (e) { //on add input button click
        e.preventDefault();
        if (x < max_fields) { //max input box allowed
          x++; //text box increment
          $(wrapper).append('<div class="row dateDiv"><div class="col-md-5"><div class="input-group date"><input type="text" class="form-control" /><span class="input-group-addon"><span class="fa fa-calendar"></span></span></div></div><div class="col-md-5"><div class="input-group date"><input type="text" class="form-control" /><span class="input-group-addon"><span class="fa fa-calendar"></span></span></div></div><div class="col-md-2"><div class="input-group date"><a  class="remove_field"><i class="fa fa-minus" aria-hidden="true"></i></a></div></div></div>');

          //add input box
          //$(wrapper).append('<div class="row dateDiv"><input type="text" name="mytext[]"/><a  class="remove_field">Remove</a></div>'); 
        }
      });

      $(wrapper).on("click", ".remove_field", function (e) { //user click on remove text
        e.preventDefault(); $(this).parent().parent().parent('div').remove(); x--;
      })
    });
    //uncommet when go to live .....Dont Delete this code...
      $(document).ready(function () {


        //Wizard
        $('a[data-toggle="tab"]').on('show.bs.tab', function (e) {

            var $target = $(e.target);

            if ($target.parent().hasClass('disabled')) {
                return false;
            }
        });

    });



    
  }

  // showControls(): boolean {
  //   var show = true;
  //   if (this.selectedTraineeshipType == "onlineTraineeship") {
  //     show = true;
  //     return show;
  //   }
  //   if (this.selectedTraineeshipType == "onlineMentorTraineeship") {
  //     show = true;
  //     return show;
  //   }
  //   if (this.selectedTraineeshipType == "onsiteTraineeship") {
  //     show = false;
  //     return show;
  //   }
  // }

  getFieldInterest() {


    // this.traineeshipService.getSearchFieldOfIntrest('{"username":"santosh.d@smartims.com","token":"1nuorlia58ckckoosskw4c448kwsg8w","login_status":"1"}').subscribe(
    this.traineeshipService.getSearchFieldOfIntrest('' + JSON.stringify(this.userDetails) + '').subscribe(
      (response) => {

        this.exampleData = response.dataRows;
        //alert(JSON.stringify(this.exampleData));

      },
      (err) => {
        this.errorMessage = err;

      });


  }
  AddOrRemovepreferredTimeAction(index, value, item: programcreationModel.preffered_datesmodel) {
    if (value) {
      let preferDate = new programcreationModel.preffered_datesmodel();
      if (item.id < 0) {
        preferDate.id = item.id - 1;
        // preferDate.start_date_Local = new Date();
        // preferDate.end_date_Local = new Date();
        this.preferredDatesList.push(preferDate);
      }
      else
        this.AddPreferreddate();
    }
    else {
      if (item.id < 0)
        this.preferredDatesList.splice(index, 1);
      else {
        item.flag = true;
      }

    }
  }

  get persons() {
    return (<FormArray>this.creationstep1.get('persons')).controls;
  }
  preferredTimeAction() {

    (<FormArray>this.creationstep1.get('persons')).push(this.fb.group({
      startDatePreferredTimeSlots: [],
      endDatePreferredTimeSlots: [],

    }
    ));
  }

  add_questions_Click() {
    let questionModal1 = new programcreationModel.QuestionsModel();
    questionModal1.id = 0;
    questionModal1.question = '';
    questionModal1.answer = '';
    questionModal1.category = 'individual';
    // questionModal1.qa_id = '';
    this.questionArray.push(questionModal1);
    this.RemoveQuestionVisible=this.questionArray.length > 1 ;
  }
  carrer_Click() {

    this.careerSelected = this.careerLevelList.filter(x => x.selected).map(y => y.carreers + "," + y.id).join('/');
    let careerModal1 = new programcreationModel.careermodel();

    this.careerArray.push(careerModal1);

  }

  // removeQuestion(index) {

  //   this.questionArray.splice(index)
  // }
  removeQuestion(index:number) {

    this.questionArray[index].flag=false;

    if(this.questionArray.filter(q=>q.flag).length<=1)
      this.RemoveQuestionVisible=false;
  }
  getLocations() {


    //this.traineeshipService.getLocations('{"username":"santosh.d@smartims.com"}').subscribe(
    this.traineeshipService.getLocations('' + JSON.stringify(this.userDetails) + '').subscribe(
      (response) => {

        this.countryList = response.dataRows;
        this.countryListData = this.countryList

        this.CountryLookupData = AppMethodModel.AppMethods.ToDDLDataItemsFromAccountQuickResults(response.dataRows);;
      },
      (err) => {
        this.errorMessage = err;

      });

  }
  getProgrameditdata(Id: any) {

this.isLoading=true;
    //this.traineeshipService.getLocations('{"username":"santosh.d@smartims.com"}').subscribe(
    this.traineeshipService.programCreationExtra('' + JSON.stringify(this.CreatprogramEditDetailsRequest(Id)) + '').subscribe(
      (response) => {
        if(response.message=="Admin credentials required"){
          if(confirm("please Sign in to edit the data")){
            // $("signIn").click();
            this.router.navigate(['/'])
          }
          
        }

        this.programCreationExtraList = response.dataRows;
        this.certification_type = response.dataRows[0].certification_type;
        this.certification = response.dataRows[0].certification;
        //  this.certificationtext = response.dataRows[0].certification;
        if (response.dataRows[0].certification == "yes")
          this.certification = true;
        else
          if (response.dataRows[0].certification == "no")
            this.certification = false;

       if (response.dataRows[0].certification == "yes")
            this.certificationShow = true;
          else
            if (response.dataRows[0].certification == "no")
              this.certificationShow = false;
        this.no_of_sessions = response.dataRows[0].no_of_sessions;
        this.duration_of_sessions = response.dataRows[0].duration_of_sessions;
        this.applicants_count = response.dataRows[0].applicants_count;
        this.total_spots = response.dataRows[0].total_spots;
        this.contract_startdate_format=response.dataRows[0].contract_startdate_format
        //this.contract_startdate_local = response.dataRows[0].contract_startdate;
        if (response.dataRows[0].contract_startdate != null) {
          // var res = response.dataRows[0].contract_startdate.split("-");
          // this.contract_startdate_local = { date: { year: res[0], month: res[1], day: res[2] } };
          this.contract_startdate_local = new Date(response.dataRows[0].contract_startdate);
        }
        this.noOfYearsContract = response.dataRows[0].years_of_contract;
        this.full_description = response.dataRows[0].full_description;
        this.accommodation = response.dataRows[0].accommodation;
        this.curriculumn = response.dataRows[0].curriculumn;
        this.techniques = response.dataRows[0].techniques;
        this.selectedcountries = response.dataRows[0].eligible_countries;
        this.eligibility_criteria = response.dataRows[0].eligibility_criteria;
        if(response.dataRows[0].feature1!==null)
          this.feature1 = response.dataRows[0].feature1;
        if(response.dataRows[0].feature2!==null)
          this.feature2 = response.dataRows[0].feature2;
        if(response.dataRows[0].feature3!==null)
            this.feature3 = response.dataRows[0].feature3;
        if(response.dataRows[0].feature4!==null)
          this.feature4 = response.dataRows[0].feature4;
        if(response.dataRows[0].feature5!==null)
          this.feature5 = response.dataRows[0].feature5;
        if(response.dataRows[0].feature6!==null)
          this.feature6 = response.dataRows[0].feature6;
       
          this.trainer_name = response.dataRows[0].trainer_name;
        // this.trainer_name_check = response.dataRows[0].trainer_name_check;
        this.department_name = response.dataRows[0].department_name;
        this.hospital_name = response.dataRows[0].hospital_name;
        this.specality=response.dataRows[0].specality;
        this.address = response.dataRows[0].address;
        this.trainer_country_id = response.dataRows[0].trainer_country_id;
        this.trainer_country_name = response.dataRows[0].trainer_country_name;
        this.brief_description = response.dataRows[0].brief_description;
        this.host_email = response.dataRows[0].host_email;
        this.course_link = response.dataRows[0].course_link
        this.website_link = response.dataRows[0].website_link;
        if(response.dataRows[0].host_affiliation!=null){
        this.host_affiliation = response.dataRows[0].host_affiliation;
      }
        this.nih_grants = response.dataRows[0].nih_grants;
        this.decision_format=response.dataRows[0].decision_format;
        this.deadline_format=response.dataRows[0].deadline_format;
        this.trialect_email=response.dataRows[0].host_trialect_email;
        this.position=response.dataRows[0].position;
        // this.profession_otherschecked=response.dataRows[0].profession_others;
        if (this.nih_grants == "yes") {
          this.nih_grantschecked = true;
        } else if (this.nih_grants == "no") {
          this.nih_grantschecked = false;
        }
        this.non_profit_grants = response.dataRows[0].non_profit_grants;
        if (this.non_profit_grants == "yes") {
          this.non_profit_grantschecked = true;
        } else if (this.non_profit_grants == "no") {
          this.non_profit_grantschecked = false;
        }

        if(response.dataRows[0].certification_type == "both"){
          this.hostmentorselected = true;
          this.trialectselected = true;
        }
        else if (response.dataRows[0].certification_type == "hostmentor") {
          this.hostmentorselected = true;
        }
        else if (response.dataRows[0].certification_type == "trialect") {
          this.trialectselected = true;
        }
        this.hostAvailability=response.dataRows[0].host_availability;
        this.OnhostAvailability(this.hostAvailability);

        // if (response.dataRows[0].host_availability == "preferred_time_slots") {
        //   this.preferred_time_slotsselected = true;
        // }
        

        // if (response.dataRows[0].host_availability == "round_the_year") {
        //   this.round_the_yearselected = true;
        // }

        this.selectedCountryId = response.dataRows[0].trainer_country_id;
        //program preview 
        this.program_name = response.dataRows[0].program_name;
        this.deactivate_post = response.dataRows[0].deactivate_post;
        this.deactivate_post_local = new Date(response.dataRows[0].deactivate_post);
        this.top_bas_translational = response.dataRows[0].top_bas_translational;
        if (this.top_bas_translational == 'yes') {
          this.top_bas_translationalchecked = true;
        } else if (this.top_bas_translational == 'no') {
          this.top_bas_translationalchecked = false;
        }
        this.top_clinical_res_traineeship = response.dataRows[0].top_clinical_res_traineeship
        if (this.top_clinical_res_traineeship == 'yes') {
          this.top_clinical_res_traineeshipchecked = true;
        } else if (this.top_clinical_res_traineeship == 'no') {
          this.top_clinical_res_traineeshipchecked = false;
        }
        this.top_clinical_traineeship = response.dataRows[0].top_clinical_traineeship
        if (this.top_clinical_traineeship == 'yes') {
          this.top_clinical_traineeshipchecked = true;
        } else if (this.top_clinical_traineeship == 'no') {
          this.top_clinical_traineeshipchecked = false;
        }
        this.top_translational = response.dataRows[0].top_translational
        if (this.top_translational == 'yes') {
          this.top_translationalchecked = true;
        } else if (this.top_translational == 'no') {
          this.top_translationalchecked = false;
        }
        this.profession_doctor = response.dataRows[0].profession_doctor
        if (this.profession_doctor == 'yes') {
          this.profession_doctorchecked = true;
        } else if (this.profession_doctor == 'no') {
          this.profession_doctorchecked = false;
        }
        this.profession_biomedical = response.dataRows[0].profession_biomedical
        if (this.profession_biomedical == 'yes') {
          this.profession_biomedicalchecked = true;
        } else if (this.profession_biomedical == 'no') {
          this.profession_biomedicalchecked = false;
        }
        this.profession_others = response.dataRows[0].profession_others
        if (this.profession_others == 'yes') {
          this.profession_otherschecked = true;
        } else if (this.profession_others == 'no') {
          this.profession_otherschecked = false;
        }
        this.created_date = response.dataRows[0].created_date
        this.full_description = response.dataRows[0].full_description;
        this.techniques = response.dataRows[0].techniques;
        this.curriculumn = response.dataRows[0].curriculumn;
        this.accommodation = response.dataRows[0].accommodation;
        this.years_of_contract = response.dataRows[0].years_of_contract;
        this.total_spots = response.dataRows[0].total_spots;
        this.deactivate_post = response.dataRows[0].deactivate_post;
        this.decision_date = response.dataRows[0].decision_date;
        this.carreerslistdata = response.carreers;
        this.selectedcarreerslistdata = response.carreers;
        this.getCareerLevelsAPI();
        this.specificfields=response.dataRows[0].specificfields;
        this.status=response.dataRows[0].status;
        this.tagline = response.dataRows[0].tagline;
        this.eligible_countries = response.dataRows[0].eligible_countries;
        // this.individual_questions = response.individual_questions;
        // this.questionArray = response.individual_questions;
        // if (this.questionArray == null || this.questionArray.length < 1) {
        //   this.questionArray = [];
        //   this.createdefaultQuestion();
        // }
        this.individual_questions = response.individual_questions;
        this.questionArray = response.individual_questions.map((iq)=> {iq.flag = true; return iq;});
        if(this.questionArray.length==0){
          this.createdefaultQuestion();
        }
        if(this.questionArray.length>1) this.RemoveQuestionVisible=true;
        
        this.image_urllistdata = response.image_url;
        this.uploadedFileListdata = response.image_url;
        this.programImages_count = response.image_url.length;

        //  localStorage.setItem("imagescount",this.programImages_count);

        this.meshtermlistdata = response.meshdata;
        this.SelectedAccountEmployerData = []
        if (this.meshtermlistdata && this.meshtermlistdata.length > 0)
          this.meshtermlistdata.forEach(element => {
            this.SelectedAccountEmployerData.push(new AppModel.DDLData(element.id, element.name));
          });
        this.program_countries = response.program_countries;
        this.baseprogram_countries = response.program_countries;
        this.SelectedCountryLookupData=[];
        if (this.program_countries && this.program_countries.length > 0) {
          this.program_countries.forEach(element => {
            this.SelectedCountryLookupData.push(new AppModel.DDLData(element.country_id, element.name));
          });
        }

        var newlist_final = [];
        var newlist;
        var array_final = [];

        if (this.image_urllistdata && this.image_urllistdata.length > 0) {
          this.image_urllistdata.forEach(element => {
            let array_list =
            {
              small: element.url,
              medium: element.url,
              big: element.url,
            };
            //console.log(array_list);
            newlist = array_list;
            newlist_final.push(newlist);
          });

          this.galleryImages = newlist_final;
        }



        // https://s3.amazonaws.com/traineeshipprogram/files/30-05-2019-06-18-38-927.png (sponsor Logo)
        this.sponsor_logo = (response.dataRows[0].sponsor_logo != "" && response.dataRows[0].sponsor_logo != null) ? response.dataRows[0].sponsor_logo.split('/')[5] : ""
        if(response.dataRows[0].sponsor_logo!=null && response.dataRows[0].sponsor_logo!="" ){
          this.sponsor_logo_check=false;
        }
        else{
          this.sponsor_logo_check=true;
        }
        this.sponsor_logo_image=response.dataRows[0].sponsor_logo
        // this.sponsor_logo_check=response.dataRows[0].sponsor_logo



        if (response.dataRows[0].trainer_name_check == 'yes')
          this.trainer_name_check = true
        else
        this.trainer_name_check = false
        //prefer dates
        this.preferredDatesList = response.preffered_dates;
        if (this.preferredDatesList && this.preferredDatesList.length > 0) {
          this.preferredDatesList.forEach(element => {
            element.flag=false;
            element.start_date_Local = new Date(element.start_date);
            element.end_date_Local = new Date(element.end_date);
            // var startdate = element.start_date.split("-");
            // element.start_date_Local = { date: { year: startdate[0], month: startdate[1], day: startdate[2] } };
            // var enddate = element.end_date.split("-");
            // element.end_date_Local = { date: { year: enddate[0], month: enddate[1], day: enddate[2] } };
          });

        }

        if (!this.preferredDatesList || (this.preferredDatesList && this.preferredDatesList.length < 1)) {
          this.AddPreferreddate();

        }
        //merit list
        this.PriorityMeritListData = response.logistic_data;

        if (this.PriorityMeritListData && this.PriorityMeritListData.length > 0)
          this.PriorityMeritListData.forEach(element => {
            this.merit_cost_week = element.merit_cost_week;
            this.sponsor_week = element.sponsor_week;
            this.selectedPriorityWeek= parseInt(element.priority_merit_weeks);
            element.flag=true;
          });
       
        if (response.logistic_data != null && response.logistic_data.length > 0) {
          this.merit_cost = response.logistic_data[0].merit_cost;
          this.sponsor = response.logistic_data[0].sponsor;
          
        }
        if (!this.PriorityMeritListData || (this.PriorityMeritListData && this.PriorityMeritListData.length < 1)) {
          this.PriorityMeritListData = [];

          let PriorityMerit = new programcreationModel.PriorityMeritmodel();
          PriorityMerit.id = - 1;
          PriorityMerit.merit_cost_week = "";
          PriorityMerit.sponsor_week = "";
          this.PriorityMeritListData.push(PriorityMerit);
          
        }

    // this.onChangeWeek(this.selectedPriorityWeek)
    this.isLoading=false;
      },
      (err) => {
        this.isLoading=false;
        this.errorMessage = err;

      });

  }


  onEligiblecountriesChange(selectedValue) {
    this.selectedCountry = selectedValue;


  }

  public fileChange(input) {
  // alert(input.target.files.length)
  // alert(input.target.files)
if(input.target.files!=null&&input.target.files.length>0){
  this.sponsor_logo_check=true;
}
else if(this.reponseId>0){
  this.sponsor_logo_check=false;
}
// else 
// this.sponsor_logo_check=false;

    this.processImage(input.target.files);
  }
  hidepopup(target) {
    $('#hidepopup').hide();
    //document.getElementById(target).style.display = 'none';
  }


  private processImage(files, index = 0) {
    let reader = new FileReader();

    if (index in files) {
      this.readFile(files[index], reader, (result) => {

        // Create an img element and add the image file data to it
        let img = document.createElement('img');
        img.src = result;

        // Send this img to the resize function (and wait for callback)
        this.traineeshipService.resizeImage(img, (croppedImage) => {

          // This is the file you want to upload.
          // Either as a base64 string or img.src = croppedImage if you prefer a file.
          this.uploadImage = croppedImage;
          // this.uploadImageBase64 = reader.result.toString().split(',')[1];
          this.uploadImageBase64 = croppedImage
          // console.log(this.uploadImageBase64);
          this.displayImage="data:image/png;base64,"+this.uploadImageBase64
        });
      });
    } else {
      // When all files are done this forces a change detection
      this.changeDetectorRef.detectChanges();
    }
  }

  private readFile(file, reader, callback) {
    reader.onload = () => {
      callback(reader.result);
    };

    reader.readAsDataURL(file);
  }

  removeSelectedImage(selectedFileName, i) {
    //alert(selectedFileName);
    // $('#id_drugs.jpg').empty();
    $("p[id='id_" + selectedFileName + "']").empty();
    //$( "button[id='btnId_"+selectedFileName+"']" ).remove();
    $("img[id='imgId_" + i + "']").attr("src", "");
    var x;
    x = $("button[id='btnId_" + selectedFileName + "']").detach();
    $("body").prepend(x);
    //$( "p[id='id_"+selectedFileName+"'" ).empty();
    //$( "p[id='id_drugs.jpg'" ).empty();
  }

  public startDateOptions: IMyOptions = {
    dateFormat: 'yyyy/mm/dd',
  };
  public endDateOptions: IMyOptions = {
    dateFormat: 'yyyy/mm/dd',
  };

  nextEvent() {

    var $active = $('.wizard .nav-tabs li.active');
    $active.next().removeClass('disabled');
    this.nextTab($active);
    window.scroll(0, 0)
    this.nextClicked=false;
  }

  previousButtonEvent() {

    var $active = $('.wizard .nav-tabs li.active');
    this.prevTab($active);
  }

  public nextTab(elem) {
    $(elem).next().find('a[data-toggle="tab"]').click();
  }

  public prevTab(elem) {
    $(elem).prev().find('a[data-toggle="tab"]').click();
  }

  private convertDate(date: any): string {
    return (date) ? date.year + '-' + date.month + '-' + date.day : '';
  }




  public alertClosed(): void {
    // this.successMessage = null;
    this.errorMessage = null;
  }


  step1validation(): boolean {
 
  //   alert(this.sponsor_logo);
    this.errorMessage = null;

    let valid: boolean = true;
    if(this.preferred_time_slotsselected==true)
{
    this.preferredDatesList.forEach(element => {
      if (element.start_date == "" || element.start_date == null) {
        valid = false;
        this.nextClicked=false;
        
        this.errorMessage = "Please enter Preferred time slots"
      }
      if (element.end_date == null || element.end_date == "") {
        this.nextClicked=false;
        valid = false;
        this.errorMessage = "Please enter Preferred end date slots"
      }
    });
  }

    if (this.isOnlineTraineeShip) {
      if (this.creationstep1.value.numberOfSessions == "" || this.creationstep1.value.numberOfSessions == undefined||this.creationstep1.value.numberOfSessions.trim()=="") {
        window.scroll(0, 0)
        this.nextClicked=false;
        this.errorMessage = "Please enter Number of Sessions"
        this.isLoading = false;
      }
      if (this.creationstep1.value.durationOfEachSession == "" || this.creationstep1.value.durationOfEachSession == undefined ||this.creationstep1.value.durationOfEachSession.trim() == "" ) {
        window.scroll(0, 0)
        this.nextClicked=false;
        this.errorMessage = "Please enter Duration of each Session"
        this.isLoading = false;
      }
      // if(this.priority_merit_cost==undefined){
      //   window.scroll(0, 0)
      //   this.errorMessage = "Please enter merit cost"
      //   this.isLoading = false;
      // }
      this.PriorityMeritListData.forEach(element => {
        if (element.priority_merit_cost == "" || element.priority_merit_cost == null) {
          valid = false;
          window.scroll(0, 0)
          this.nextClicked=false;
          this.errorMessage = "Please enter priority merit cost"
        }
        if (element.priority_merit_discount == null || element.priority_merit_discount == "") {
          valid = false;
          window.scroll(0, 0)
          this.nextClicked=false;
          this.errorMessage = "Please enter priority merit discount"
        }
      });

    }
    
    else if (this.isOnlineMentorship) {
      if (this.creationstep1.value.numberOfSessions == "" || this.creationstep1.value.numberOfSessions == undefined) {
        window.scroll(0, 0)
        this.nextClicked=false;
        this.errorMessage = "Please enter Number of Sessions"
        this.isLoading = false;
      }
      if (this.creationstep1.value.durationOfEachSession == "" || this.creationstep1.value.durationOfEachSession == undefined) {
        window.scroll(0, 0)
        this.nextClicked=false;
        this.errorMessage = "Please enter Duration of each Session"
        this.isLoading = false;
      }
 

    }

    if (this.creationstep1.value.programName == "" || this.creationstep1.value.programName == undefined ||this.creationstep1.value.programName.trim() == "") {
      window.scroll(0, 0)
      this.nextClicked=false;
      this.errorMessage = "Please enter Program name"
      this.isLoading = false;
    }

    else if (this.creationstep1.value.briefDescription == "" || this.creationstep1.value.briefDescription == undefined ||this.creationstep1.value.briefDescription.trim()=="") {
      window.scroll(0, 0)
      this.nextClicked=false;
      this.errorMessage = "Please enter Brief Description"
      this.isLoading = false;
    }
  

    else if (this.creationstep1.value.numberofSlots == "" || this.creationstep1.value.numberofSlots == undefined) {
      window.scroll(0, 0)
      this.nextClicked=false;
      this.errorMessage = "Please enter Number of Slots"
      this.isLoading = false;
    }
    else if (this.convertDate(this.contract_startdate_local) == "" || this.convertDate(this.contract_startdate_local) == undefined) {
      window.scroll(0, 0)
      this.nextClicked=false;
      this.errorMessage = "Please enter Contract Start Date"
      this.isLoading = false;
    }
    else if (this.creationstep1.value.noOfYearsContract == "" || this.creationstep1.value.noOfYearsContract == undefined) {
      window.scroll(0, 0)
      this.nextClicked=false;
      this.errorMessage = "Please enter No of Years Contract"
      this.isLoading = false;
    }
    
    else if (this.creationstep1.value.sponsorCost == "" || this.creationstep1.value.sponsorCost == undefined) {
      window.scroll(0, 0)
      this.nextClicked=false;
      this.errorMessage = "Please enter Sponsor cost"
      this.isLoading = false;
    }
    else if ((this.uploadImageBase64==""||this.uploadImageBase64==undefined)&&(this.sponsor_logo==""||this.sponsor_logo==undefined)) {
      window.scroll(0, 0)
      this.nextClicked=false;
      this.errorMessage = "Please upload Sponsor logo"
      this.isLoading = false;
    }
    else if (this.uploadedFileListdata == null||this.uploadedFileListdata.length==0|| this.uploadedFileListdata == undefined) {
      window.scroll(0, 0)
      this.nextClicked=false;
      this.errorMessage = "Please Upload images."
      this.isLoading = false;
    }
    else if (this.PriorityMeritListData.length<1|| this.PriorityMeritListData == undefined) {
      window.scroll(0, 0)
      this.nextClicked=false;
      this.errorMessage = "Please Categories."
      this.isLoading = false;
    }
    if (this.errorMessage != null) {
      valid = false;
    }

    return valid
  }






  submitStep1(isDraft:boolean) {
    this.nextClicked=true;
    // this.isLoading = true;
     this.errorMessage ="";
    if (this.reponseId != null && this.reponseId > 0) {
      this.updatedProgramid = this.reponseId
    } else
      if (this.Programid != null && this.Programid > 0) {
        this.updatedProgramid = this.Programid
      }
      else {
        this.updatedProgramid = 0
      }
    
    
   
    if (this.creationstep1.value.hostAvailability == true) {
      this.creationstep1.value.hostAvailability = "round_the_year";
    }
    else {
      this.creationstep1.value.hostAvailability = "preferred_time_slots";
    }
    
         

    if (this.preferredDatesList && this.preferredDatesList.length > 0) {
      this.preferredDatesList.forEach(element => {
        element.start_date = this.GetFormattedDate(element.start_date_Local);

        element.end_date = this.GetFormattedDate(element.end_date_Local);
      });
    }
if(this.creationstep1.value.deactivatePost=="" || this.creationstep1.value.deactivatePost==undefined||this.creationstep1.value.deactivatePost==null){
  this.creationstep1.value.deactivatePost="";
}




    if (this.step1validation()) {
      if (this.PriorityMeritListData && this.PriorityMeritListData.length > 0)
        this.PriorityMeritListData.forEach(element => {
          element.merit_cost_week = this.merit_cost_week;
          element.sponsor_week = this.sponsor_week;
        });

      this.submitCreationRequest =
        {

          "id": this.updatedProgramid,
          "traineeship_type": this.selectedTraineeshipType,
          "partial_program": this.creationstep1.value.partialprogramchecked,
          "slug": '',
          "program_name": this.creationstep1.value.programName.trim(),
          "brief_description": this.creationstep1.value.briefDescription.trim(),
          "sponsor_logo": this.uploadImageBase64,
          "certification": this.creationstep1.value.certification,
          "certification_type": (this.creationstep1.value.certification == 'no') ? '' : this.certification_type,
          "no_of_sessions": this.creationstep1.value.numberOfSessions,
          "duration_of_sessions": this.creationstep1.value.durationOfEachSession,
          "total_spots": this.creationstep1.value.numberofSlots,
          "contract_startdate": this.GetFormattedDate(this.contract_startdate_local),
          "years_of_contract": this.creationstep1.value.noOfYearsContract,
          "priority_merit_cost": this.creationstep1.value.actualCost,
          "priority_merit_discount": this.creationstep1.value.discount,
          "deactivate_post": this.creationstep1.value.deactivatePost,
          "sponsor_cost": this.creationstep1.value.sponsorCost,
          "host_availability": this.hostAvailability,
          "preffered_dates": this.preferredDatesList,
          "username": "" + localStorage.getItem("email") + "",
          "token": "" + localStorage.getItem("token_Id") + "",
          "login_status": "" + localStorage.getItem("status") + "",
          "step": "1",
          "logistic_data": this.PriorityMeritListData,
          "image_url": this.uploadedFileListdata,
          "sponsor_logo_check":this.sponsor_logo_check
        }
        this.isLoading=true;
      this.traineeshipService.programCreation('' + JSON.stringify(this.submitCreationRequest) + '').subscribe(
        (response) => {
          this.nextClicked=false;
          this.isLoading = false;
          $('#datatable_processing').hide();
          if(response.message=="Data updated sucessfully"){
            this.allCreationList = response.dataRows;
            }
             
            // if(response.message= "Admin credentials required"){
            //   this.errorMessage ="Please login as admin"
            // }
        
            // if(response.message=="Admin credentials required"){
            //   if(confirm("please login as Admin to create program")){
            //     this.router.navigate(['/'])
            //   }
              
            // }

          this.programCreationExtraList = response.dataRows;
          this.preferredDatesList = response.preffered_dates;
          if (!this.preferredDatesList || (this.preferredDatesList && this.preferredDatesList.length < 1)) {
            this.preferredDatesList = [];

            let preferDate = new programcreationModel.preffered_datesmodel();
            preferDate.id = -1;
            this.preferredDatesList.push(preferDate)
          }
          this.PriorityMeritListData = response.logistic_data;
          if (!this.PriorityMeritListData || (this.PriorityMeritListData && this.PriorityMeritListData.length < 1)) {
            this.PriorityMeritListData = [];

            let PriorityMerit = new programcreationModel.PriorityMeritmodel();
            PriorityMerit.id = - 1;
            PriorityMerit.merit_cost_week = "";
            PriorityMerit.sponsor_week = "";
            this.PriorityMeritListData.push(PriorityMerit);
          }
          this.reponseId = response.data.id
          if (this.updatedProgramid != null && this.updatedProgramid! > 0)
            this.reponseId = this.updatedProgramid
          this.getProgrameditdata(this.reponseId)
          this.isLoading = false;
          if(!isDraft){
            this.isLoading = false;
            this.nextEvent();
          }
        },
        (err) => {
          this.nextClicked=false;
          this.isLoading = false;
          this.errorMessage = err;

        });

    }
  }

  submitStep2(isDraft:boolean) {
    this.errorMessage ="";
    // this.isLoading = true;
    if (this.Programid != null && this.Programid > 0) {
      this.updatedProgramid = this.Programid
    }
    else {
      this.updatedProgramid = this.reponseId
    }
   // alert(this.creationstep1.value.myckeditorMainAreas);
    
   


  
    if ((this.creationstep1.value.myckeditorMainAreas==null || this.creationstep1.value.myckeditorMainAreas.trim() == "" || this.creationstep1.value.myckeditorMainAreas.trim() == undefined ) ||
      (this.creationstep1.value.myckeditorTechniques==null || this.creationstep1.value.myckeditorTechniques.trim() == "" || this.creationstep1.value.myckeditorTechniques.trim() == undefined) ||
      ( this.creationstep1.value.myckeditorCurriculum==null || this.creationstep1.value.myckeditorCurriculum.trim() == "" || this.creationstep1.value.myckeditorCurriculum.trim() == undefined) ||
      (this.creationstep1.value.myckeditorAccommodation==null || this.creationstep1.value.myckeditorAccommodation.trim() == "" || this.creationstep1.value.myckeditorAccommodation.trim() == undefined)

    ) {
      this.isLoading = false;

       if (this.creationstep1.value.myckeditorMainAreas==null || this.creationstep1.value.myckeditorMainAreas.trim() == "" || this.creationstep1.value.myckeditorMainAreas.trim() == undefined) {
        window.scroll(0, 0)
        this.errorMessage = "Please enter Main areas of the group"
      }
      else if (this.creationstep1.value.myckeditorTechniques==null || this.creationstep1.value.myckeditorTechniques.trim() == "" || this.creationstep1.value.myckeditorTechniques.trim() == undefined ) {
        window.scroll(0, 0)
        this.errorMessage = "Please enter Techniques"
      }
      else if (this.creationstep1.value.myckeditorCurriculum==null || this.creationstep1.value.myckeditorCurriculum.trim() == "" || this.creationstep1.value.myckeditorCurriculum.trim() == undefined) {
        window.scroll(0, 0)
        this.errorMessage = "Please enter Curriculum"
      }
      else if (this.creationstep1.value.myckeditorAccommodation==null || this.creationstep1.value.myckeditorAccommodation.trim() == "" || this.creationstep1.value.myckeditorAccommodation.trim() == undefined) {
        window.scroll(0, 0)
        this.errorMessage = "Please enter Accommodation"
      }

    
      
   

      else {
        window.scroll(0, 0)
        this.errorMessage = "Please fill all the required fields"
      }
    }
    else {
      this.submitCreationRequest =
      {
        "id": this.updatedProgramid,
        "full_description": this.creationstep1.value.myckeditorMainAreas.trim(),
        "techniques": this.creationstep1.value.myckeditorTechniques.trim(),
        "curriculumn": this.creationstep1.value.myckeditorCurriculum.trim(),
        "accommodation": this.creationstep1.value.myckeditorAccommodation.trim(),
        "username": "" + localStorage.getItem("email") + "",
        "token": "" + localStorage.getItem("token_Id") + "",
        "login_status": "" + localStorage.getItem("status") + "",
        "step": "2"
      }
      this.traineeshipService.programCreation('' + JSON.stringify(this.submitCreationRequest) + '').subscribe(
        (response) => {
          this.isLoading = false;
          this.allCreationList = response.dataRows; 
                   if(!isDraft)
                      this.nextEvent();
                    
        },
        (err) => {
          this.isLoading = false;
          this.errorMessage = err;

        });
      // this.nextEvent();
    }
  }
  CheckInterestexist(Name: string): boolean {
    var isexist = false;

    if (this.meshtermlistdata != null && this.meshtermlistdata.length > 0) {
      this.meshtermlistdata.forEach(element => {
        if (element.name == Name) {
          element.flag=false;
          isexist = true;
        }
      });
    }
    return isexist;
  }
  CheckCountryexist(Name: string): boolean {
    var isexist = false;

    if (this.program_countries != null && this.program_countries.length > 0) {
      this.program_countries.forEach(element => {
        if (element.name == Name) {
          element.flag=false;
          isexist = true;
        }
      });
    }
    return isexist;
  }

  submitStep3(isDraft:boolean) {
    
    this.errorMessage ="";
// this.isLoading=true;
    if (this.Programid != null && this.Programid > 0) {
      this.updatedProgramid = this.Programid
    }
    else {
      this.updatedProgramid = this.reponseId
    }

    //let selectedFieldOfInterest = this.getSelectedFieldOfInterest();
    //let selectedCountriesListAll = this.getSelectedCountiesListAll();
    let selectedCountry = $("#ddlCountry option:selected").text();
    var selectedFieldOfInterestnew = null;
      this.meshtermlistdata = [];
    if (this.SelectedAccountEmployerData && this.SelectedAccountEmployerData.length > 0) {
      this.SelectedAccountEmployerData.forEach(element => {
        if (!this.CheckInterestexist(element.Text)) {
          var meshtermdata: programcreationModel.meshtermModel = new programcreationModel.meshtermModel();
          meshtermdata.meshterm_id = element.Id;
          meshtermdata.name = element.Text;
         
          this.meshtermlistdata.push(meshtermdata);
        }
        if (selectedFieldOfInterestnew == null)
          selectedFieldOfInterestnew = element.Id;
        else
          selectedFieldOfInterestnew = selectedFieldOfInterestnew + ',' + element.Id;

      });

    }

    var SelectedCountrynew = null;
   
    if (this.SelectedCountryLookupData && this.SelectedCountryLookupData.length > 0) {
      this.SelectedCountryLookupData.forEach(element => {
        if (!this.CheckCountryexist(element.Text)) {
          var Countryata: programcreationModel.program_countriesModel = new programcreationModel.program_countriesModel();
          Countryata.country_id = element.Id;
          Countryata.name = element.Text;
          Countryata.id = -1
          Countryata.flag = false;
          // Countryata.flag=true;
          this.program_countries.push(Countryata);
        }
        if (SelectedCountrynew == null)
          SelectedCountrynew = element.Id;
        else
          SelectedCountrynew = SelectedCountrynew + ',' + element.Id;

      });

    }


    this.program_countries.forEach(element => {
      if (element.id > 0) {
        var found = this.SelectedCountryLookupData.find(function (celement) {
          return celement.Id == element.country_id;
        });
        if (found == null) {
          element.flag = true;
        }
      }
    });

    //test now


    this.tempcareerLevelList=[];
    this.careerLevelList.forEach(element => {
      if (element.selected || element.id > 0) {
        this.tempcareerLevelList.push(element);
      }
    });






    this.submitCreationRequest =
      {
        "id": this.updatedProgramid,
        // "field_of_interests": selectedFieldOfInterestnew,
        "field_of_interests": this.meshtermlistdata.filter(m=>!m.flag).map(fi=>fi.name).join(','),
        "eligibility_criteria": this.creationstep1.value.eligibilityCriteria,
        // "eligible_countries": SelectedCountrynew,
        "eligible_countries": this.program_countries.filter(c=>!c.flag).map(m=>m.name).join(','),
        //"program_carrers": this.careerSelected,
        "program_carrers": this.tempcareerLevelList.filter(cr=>cr.selected).map(tcr=>tcr.carreers).join(','),
        "feature1": this.creationstep1.value.feature1,
        "feature2": this.creationstep1.value.feature2,
        "feature3": this.creationstep1.value.feature3,
        "feature4": this.creationstep1.value.feature4,
        "feature5": this.creationstep1.value.feature5,
        "feature6": this.creationstep1.value.feature6,
        "username": "" + localStorage.getItem("email") + "",
        "token": "" + localStorage.getItem("token_Id") + "",
        "login_status": "" + localStorage.getItem("status") + "",
        "step": "3",
        // "meshdata": this.meshtermlistdata.filter(m=>!m.flag),
        "meshdata": this.meshtermlistdata.filter(m=>!m.flag),
        "career": this.tempcareerLevelList,
        "program_countries": this.program_countries.filter(c=>!c.flag)
      }
    //   alert(this.careerArray.length)
    // alert(this.tempcareerLevelList.length)

    if ((selectedFieldOfInterestnew == "" || selectedFieldOfInterestnew == undefined) ||
      (this.creationstep1.value.eligibilityCriteria.trim() == "" || this.creationstep1.value.eligibilityCriteria == undefined) ||
      (SelectedCountrynew == "" || SelectedCountrynew == undefined) ||
      (this.program_countries.length ==0)||(this.meshtermlistdata.length ==0)||(this.tempcareerLevelList.length==0)||
      (!this.creationstep1.value.feature1 || this.creationstep1.value.feature1.trim() == "" ) ||
      (!this.creationstep1.value.feature2 || this.creationstep1.value.feature2.trim() == "" ) ||
      (!this.creationstep1.value.feature3 || this.creationstep1.value.feature3.trim() == "" ) ||
      (!this.creationstep1.value.feature4 || this.creationstep1.value.feature4.trim() == "" ) ||
      (!this.creationstep1.value.feature5 || this.creationstep1.value.feature5.trim() == "" ) ||
      (!this.creationstep1.value.feature6 || this.creationstep1.value.feature6.trim() == "" )
      
    ) {
      this.isLoading = false;

      // if (this.creationstep1.value.fieldOfInterest == "" || this.creationstep1.value.fieldOfInterest == undefined) {
      //   window.scroll(0, 0)
      //   this.errorMessage = "Please enter fieldOfInterest"
      // }
      if (!this.creationstep1.value.eligibilityCriteria || this.creationstep1.value.eligibilityCriteria.trim() == "") {
        window.scroll(0, 0)
        this.errorMessage = "Please enter Eligibility Criteria "
      }
      else if (SelectedCountrynew == null || SelectedCountrynew == "" || SelectedCountrynew == undefined) {
        window.scroll(0, 0)
        this.errorMessage = "Please select Eligible Country"
      }
      else if (this.meshtermlistdata.length ==0) {
        window.scroll(0, 0)
        this.errorMessage = "Please  select Field of interest"
      }
      else if (this.program_countries.length ==0) {
        window.scroll(0, 0)
        this.errorMessage = "Select Eligible Country"
      }

      else if (this.tempcareerLevelList.length == 0 ) {
        window.scroll(0, 0)
        this.errorMessage = "Please enter Education Career"
      }
      else if (!this.creationstep1.value.feature1 || !this.creationstep1.value.feature1.trim()) {
        window.scroll(0, 0)
        this.errorMessage = "Please enter Feature1"
      }
      else if (!this.creationstep1.value.feature2 || !this.creationstep1.value.feature2.trim()) {
        window.scroll(0, 0)
        this.errorMessage = "Please enter Feature2"
      }
      else if (!this.creationstep1.value.feature3 || !this.creationstep1.value.feature3.trim()) {
        window.scroll(0, 0)
        this.errorMessage = "Please enter Feature 3"
      }
      else if (!this.creationstep1.value.feature4 || !this.creationstep1.value.feature4.trim()) {
        window.scroll(0, 0)
        this.errorMessage = "Please enter Feature 4"
      }
      else if (!this.creationstep1.value.feature5 || !this.creationstep1.value.feature5.trim()) {
        window.scroll(0, 0)
        this.errorMessage = "Please enter Feature 5"
      }
      else if (!this.creationstep1.value.feature6 || !this.creationstep1.value.feature6.trim()) {
        window.scroll(0, 0)
        this.errorMessage = "Please enter Feature 6"
      }

      // else {
      //   window.scroll(0, 0)
      //   this.errorMessage = "Please fill all the required fields"
      // }
    }
    else {
      this.isLoading = true;
      // this.isLoading = true;
      this.traineeshipService.programCreation('' + JSON.stringify(this.submitCreationRequest) + '').subscribe(
        (response) => {
          this.isLoading = false;
          $('#datatable_processing').hide();
          this.errorMessage=null;
          this.allCreationList = response.dataRows;
          if(!isDraft)
            this.nextEvent();
        },
        (err) => {
          this.isLoading = false;
          this.errorMessage = err;
        });
      // this.nextEvent();
    }
  }

  step4validation(): boolean {
    
    this.errorMessage = null;
    let selectedCountry = $("#ddlCountry option:selected").text();
    let valid: boolean = true;
    if (this.isOnlineTraineeShip || this.isOnsitetraineeship) {
      if (!this.creationstep1.value.depname || !this.creationstep1.value.depname.trim()) {
        window.scroll(0, 0)
        this.errorMessage = "Please enter Department Name"
        this.isLoading = false;
      }
      if (!this.creationstep1.value.hospName || !this.creationstep1.value.hospName.trim()) {
        window.scroll(0, 0)
        this.errorMessage = "Please enter Hospital Name"
        this.isLoading = false;
      }
      if ((this.countryName == "" || this.countryName == undefined)&& (this.trainer_country_id==""||this.trainer_country_id==null)) {
        window.scroll(0, 0)
        this.errorMessage = "Please select Country"
        this.isLoading = false;
      }
       if (!this.creationstep1.value.address || !this.creationstep1.value.address.trim()) {
        window.scroll(0, 0)
        this.errorMessage = "Please enter Address "
        this.isLoading = false;
      }

    }
    else if (this.isOnlineMentorship) {
      this.selectedCountry = "0";
      if ( this.position == undefined || this.position == null||this.position.trim() == "" ) {
        window.scroll(0, 0)
        this.errorMessage = "Please enter Position "
        this.isLoading = false;
      }
      if (this.specificfields == undefined ||  this.specificfields == null||this.specificfields.trim() == "" ) {
        window.scroll(0, 0)
        this.errorMessage = "Please enter Specific fields "
        this.isLoading = false;
      }
      if ( this.specality == undefined || this.specality == null|| this.specality.trim() == "" ) {
        window.scroll(0, 0)
        this.errorMessage = "Please enter Specialty"
        this.isLoading = false;
      }


    }

    if (this.creationstep1.value.trainerName == "" || this.creationstep1.value.trainerName == undefined ||this.creationstep1.value.trainerName == null ||this.creationstep1.value.trainerName.trim() == "") {
      window.scroll(0, 0)
      this.errorMessage = "Please enter Trainer Name"
      this.isLoading = false;
    }



    else if (this.creationstep1.value.disclaimerText == null || this.creationstep1.value.disclaimerText == undefined ||this.creationstep1.value.disclaimerText.trim() == "") {
      window.scroll(0, 0)
      this.errorMessage = "Please enter Disclaimer message"
      this.isLoading = false;
    }
    else if (this.creationstep1.value.websiteLink == null || this.creationstep1.value.websiteLink == undefined ||this.creationstep1.value.websiteLink.trim() == "" ) {
      window.scroll(0, 0)
      this.errorMessage = "Please enter Website Link"
      this.isLoading = false;
    }
    else if (((this.creationstep1.value.basicTranslationalTraineeship== null)||(this.creationstep1.value.basicTranslationalTraineeship== "no")) &&
    ( (this.creationstep1.value.translationalTraineeship == null)||(this.creationstep1.value.translationalTraineeship == "no") )&& 
    ((this.creationstep1.value.clinicalTraineeship == null )||(this.creationstep1.value.clinicalTraineeship == "no" ))&&
    ((this.creationstep1.value.clinicalResearchTraineeship == null)||(this.creationstep1.value.clinicalResearchTraineeship == "no"))) {
      window.scroll(0, 0)
      this.errorMessage = "Please select type of program "
      this.isLoading = false;
    }
    else if (((this.creationstep1.value.otherMedicalCheck== null)||(this.creationstep1.value.otherMedicalCheck== "no")) &&
    ( (this.creationstep1.value.doctorCheck == null)||(this.creationstep1.value.doctorCheck == "no") )&& 
    ((this.creationstep1.value.biomedicalCheck == null )||(this.creationstep1.value.biomedicalCheck == "no" ))) {
      window.scroll(0, 0)
      this.errorMessage = "Please select Profession"
      this.isLoading = false;
    }
    else if (this.host_email == "" || this.host_email == undefined) {
      window.scroll(0, 0)
      this.errorMessage = "Please enter Host Email "
      this.isLoading = false;
    }
    else if (this.trialect_email == "" || this.trialect_email == undefined) {
      window.scroll(0, 0)
      this.errorMessage = "Please enter Trialect AllocatedEmail "
      this.isLoading = false;
    }

    if (this.errorMessage != null) {
      valid = false;
    }
    return valid
  }

  submitStep4(isDraft:boolean) {
 
    this.errorMessage=null;
    this.errorMessage ="";
    if (this.Programid != null && this.Programid > 0) {
      this.updatedProgramid = this.Programid
    }
    else {
      this.updatedProgramid = this.reponseId
    }


    let selectedCountry = $("#ddlCountry option:selected").text();
    if (this.nih_grantschecked == true) {
      this.nGGrantsData = "yes"
    }
    else {
      this.nGGrantsData = "no"
    }
    if (this.non_profit_grantschecked == true) {
      this.nPGrantsData = "yes"
    }
    else {
      this.nPGrantsData = "no"
    }
    if (this.creationstep1.value.otherMedicalCheck == true || this.profession_otherschecked== true) {
      this.creationstep1.value.otherMedicalCheck = "yes"
    }
    else if (this.creationstep1.value.otherMedicalCheck == false || this.profession_otherschecked== false){
      this.creationstep1.value.otherMedicalCheck = "no"
    }
    if (this.creationstep1.value.doctorCheck == true || this.profession_doctorchecked== true) {
      this.creationstep1.value.doctorCheck = "yes"
    }
    else if (this.creationstep1.value.doctorCheck == false || this.profession_doctorchecked== false){
      this.creationstep1.value.doctorCheck = "no"
    }
    if (this.creationstep1.value.biomedicalCheck == true || this.profession_biomedicalchecked==true) {
      // this.profession_biomedicalchecked=
      this.creationstep1.value.biomedicalCheck = "yes"
    }
    else if (this.creationstep1.value.biomedicalCheck == false || this.profession_biomedicalchecked==false){
      // this.profession_biomedicalchecked="no"
      this.creationstep1.value.biomedicalCheck = "no"
    }
    if (this.creationstep1.value.clinicalTraineeship == true ||this.top_clinical_traineeshipchecked == true) {
      this.creationstep1.value.clinicalTraineeship = "yes"
    }
    else if (this.creationstep1.value.clinicalTraineeship == false ||this.top_clinical_traineeshipchecked == false){
      this.creationstep1.value.clinicalTraineeship = "no"
    }
    if (this.creationstep1.value.clinicalResearchTraineeship == true || this.top_clinical_res_traineeshipchecked== true) {
      
      this.creationstep1.value.clinicalResearchTraineeship = "yes"
    }
    else  if (this.creationstep1.value.clinicalResearchTraineeship == false || this.top_clinical_res_traineeshipchecked== false) {
      this.creationstep1.value.clinicalResearchTraineeship = "no"
    }
    if (this.creationstep1.value.translationalTraineeship == true ||this.top_translationalchecked==true) {
      this.creationstep1.value.translationalTraineeship = "yes"
    }
    else if (this.creationstep1.value.translationalTraineeship == false ||this.top_translationalchecked==false) {
      this.creationstep1.value.translationalTraineeship = "no"
    }
    if (this.creationstep1.value.basicTranslationalTraineeship == true ||this.top_bas_translationalchecked==true) {
      // alert("IF basicTranslationalTraineeship")
      // alert(this.creationstep1.value.basicTranslationalTraineeship);
      // alert(this.top_bas_translationalchecked);
      
      this.creationstep1.value.basicTranslationalTraineeship = "yes"
    }
    else if (this.creationstep1.value.basicTranslationalTraineeship == false ||this.top_bas_translationalchecked==false) {
      // alert("else basicTranslationalTraineeship")
      // alert(this.creationstep1.value.basicTranslationalTraineeship);
      // alert(this.top_bas_translationalchecked);
      this.creationstep1.value.basicTranslationalTraineeship = "no"
    }

    if (this.creationstep1.value.trainerNameCheck == true) {
      this.creationstep1.value.trainerNameCheck = "yes";
    }
    else {
      this.creationstep1.value.trainerNameCheck = "no"
    }
    if(this.countryName==''|| this.countryName==undefined){
      this.countryName='';
    }
    if (this.step4validation()) {

      this.submitCreationRequest =
        {
          "id": this.updatedProgramid,
          "trainer_name": this.creationstep1.value.trainerName,
          "trainer_name_check": this.trainer_name_check,
          "department_name": this.creationstep1.value.depname,
          "hospital_name": this.creationstep1.value.hospName,
          "address": this.creationstep1.value.address,
          "trainer_country_id": this.selectedCountry,
          "trainer_country_name": this.countryName,
          "website_link": this.creationstep1.value.websiteLink,
          "nih_grants": this.nGGrantsData,
          "non_profit_grants": this.nPGrantsData,
          "host_affiliation": this.creationstep1.value.disclaimerText,
          "tagline": this.creationstep1.value.tagLine,
          "top_clinical_traineeship": this.creationstep1.value.clinicalTraineeship,
          "top_clinical_res_traineeship": this.creationstep1.value.clinicalResearchTraineeship,
          // "top_clinical_res_traineeship": this.top_clinical_res_traineeshipchecked ? 'yes' : 'no',
          "top_bas_translational": this.creationstep1.value.basicTranslationalTraineeship,
          "top_translational": this.creationstep1.value.translationalTraineeship,
          "profession_doctor": this.creationstep1.value.doctorCheck,
          "profession_biomedical": this.creationstep1.value.biomedicalCheck,
          "position": this.position,
          "host_email": this.host_email,
          "specialty": this.specality,
          "specificfields": this.specificfields,
          "profession_others": this.creationstep1.value.otherMedicalCheck,
          "username": "" + localStorage.getItem("email") + "",
          "token": "" + localStorage.getItem("token_Id") + "",
          "login_status": "" + localStorage.getItem("status") + "",
          "course_link": this.course_link,
          "host_trialect_email":this.trialect_email,
          "step": "4"
        }


      this.traineeshipService.programCreation('' + JSON.stringify(this.submitCreationRequest) + '').subscribe(
        (response) => {
          this.isLoading = false;
          this.allCreationList = response.dataRows;
          this.errorMessage=null;
          if(response.message=="Data updated sucessfully"){
          
          if(!isDraft)
           this.nextEvent();
          }
          
          else{
           alert(response.message);
            
            //this.errorMessage =response.message;
          }
        },
        (err) => {
          this.isLoading = false;
          this.errorMessage = err;

        });
      //this.nextEvent();
    }
  }
  submitStep5(isDraft:boolean) {
    this.isLoading = true;
    this.errorMessage=null;  
  
    if (this.Programid != null && this.Programid > 0) {
      this.updatedProgramid = this.Programid
    }
    else {
      this.updatedProgramid = this.reponseId
    }
    this.submitCreationRequest =
      {
        "id": this.updatedProgramid,

        "questions": this.questionArray,
        //"answer":this.creationstep1.value.answer1,
        "username": "" + localStorage.getItem("email") + "",
        "token": "" + localStorage.getItem("token_Id") + "",
        "login_status": "" + localStorage.getItem("status") + "",
        "step": "5",
        // "individual_questions": this.questionArray,
        // "general_questions": this.questionArray,
        // "category": "general",
        // "qa_id": ""
      }


    //   if((this.creationstep1.value.question1==""||this.creationstep1.value.question1==undefined)||
    //   (this.creationstep1.value.answer1==""||this.creationstep1.value.answer1==undefined)

    //   ){
    //     console.log(this.creationstep1.value)
    //     //alert(this.creationstep1.value.answer1)
    //     if(this.creationstep1.value.question1==""||this.creationstep1.value.question1==undefined){
    //       window.scroll(0,0)
    //       this.errorMessage = "Please fill question fields"
    //     }
    //     else if(this.creationstep1.value.answer1==""||this.creationstep1.value.answer1==undefined){

    //       window.scroll(0,0)
    //       this.errorMessage = "Please fill answer fields"
    //     }
    // else{
    //     window.scroll(0,0)
    //     this.errorMessage = "Please fill all the required fields"
    //   }
    //   }
    //   else{
    //   this.traineeshipService.programCreation(''+JSON.stringify(this.submitCreationRequest)+'').subscribe(
    //     (response) => {

    //         this.allCreationList=response.dataRows;
    //         // this.nextEvent();
    //     },
    //     (err) => {
    //         this.errorMessage = err;

    //     });
    //     this.nextEvent();
    //   }

    this.traineeshipService.programCreation('' + JSON.stringify(this.submitCreationRequest) + '').subscribe(
      (response) => {
        this.hideUILoader();
        this.errorMessage=null;
        this.allCreationList = response.dataRows;
        //this.isLoading = false;
        if(!isDraft)
          this.nextEvent();
        this.getProgrameditdata(this.updatedProgramid);
        //this.getPreviewDetails( this.updatedProgramid);
      },
      (err) => {
        this.hideUILoader();
        this.errorMessage = err;
      });


  }
  getCareerLevelsAPI() {

 //   this.isLoading = true;
    //this.traineeshipService.getLocations('{"username":"santosh.d@smartims.com"}').subscribe(
    this.traineeshipService.programCareerlevelCreate('' + JSON.stringify(this.userDetails) + '').subscribe(
      (response) => {

        response.dataRows.forEach(o => {
          o.selected = o.selected == '0' ? false : true;
          if (o.id == null)
            o.id = -1;
        });
        //this.isLoading = false;
        this.careerLevelList = response.dataRows;
        if (this.careerLevelList && this.careerLevelList.length > 0 && this.selectedcarreerslistdata != null && this.selectedcarreerslistdata.length > 0) {
          this.careerLevelList.forEach(element => {
            this.selectedcarreerslistdata.forEach(selectedelement => {
              if (selectedelement.career_id == element.career_id) {
                element.id = selectedelement.id;
                element.selected = true;
              }
            });

          });
        }

      },
      (err) => {
        this.isLoading = false;
        this.errorMessage = err;

      });

  }

  checkIfAllSelected(item: any) {
    item.selected = !item.selected
    // this.selectedAll = this.careerLevelList.every(function(item:any) {
    //     return item.selected ;
    //   })
    //for save
    this.careerSelected = this.careerLevelList.filter(x => x.selected).map(y => ({ ...y, 'id': "" }));
    //this.careerSelected = this.careerLevelList.filter(x=>x.selected).map(y=> "{ name:"+y.carreers+",career_id:"+y.id+",'id:''}").join(',');
    // this.careerSelected = this.careerLevelList.filter(x=>x.selected).map(y=>"'"+ y.carreers+"'").join(',');
    //this.program_carrers.push(this.careerSelected)
    let careerModal1 = new programcreationModel.careermodel();

    this.careerArray.push(careerModal1);
  }
  onexamplechanged(info: { data: any, value: string }) {
    if (info != null && info.value != null) {

      this.word = '+';

      for (let i = 0; i < info.data.length; i++) {
        this.current = (info.data[i].text);
        if (this.current.indexOf(' ') >= 0) {
          this.current = "'" + this.current + "'"
        }

        this.word = this.word + " +" + this.current;

      }




    }
    else {

      this.word = ""
    }

  }
  getSelectedFieldOfInterest() {


    let selectedFieldOfInterest = this.word.substring(1).trim();
    let finalString = "";

    finalString = selectedFieldOfInterest.split("+").join("");



    return finalString;

  }

  onContractSartDateChanged(event: IMyDateModel) {
    // event properties are: event.date, event.jsdate, event.formatted and event.epoc
    this.contract_startdate = event.formatted
    //this.contract_startdate_local = { date: { year: event.date.year, month: event.date.month, day: event.date.day } };
    // console.log('onInputFieldChanged(): Value: ', event.date, ' - dateFormat: ', event.formatted, event.jsdate);
  }

  onSartDateChanged(event: IMyDateModel, dateData: programcreationModel.preffered_datesmodel) {
    // event properties are: event.date, event.jsdate, event.formatted and event.epoc
    dateData.start_date = event.formatted
    // dateData.start_date_Local = { date: { year: event.date.year, month: event.date.month, day: event.date.day } };
    // console.log('onInputFieldChanged(): Value: ', event.date, ' - dateFormat: ', event.formatted, event.jsdate);
  }

  onEndDateChanged(event: IMyDateModel, dateData: programcreationModel.preffered_datesmodel) {
    // event properties are: event.date, event.jsdate, event.formatted and event.epoc
    dateData.end_date = event.formatted
    //dateData.end_date_Local = { date: { year: event.date.year, month: event.date.month, day: event.date.day } };
    // console.log('onInputFieldChanged(): Value: ', event.date, ' - dateFormat: ', event.formatted, event.jsdate);
  }
  onInputFieldChanged(event: IMyInputFieldChanged) {
    // console.log('onInputFieldChanged(): Value: ', event.value, ' - dateFormat: ', event.dateFormat, ' - valid: ', event.valid);
  }


  AddOrRemovePriorityMerit(index, value, item: programcreationModel.PriorityMeritmodel): void {
 


    if (value) {
      let PriorityMerit = new programcreationModel.PriorityMeritmodel();
      if (item.id < 0)
        PriorityMerit.id = item.id - 1;
      else
        PriorityMerit.id = -1;
      PriorityMerit.merit_cost_week = "";
      PriorityMerit.sponsor_week = "";
      this.PriorityMeritListData.push(PriorityMerit);
    }
    else {
      
      if (item.id < 0)
        this.PriorityMeritListData.splice(index, 1);
      // else if (item.id > 0){
      //   this.PriorityMeritListData.splice(index, 1);
      // }
      else 
        item.flag = false;
    }
  }

  onSelectFile(event: programcreationModel.IFileReaderEvent) {

    const fileReader: FileReader = new FileReader();

    // fileReader.onload = (event: Event) => {
    //   fileReader.result; // This is valid
    // };
    // if (event.target.files && event.target.files[0]) {
    //   var filesAmount = event.target.files.length;
    //   for (let i = 0; i < filesAmount; i++) {
    //     var reader = new FileReader();

    //     reader.onload = (event) => {
    //       console.log(event.target.result);
    //       this.urls.push(event.target.result);
    //     }
    //     reader.onload = function (fre: programcreationModel.IFileReaderEvent) {
    //       var data = JSON.parse(fre.target.result);

    //       reader.readAsDataURL(event.target.files[i]);
    //     }
    //   }



  }
  onChange(e) { }

  onFileMultipleImages(event) {


    if (event.target.files && event.target.files.length > 0) {
      //event.target.files.forEach(element => {
      for (var i: number = 0; i < event.target.files.length; i++) {
        let reader = new FileReader();

        let file = event.target.files[i];
        reader.readAsDataURL(file);
        reader.onload = () => {

          // this.applyingform.get('UploadCV').setValue({
          //   filename: file.name,
          //   filetype: file.type,
          //  value: reader.result.toString().split(',')[1]

          // })
          // if (this.uploadLOIFileBase64 == null) {
          //   this.uploadLOIFileBase64 = [];
          // }

          // this.uploadLOIFileBase64.push(reader.result.toString().split(',')[1])
          var base64data = reader.result.toString().split(',')[1];
          //  console.log console.log(this.uploadLOIFileBase64);
          var uploadedFiledata: programcreationModel.FileModel = new programcreationModel.FileModel();

          uploadedFiledata.uploadFileBase64 = base64data;
          uploadedFiledata.imagename = file.name;
          uploadedFiledata.name = file.name;
          if (this.uploadedFileListdata == null) {
            uploadedFiledata.id = -1;
            this.uploadedFileListdata = [];
          } else if (this.uploadedFileListdata != null && this.uploadedFileListdata.length > 0) {
            var min: number = 0;
            this.uploadedFileListdata.forEach(element => {
              if (min > element.id) {
                min = element.id;
              }
            });
            uploadedFiledata.id = min;
          }
          this.uploadedFileListdata.push(uploadedFiledata);
          this.myInput.nativeElement.value = "";

        };
      }
      // });
    }
  }


  fileremove(file: programcreationModel.FileModel, index): void {

    if (file.id < 1) {
      this.uploadedFileListdata.splice(index, 1);
      if (this.uploadedFileListdata.length < 1)
        this.myInput.nativeElement.value = "";

      // if (this.myInput.nativeElement.files && this.myInput.nativeElement.files.length > 0) {
      //   for (var i: number = 0; i < this.myInput.nativeElement.files.length; i++) {
      //     var filesss = this.myInput.nativeElement.files;
      //     console.log();
      //     // this.myInput.nativeElement.files.forEach((element, i) => {
      //       this.uploadedFileListdata.forEach(fileelement => {
      //         if (fileelement.name == this.myInput.nativeElement.files[i].name) {
      //          // this.myInput.nativeElement.files.splice(i, 1);
      //           this.myInput.nativeElement.files.slice(i, 1);

      //         }
      //       });

      //     // });
      //     //  this.uploadedFileListdata.splice(index, 1);
      //   }
      //}
    }

    else {
      file.flag = true;
      console.log(this.myInput.nativeElement.files);
      // this.myInput.nativeElement.value = "";
      this.uploadedFileListdata.forEach(fileelement => {
        if (fileelement.imagename == file.imagename) {
          fileelement.flag = true;
        }
      });
      this.OnImageDelete(file);
    }


  }
  filedownload(file: programcreationModel.FileModel, index): void {

  }
  OnhostAvailability(data: any): void {
    this.hostAvailability = data;
    this.preferred_time_slotsselected = false;
    this.round_the_yearselected = false;
    if (data == "round_the_year") {
      this.round_the_yearselected = true;
    }
    if (data == "preferred_time_slots") {
      this.preferred_time_slotsselected = true;
    }

   
  }
  CreatprogramEditDetailsRequest(Id: number): any {
    this.programEditDetails =
      {
        "id": "" + Id + "",
        "username": "" + localStorage.getItem("email") + "",
        "token": "" + localStorage.getItem("token_Id") + "",
        "login_status": "" + localStorage.getItem("status") + "",


      }
    return this.programEditDetails;
  }
  publishProgramDetailsRequest(Id: number): any {
    this.publishProgramDetails =
      {
        "publish_date":""+this.convertDate(this.publishDateCalanderForm.value.publish_startdate.date)+"",
        "id": "" + Id + "",
        "username": "" + localStorage.getItem("email") + "",
        "token": "" + localStorage.getItem("token_Id") + "",
        "login_status": "" + localStorage.getItem("status") + ""


      }
    return this.publishProgramDetails;
  }
  exportPDF() {
    window.print();
  }

  selectAll() {

    this.selectedAll = !this.selectedAll;
    // alert(this.careerLevelList.length);
    for (var i = 0; i < this.careerLevelList.length; i++) {

      this.careerLevelList[i].selected = this.selectedAll;

    }
    //this.carrer_Click();
    //this.checkIfAllSelected();

  }
  publish(isSave:boolean) {
    // alert(this.convertDate(this.publishDateCalanderForm.value.publish_startdate.date))
    if(!isSave){

    this.traineeshipService.programPublish('' + JSON.stringify(this.publishProgramDetailsRequest(this.reponseId)) + '').subscribe(
      (response) => {

        //this.allCreationList=response.dataRows;
        this.isLoading=true;
       this.nextEvent();
      },
      (err) => {
        this.errorMessage = err;

      });
    }
    else{
      this.nextEvent();
    }
    //this.nextEvent();
  }


  // getPreviewDetails() {
  //   this.isLoading = true;
  //   this.traineeshipService.programCreationExtra('{"Id":' + this.reponseId + ',"username":"' + localStorage.getItem("email") + '","token":"' + localStorage.getItem("token_Id") + '","login_status":"' + localStorage.getItem("status") + '"}').subscribe(
  //     (response) => {
  //       this.isLoading = false;
  //       this.programPreviewDetails = response.dataRows;
  //       this.errorMsgData = response.message;
  //       this.programImages = response.url;
  //       this.programImages_count = response.url.length;

  //       //  localStorage.setItem("imagescount",this.programImages_count);


  //       var newlist_final = [];
  //       var newlist;
  //       var array_final = [];
  //       for (let i = 0; i < this.programImages_count; i++) {

  //         let array_list =
  //         {
  //           small: this.programImages[i].url_images,
  //           medium: this.programImages[i].url_images,
  //           big: this.programImages[i].url_images,
  //         };
  //         //console.log(array_list);
  //         newlist = array_list;
  //         newlist_final[i] = newlist;
  //       }
  //       this.galleryImages = newlist_final
  //     },
  //     (err) => {
  //       this.isLoading = false;
  //       this.errorMessage = err;

  //     });
  // }


  onMultiEligiblecountriesChange(info: { data: any, value: string }) {
    if (info != null && info.value != null) {

      this.selectedcountries = '';

      for (let i = 0; i < info.data.length; i++) {
        this.currentcountry = (info.data[i].text);
        if (this.currentcountry.indexOf(' ') >= 0) {
          this.currentcountry = "'" + this.currentcountry + "'"
        }

        this.selectedcountries = this.selectedcountries + " ," + this.currentcountry;


        let selectedcountrieids = '';
        let currentcountryids: string;
        for (let i = 0; i < info.data.length; i++) {
          currentcountryids = (info.data[i].id);
          if (currentcountryids.indexOf(' ') >= 0) {
            currentcountryids = "'" + currentcountryids + "'"
          }

          selectedcountrieids = selectedcountrieids + " ," + currentcountryids;

        }

      }
    } else {

      this.selectedcountries = ""
    }

  }
  getSelectedCountiesListAll() {


    let selectedCountrieslist = this.selectedcountries.substring(1).trim();
    let finalselectedCountrieslist = "";

    finalselectedCountrieslist = selectedCountrieslist.split("+").join(",");



    return finalselectedCountrieslist;

  }

  //Common for all steps start

  //Common for all steps end



  //Step 1  start --title

  OnStep1Validation(): void {
    var Isvalid = true;


    this.PriorityMeritListData.forEach(element => {
      if (this.isOnsitetraineeship) {
        if (!element.priority_merit_cost || element.priority_merit_cost == "")
          element.priority_merit_weeks_valid = false;
      }
      if (!element.priority_merit_cost || element.priority_merit_cost == "")
        element.priority_merit_cost_valid = false;
      if (!element.priority_merit_cost || element.priority_merit_cost == "")
        element.priority_merit_discount_valid = false;
    });

    if (this.isOnlineMentorship) {
      Isvalid = false;
    }
    if (this.isOnlineTraineeShip) {
      Isvalid = false;
    }
    if (this.isOnsitetraineeship) {



      Isvalid = false;
    }
  }
  //Step 1  end   --title


  //Step 2  start

  OnStep2Validation(): void {
    var Isvalid = true;
    if (this.isOnlineMentorship) {
      Isvalid = false;
    }
    if (this.isOnlineTraineeShip) {
      Isvalid = false;
    }
    if (this.isOnsitetraineeship) {
      Isvalid = false;
    }
  }

  OnImageDelete(file: programcreationModel.FileModel) {
    var fileDetails =
    {
      "username": "" + localStorage.getItem("email") + "",
      "token": "" + localStorage.getItem("token_Id") + "",
      "login_status": "" + localStorage.getItem("status") + "",
      "id": "" + file.id + "",
      "url": "" + file.url + ""


    }

    this.traineeshipService.programDeleteImage('' + JSON.stringify(fileDetails) + '').subscribe(
      (response) => {

       // this.allCreationList = response.dataRows;
       
        // this.getPreviewDetails(response.data.id);
      },
      (err) => {
        this.errorMessage = err;

      });
  }

  oncountryChange(selectedValue) {
    this.selectedCountry = selectedValue;
    if(this.countryList!=null){
    for (var i = 0; i < this.countryList.length; i++) {
                
      if (this.countryList[i].id == this.selectedCountry) {
          
          this.countryName = this.countryList[i].text;
          
         
      }
  }
}
     //alert(this.countryName)
    


  }

  Onnon_profitClick() {
    this.non_profit_grantschecked = !this.non_profit_grantschecked
  }

  Onnih_grantsClick() {
    this.nih_grantschecked = !this.nih_grantschecked
  }

  createdefaultQuestion(): void {

    this.questionArray = [];
    let questionModaldata = new programcreationModel.QuestionsModel();
    questionModaldata.id = 0;
    questionModaldata.question = '';
    questionModaldata.answer = '';
    questionModaldata.category = 'individual';
    // questionModaldata.qa_id = '';
    this.questionArray.push(questionModaldata);
  }

  onChangeWeek_1(item: any) {

     debugger;
      if (item != null) {
        this.actualCost=item.priority_merit_cost
        // this.priorityWeekCost = item.priority_merit_cost - item.priority_merit_discount;
        this.priorityWeekCost = item.priority_merit_discount;

      }

  }
  // onChangeWeek(item: number) {
  //   {
      
      
  //     if (item && item > 0) {
  //       var filteredArray = this.PriorityMeritListData.filter(f => parseInt(f.priority_merit_weeks) == item);

  //       if (filteredArray.length) {
  //         var value = filteredArray[0];
  //         this.priority_merit_weeks = value.priority_merit_weeks;
         
  //         this.actualCost = value.priority_merit_cost;
        
  //         this.priorityWeekCost = parseInt(value.priority_merit_discount);
  //       }
  //     }else{
  //         this.priority_merit_weeks = '';
        
  //         this.actualCost = '';
  //         this.priorityWeekCost = '';
  //       }
  //   }
  // }


  AddPreferreddate() {
    if (this.preferredDatesList == null)
      this.preferredDatesList = [];

    let preferDate = new programcreationModel.preffered_datesmodel();
    preferDate.id = -1;
  
    this.preferredDatesList.push(preferDate);
  }


  GetMydate(date: string): any {
    if (date) {
      var leveldate_array = date.split('/');
      return { date: { year: Number(leveldate_array[2]), month: Number(leveldate_array[1]), day: Number(leveldate_array[0]) } }
    }
  }

  GetFormattedDate(inputdate: Date): string {
   
    if (inputdate) {
      var month = inputdate.getMonth() + 1;
      var day = inputdate.getDate();
      var year = inputdate.getFullYear();
      return year + "-" + month + "-" + day;
    }
  }

  OnAccountFilter(event: any): void {
    this.isLoading=true;
    this.searchtext = event
    if (event) {
      this.getUserJsonData(event);
      this.traineeshipService.getSearchFieldOfIntrestBySearchTerm('' + JSON.stringify(this.userDetails) + '').subscribe(
        (response) => {
          this.isLoading=false;

          this.AccountEmployerNameData = AppMethodModel.AppMethods.ToDDLDataItemsFromAccountQuickResults(response.dataRows);;
        });
    }
  }

  filter_list_save(): void {
    this.isLoading=true;
    if (this.searchtext != null && this.searchtext != "") {
      this.getUserJsonData(event);
      this.traineeshipService.filter_list_save('' + JSON.stringify(this.userDetails) + '').subscribe(
        (response) => {
          this.isLoading=false;

          this.AccountEmployerNameData = AppMethodModel.AppMethods.ToDDLDataItemsFromAccountQuickResults(response.dataRows);;
          // this.SelectedAccountEmployerData = AppMethodModel.AppMethods.ToDDLDataItemsFromAccountQuickResults(response.dataRows);;

        });
    }
  }



  getUserJsonData(searchtext: any): any {
    this.userDetails =
      {
        "username": "" + localStorage.getItem("email") + "",
        "token": "" + localStorage.getItem("token_Id") + "",
        "login_status": "" + localStorage.getItem("status") + "",
        "search_field": "" + this.searchtext + "",
      }
    return this.userDetails;
  }
  OnAccountEmployernameSelection(args: AppModel.DDLData[]): void {

    if (args && args.length > 0) {

      this.SelectedAccountEmployerData = args;

    }
    else {

    }
  }


  onValueChange(newDate: Date) {
    this.contract_startdate_local = newDate;
    this.contract_startdate = this.GetFormattedDate(newDate)

  }
  valueChangePublishDate(publishDate: Date){
    this.publish_startdate=this.GetFormattedDate(publishDate)

  }

  onHostAvailabilityStartDateValueChange(newDate: Date, item) {
    item.start_date_Local = newDate;
    item.start_date = this.GetFormattedDate(newDate)
  }

  onHostAvailabilityEndDateValueChange(newDate: Date, item) {
    item.end_date_Local = newDate;
    item.end_date = this.GetFormattedDate(newDate)
  }


  OnCountryCountryFilter(event: any): void {
    this.Countrysearchtext = event
    if (event) {
      // this.getUserJsonData(event);
      this.traineeshipService.getLocations('' + JSON.stringify(this.getUserJsonData(event)) + '').subscribe(
        //this.traineeshipService.getSearchFieldOfIntrestBySearchTerm('' + JSON.stringify(this.userDetails) + '').subscribe(
        (response) => {

          this.CountryLookupData = AppMethodModel.AppMethods.ToDDLDataItemsFromAccountQuickResults(response.dataRows);;
        });
    }
  }


  OnCountrynameSelection(args: AppModel.DDLData[]): void {

    if (args && args.length > 0) {

      this.SelectedCountryLookupData = args;

    }
    else {

    }
  }

hideUILoader(){
  this.isLoading=false;
  setTimeout(x=>$('#datatable_processing').hide(),100);
}

  backStep2(){
    this.getProgrameditdata(this.reponseId)
    this.hideUILoader();
    this.previousButtonEvent();
  }
  backStep3(){
    this.getProgrameditdata(this.reponseId);
    this.hideUILoader();
    this.previousButtonEvent();
  }
  backStep4(){
    this.getProgrameditdata(this.reponseId);
    this.hideUILoader();
    this.previousButtonEvent();
  }
  backStep5(){
    this.getProgrameditdata(this.reponseId);
    this.hideUILoader();
    this.previousButtonEvent();
  }
  backStep6(){
    this.getProgrameditdata(this.reponseId)
    this.previousButtonEvent();
  }
  copyText(val: string){
    let selBox = document.createElement('textarea');
      selBox.style.position = 'fixed';
      selBox.style.left = '0';
      selBox.style.top = '0';
      selBox.style.opacity = '0';
      selBox.value = val;
      document.body.appendChild(selBox);
      selBox.focus();
      selBox.select();
      document.execCommand('copy');
      document.body.removeChild(selBox);
    }
    afterPublish(){
      if(this.reponseId!=null||this.reponseId>0)
        this.router.navigate(['/',this.reponseId,'program-details'])
    }
    sendtoHost(){
      var hostDetails =
      {
        "username": "" + localStorage.getItem("email") + "",
        "token": "" + localStorage.getItem("token_Id") + "",
        "login_status": "" + localStorage.getItem("status") + "",
        "id": "" + this.reponseId+ "",
       
  
  
      }
  
      this.traineeshipService.sendtoHost('' + JSON.stringify(hostDetails) + '').subscribe(
        (response) => {
          this.hostmailResponse=response.message;
          alert(this.hostmailResponse)
  
        },
        (err) => {
          this.errorMessage = err;
  
        })
    }

    cancel(){
      if(confirm("Are you sure want to cancel")){
        this.router.navigate(['/','traineeship'])
      }
    }
    private publishDateConvertions(date: any): string {
      return (date) ? date.year + '-' + date.month + '-' + date.day : '';
  }
  exploreTrainee(){
    sessionStorage.setItem('selectedTraineeship','');
    sessionStorage.setItem('programListIsDefault','')
  }

}





