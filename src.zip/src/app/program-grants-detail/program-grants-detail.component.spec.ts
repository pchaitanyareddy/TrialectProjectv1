import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProgramGrantsDetailComponent } from './program-grants-detail.component';

describe('ProgramGrantsDetailComponent', () => {
  let component: ProgramGrantsDetailComponent;
  let fixture: ComponentFixture<ProgramGrantsDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProgramGrantsDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProgramGrantsDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
