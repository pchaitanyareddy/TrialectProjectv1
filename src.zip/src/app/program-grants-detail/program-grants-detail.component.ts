import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-program-grants-detail',
  templateUrl: './program-grants-detail.component.html',
  styleUrls: ['./program-grants-detail.component.css']
})
export class ProgramGrantsDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
