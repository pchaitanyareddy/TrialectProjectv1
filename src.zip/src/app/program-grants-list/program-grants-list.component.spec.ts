import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProgramGrantsListComponent } from './program-grants-list.component';

describe('ProgramGrantsListComponent', () => {
  let component: ProgramGrantsListComponent;
  let fixture: ComponentFixture<ProgramGrantsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProgramGrantsListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProgramGrantsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
