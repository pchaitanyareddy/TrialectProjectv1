import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute, } from '@angular/router';

import { TemplateNavigationComponent } from '../template/template-navigation.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TraineeshipService } from '../services/traineeship.service'
import { Select2OptionData } from 'ng2-select2';
import { CommonService } from '../services/common.service';
import * as programcreationModel from '../program-creation/program-creation-classes';
import * as AppModel from '../shared/shared-classes';
import * as AppMethodModel from '../shared/shared-methods';
//import { RecaptchaComponent } from 'ng-recaptcha/ng-recaptcha';
import * as ProgramModel from '../program-list/program-classes';
declare var $: any;

@Component({
  selector: 'app-program-grants-list',
  templateUrl: './program-grants-list.component.html',
  styleUrls: ['./program-grants-list.component.css']
})
export class ProgramGrantsListComponent implements OnInit {


  chkSearchAll: boolean = false;
  captcha: any;
  AccountEmployerNameData: AppModel.DDLData[];
  SelectedAccountEmployerData: AppModel.DDLData[];
  constructor(private router: Router,
    private route: ActivatedRoute, private traineeshipService: TraineeshipService, private formBuilder: FormBuilder) { }
  public exampleData: Array<Select2OptionData>;
  public careerArray: programcreationModel.careermodel[] = [];
  public options: Select2Options;
  public value: any;
  public current: string;
  public current1: string;
  professionIsOpen: boolean = false;
  traineeshipIsOpen: boolean = false;
  locationIsOpen: boolean = false;
  filedOfInterestIsOpen: boolean = false;
  fieldofInterestIsOpen: boolean = false;
  typeofProgramIsOpen: boolean = false;
  careerlevelIsOpen: boolean = false;
  allProgramList: any;
  errorMessage: any;
  programList: any;
  countryList: any;
  countryName:any;
  userDetails: any;
  selectedCountryId: number;
  selectedTagValue: string;
  isOnlineTraineeshipSelected: boolean;
  isOnsiteTraineeshipSelected: boolean;
  isOnlinementorshipSelected: boolean;
  appUrl: string;
  public fieldOfInteresetData: Array<Select2OptionData>;
  programListForm: FormGroup;
  submitFilterRequest: any;
  profession: string;
  traineeshipType: string;
  location: string;
  fieldOfIntereset: string;
  traineeship: string;
  careerLevel: string;
  userName: string;
  token: string;
  loginStatus: string;
  selectedCountry: string;
  typeOfProgram: string;
  selectedCountryName: string;
  word: string;
  loggedInUserRole: string;
  AddNewProgram: boolean = false
  loggedInUserName: string;
  tempcareerLevelList: any = []
  careerLevelList: any=[];
  selectedAll: boolean;
  careerSelected: string;
  resultsFound: number = null;
  results: any;
  isClicked: boolean;
  isLoading: boolean;
  PaginationOptions: ProgramModel.PaginationModel = new ProgramModel.PaginationModel();
  PageIndex: number;
  CaptchaValidate: boolean = false;
  typeid: number;
  intrestTypeName: string;
  CaptchaKey = '6LeYuSUUAAAAAG9w8ooauQTTGB0sr9jZF5jibmsA'
  selectedSorting: string;
  selectedfilterCountry: string;
  ParentName: string = "Fl"
  ShowModalPopUp: boolean = false;
  isAgree: boolean = false;
  islogin: boolean = false;
  checkTerms:boolean=false;
  conditionErrorMessage:string;
  searchwithall:string;
  ProgramId:number;
  isTraineeshipSelected:boolean;
  PrograType:string;
  ngOnInit() {
   
    if (localStorage.getItem("userId"))
      this.islogin = true;
    //if(localStorage.getItem("email"))
    this.route.params.subscribe(params => {

      this.typeid = params['typeid'];
      if (this.typeid != null && this.typeid > 0) {
        this.fieldofInterestIsOpen = true;
      }

      this.intrestTypeName = params['intrestTypeName'];
    });
    this.selectedSorting = $("#ddlSorting option:selected").text();
    this.selectedfilterCountry = $("#ddlCountry option:selected").text();
    this.PaginationOptions = {
      currentPage: 1,
      itemsPerPage: 5,
      totalItems: 0,
    };
    this.SelectedAccountEmployerData = [];
    if (this.typeid != null && this.typeid > 0 && this.intrestTypeName != null && this.intrestTypeName != "")
      this.SelectedAccountEmployerData.push(new AppModel.DDLData(this.typeid, this.intrestTypeName));
    // this.SelectedAccountEmployerData.push(new AppModel.DDLData(-1, 'text'));
    this.isLoading = true;
    this.isClicked = false;
    this.appUrl = CommonService.APP_URL;
    this.isOnlineTraineeshipSelected = false;
    this.isOnsiteTraineeshipSelected = false;
    this.isOnlinementorshipSelected = false;

    window.scrollTo(0, 0);
    let onlinetraineeshipType = localStorage.getItem("traineeshipTypeonline");
    let onsitetraineeshipType = localStorage.getItem("traineeshipTypeOnsite");
    let onlinementorshipType = localStorage.getItem("traineeshipTypeOnlineMentor");

    let isDefaultTabName=sessionStorage.getItem('programListIsDefault');
    if(isDefaultTabName == 'exploreTraineship')
    {
      this.isTraineeshipSelected = true;
      this.traineeshipIsOpen = true;

    }
    if(isDefaultTabName == 'FeaturedAreaOfInterest')
    {
      this.isTraineeshipSelected = false;
      this.fieldofInterestIsOpen = true
    }
    let traineeType = sessionStorage.getItem("selectedTraineeship");
    if(traineeType == "traineeship"){
      this.isOnlineTraineeshipSelected = true;
    }
    if(traineeType == "mentorship"){
      this.isOnlinementorshipSelected = true;
    }
    if(traineeType == "onsite"){
      this.isOnsiteTraineeshipSelected = true;
    }
    
    $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip();   
    });
    this.programListForm = this.formBuilder.group({
      fieldOfInterest: ['', Validators.required],
      country: [''],
      doctorCheck: [],
      biomedicalCheck: [],
      otherMedicalCheck: [],
      onlineTraineeship: [this.isOnlineTraineeshipSelected],
      onlineMentorship: [this.isOnlinementorshipSelected],
      onsiteTraineeship: [this.isOnsiteTraineeshipSelected],
      clinicalTraineeship: [],
      clinicalResearchTraineeship: [],
      translationalTraineeship: [],
      basicTranslationalTraineeship: [],
      careerLevel: [],
      recaptcha: ['', Validators.required],
      chkSearchAll: ['']
    });


    this.programList =
      {
        "traineeship_type": 'onlinementorship',
        "username": "" + localStorage.getItem("email") + "",
        "token": "" + localStorage.getItem("token_Id") + "",
        "login_status": "" + localStorage.getItem("status") + ""
      }


    this.value = [];

    this.options = {
      multiple: true
    }
    // this.selectedCountryId=1;
    // this.selectedCountryName='United States';

    this.userDetails =
      {
        "username": "" + localStorage.getItem("email") + "",
        "token": "" + localStorage.getItem("token_Id") + "",
        "login_status": "" + localStorage.getItem("status") + "",

      }



    this.getLocations();
    //this.getFieldInterest();
    this.getCareerLevelsAPI();
    if (this.PageIndex && this.PageIndex > 0){
      this.PaginationOptions.currentPage = this.PageIndex;
    }

    this.FetchPrograms(this.PaginationOptions.currentPage, this.PaginationOptions.itemsPerPage, true);
    
  }

  FetchPrograms(pageIndex: number, pageSize: number, fetchAll: boolean) {

    this.selectedSorting = $("#ddlSorting option:selected").text();
    this.selectedfilterCountry = $("#ddlCountry option:selected").text();
    
    if(this.fieldofInterestIsOpen||this.isOnlineTraineeshipSelected ||this.isOnlinementorshipSelected ||this.isOnsiteTraineeshipSelected){
      this.isClicked = true;
    }
    if (this.selectedSorting == null || this.selectedSorting == "")
      this.selectedSorting = "active"
    if (this.selectedSorting == "Active") {
      this.selectedSorting = "active"
    }
    else if (this.selectedSorting == "All") {
      this.selectedSorting = "all"
    }
    else if (this.selectedSorting == "Upcoming") {
      this.selectedSorting = "upcoming"
    }
    else if (this.selectedSorting == "Draft") {
      this.selectedSorting = "draft"
    }
    if(this.selectedCountry==undefined||this.selectedCountry==''){
      this.selectedCountry=''
    }
    if(this.chkSearchAll){
      this.searchwithall="yes";
    }
    else{
        this.searchwithall="no";
    }
    // alert(this.selectedCountry)
    this.tempcareerLevelList=[];
    // console.log(this.careerLevelList)

    this.careerLevelList.forEach(element => {
      if (element.selected || element.id > 0) {
        this.tempcareerLevelList.push(element);
      }
    });

    this.submitFilterRequest =
      {
        "profession": this.getProfession(),
        "traineeship_type": this.getTraineeshipType(),
        "location": this.selectedCountry == "Select" ? "" : this.selectedCountry,
        "fieldofinterest": this.getSelectedFieldOfInterest(),//"Pharmacology +oncology cardiology",
        "traineeship": this.getTypeOfProgram(), //"1,2,3,4", //type of program
       "career_level": this.tempcareerLevelList.filter(cr=>cr.selected).map(tcr=>tcr.id).join(','),
        //"career_level": this.getCareelLevel(),
        "username": localStorage.getItem("email"),
        "token": localStorage.getItem("token_Id"),//"3vuamdaytkg0o4w4ooosk400g8kcosk",
        "login_status": localStorage.getItem("status"),
        "filter": this.selectedSorting,
        "fetchall": fetchAll,
        "pageindex": pageIndex,
        "pagesize": pageSize,
        "searchwithall":this.searchwithall
      }

    this.traineeshipService.submitFilterData('' + JSON.stringify(this.submitFilterRequest) + '').subscribe(
      (response) => {
        this.isLoading = false;
        var count = 0;
        this.allProgramList = response.dataRows;
        if (this.allProgramList && this.allProgramList.length > 0) {
          this.allProgramList.forEach(element => {
            count = count + 1;
          });
        }
        this.PaginationOptions.totalItems = response.totalcount;
        this.results = response
        this.resultsFound = this.results.resultcount;
        localStorage.setItem("program_id", this.allProgramList.id);
        window.scrollTo(0, 0);

      },
      (error) => {
        this.isLoading = false;
        this.errorMessage = error;


      });
  }

  TestCapta(valid: any) {
    var ii = valid;
    // console.log(ii);
  }
  OnPageChange(page: number): void {
    this.FetchPrograms(page, this.PaginationOptions.itemsPerPage, false);
    this.PaginationOptions.currentPage = page;
  }
  handleCorrectCaptcha(event: any) {
    if (!event && !event.trim()) {
      this.CaptchaValidate = true;
    } else {
      this.CaptchaValidate = false;
    }
   // alert(this.CaptchaValidate);
  }
  carrer_Click() {

    this.careerSelected = this.careerLevelList.filter(x => x.selected).map(y => y.carreers + "," + y.id).join('/');
    let careerModal1 = new programcreationModel.careermodel();

    this.careerArray.push(careerModal1);

  }
  handleSuccess(event: any) {
    if (event && event.trim()) {
      this.CaptchaValidate = true;
    } else {
      this.CaptchaValidate = false;
    }
   // alert(this.CaptchaValidate);
  }
  public ngAfterViewInit(): void {

    this.loggedInUserRole = localStorage.getItem("role")
    this.loggedInUserName = localStorage.getItem("email")
    if ((this.loggedInUserRole != null && this.loggedInUserRole == 'ROLE_ADMIN'))
      this.AddNewProgram = true;
    else
      this.AddNewProgram = false;

  }
  toggleIcon(e){

  }
  onChangetermsCheckbox($event) {
    this.checkTerms = $event.target.checked;
  }
  getApplicantsListData(programID) {


    localStorage.setItem("programID", programID)

    this.router.navigate(['/', 'application-list'])
  }

  changed(info: { data: any, value: string }) {
    if (info != null && info.value != null) {

      this.word = '+';

      for (let i = 0; i < info.data.length; i++) {
        this.current = (info.data[i].text);
        if (this.current.indexOf(' ') >= 0) {
          this.current = "'" + this.current + "'"
        }

        this.word = this.word + " +" + this.current;

      }




    }
    else {

      this.word = ""
    }
  }


  readMoreClick(programID, programType) {
    localStorage.setItem("programID", programID);
    localStorage.setItem("programType", programType);
     
      var policy_check: any = localStorage.getItem("policy_check")
      if (policy_check=="yes") {
        this.ShowModalPopUp = false;
        this.router.navigate(['/', localStorage.getItem("programID"), 'program-details'])
      } 
      else{
        // alert("no policy check")
        this.ShowModalPopUp = true;
        // this.router.navigate(['/', localStorage.getItem("programID"), 'program-details'])
      }
        this.ProgramId=programID; 
        this.PrograType=programType
  }
  OnClose(): void {
	
	}
  keypressEvent() {

    this.selectedTagValue = String($('.select2-search__field').val());
    this.getFieldOfInterestBySearchTerm(this.selectedTagValue);
    

  }


  getFieldInterest() {

    this.isLoading = true;
    
    this.traineeshipService.getSearchFieldOfIntrest('' + JSON.stringify(this.userDetails) + '').subscribe(
      (response) => {
        this.isLoading = false;
        this.exampleData = response.dataRows;
      

      },
      (err) => {
        //this.errorMessage = err;
        this.isLoading = false;
        this.errorMessage = err;

      });


  }


  getFieldOfInterestBySearchTerm(searchTerm) {

    this.exampleData = this.exampleData.filter(m => m.text == searchTerm);


  }

  getLocations() {

    this.isLoading = true;
    //this.traineeshipService.getLocations('{"username":"santosh.d@smartims.com"}').subscribe(
    this.traineeshipService.getLocations('' + JSON.stringify(this.userDetails) + '').subscribe(
      (response) => {
        this.isLoading = false;
        this.countryList = response.dataRows;

      },
      (err) => {
        // this.errorMessage = err;
        this.isLoading = false;
        this.errorMessage = "Session has been expired, please sigout and Relogin";

      });

  }
  alertClosed() {
    this.errorMessage = null;
  }
  getCareerLevelsAPI() {

    this.isLoading = true;
    
    this.traineeshipService.programCareerlevel('' + JSON.stringify(this.userDetails) + '').subscribe(
      (response) => {
        this.isLoading = false;
        response.dataRows.forEach(o => {
          o.selected = o.selected == '0' ? false : true;
        });

        this.careerLevelList = response.dataRows;

      },
      (err) => {
        // this.errorMessage = err;
        this.isLoading = false;
        this.errorMessage = err;


      });

  }
  selectAll() {

    this.selectedAll = !this.selectedAll;
    // alert(this.careerLevelList.length);
    for (var i = 0; i < this.careerLevelList.length; i++) {

      this.careerLevelList[i].selected = this.selectedAll;

    }
    //this.carrer_Click();

    
    this.checkIfAllSelected();

  }
  checkIfAllSelected() {
    // this.selectedAll = this.careerLevelList.every(function(item:any) {
    //     return item.selected ;
    //   })

    // this.careerSelected = this.careerLevelList.filter(x => x.selected).map(y => "'" + y.carreers + "'").join(',');
    // let careerModal1 = new programcreationModel.careermodel();

    // this.careerArray.push(careerModal1);

    this.careerSelected = this.careerLevelList.filter(x => x.selected).map(y => ({ ...y, 'id': "" }));
  
    let careerModal1 = new programcreationModel.careermodel();

    this.careerArray.push(careerModal1);
  }

  ToggleChb(state: boolean) {
    this.careerLevelList.forEach(program => program.selected = state)
  }
  onChange(selectedValue) {
    this.selectedCountry = selectedValue;



  }


  getLoginStatus(): string {
    let loginStatus = '0';
    if (localStorage.getItem("email") != "undefined" && localStorage.getItem("email") != null) {
      loginStatus = '1';

    }

    return loginStatus;
  }

  getFilterSortingSelection(): string {
    let selectedSorting = 'All'

    return selectedSorting;

  }

  getCareelLevel(): string {


    let selectedCareerLevel = '';
    //selectedCareerLevel = "'phd','md'";

    if (this.programListForm.value.careerLevel1 == true)
      selectedCareerLevel = "'phd'";
    if (this.programListForm.value.careerLevel2 == true) {
      if (selectedCareerLevel != null && selectedCareerLevel != undefined)
        selectedCareerLevel = selectedCareerLevel + "," + "'MD'";
      else
        selectedCareerLevel = "'MD'";
    }
    if (this.programListForm.value.careerLevel3 == true) {
      if (selectedCareerLevel != null && selectedCareerLevel != undefined)
        selectedCareerLevel = selectedCareerLevel + "," + "'" + this.programListForm.value.careerLevel3 + "'";
      else
        selectedCareerLevel = "'" + this.programListForm.value.careerLevel3 + "'";
    }
    if (this.programListForm.value.careerLevel4 == true) {
      if (selectedCareerLevel != null && selectedCareerLevel != undefined)
        selectedCareerLevel = selectedCareerLevel + "," + "'" + this.programListForm.value.careerLevel4 + "'";
      else
        selectedCareerLevel = "'" + this.programListForm.value.careerLevel4 + "'";
    }
    if (this.programListForm.value.careerLevel5 == true) {
      if (selectedCareerLevel != null && selectedCareerLevel != undefined)
        selectedCareerLevel = selectedCareerLevel + "," + "'" + this.programListForm.value.careerLevel5 + "'";
      else
        selectedCareerLevel = "'" + this.programListForm.value.careerLevel5 + "'";
    }
    if (this.programListForm.value.careerLevel6 == true) {
      if (selectedCareerLevel != null && selectedCareerLevel != undefined)
        selectedCareerLevel = selectedCareerLevel + "," + "'" + this.programListForm.value.careerLevel6 + "'";
      else
        selectedCareerLevel = "'" + this.programListForm.value.careerLevel6 + "'";
    }
    if (this.programListForm.value.careerLevel7 == true) {
      if (selectedCareerLevel != null && selectedCareerLevel != undefined)
        selectedCareerLevel = selectedCareerLevel + "," + "'" + this.programListForm.value.careerLevel7 + "'";
      else
        selectedCareerLevel = "'" + this.programListForm.value.careerLevel7 + "'";
    }
    if (this.programListForm.value.careerLevel8 == true) {
      if (selectedCareerLevel != null && selectedCareerLevel != undefined)
        selectedCareerLevel = selectedCareerLevel + "," + "'" + this.programListForm.value.careerLevel8 + "'";
      else
        selectedCareerLevel = "'" + this.programListForm.value.careerLevel8 + "'";
    }
    if (this.programListForm.value.careerLevel9 == true) {
      if (selectedCareerLevel != null && selectedCareerLevel != undefined)
        selectedCareerLevel = selectedCareerLevel + "," + "'" + this.programListForm.value.careerLevel9 + "'";
      else
        selectedCareerLevel = "'" + this.programListForm.value.careerLevel9 + "'";
    }
    if (this.programListForm.value.careerLevel10 == true) {
      if (selectedCareerLevel != null && selectedCareerLevel != undefined)
        selectedCareerLevel = selectedCareerLevel + "," + "'" + this.programListForm.value.careerLevel10 + "'";
      else
        selectedCareerLevel = "'" + this.programListForm.value.careerLevel10 + "'";
    }
    if (this.programListForm.value.careerLevel11 == true) {
      if (selectedCareerLevel != null && selectedCareerLevel != undefined)
        selectedCareerLevel = selectedCareerLevel + "," + "'" + this.programListForm.value.careerLevel11 + "'";
      else
        selectedCareerLevel = "'" + this.programListForm.value.careerLevel11 + "'";
    }
    if (this.programListForm.value.careerLevel12 == true) {
      if (selectedCareerLevel != null && selectedCareerLevel != undefined)
        selectedCareerLevel = selectedCareerLevel + "," + "'" + this.programListForm.value.careerLevel12 + "'";
      else
        selectedCareerLevel = "'" + this.programListForm.value.careerLevel12 + "'";
    }

  
    return selectedCareerLevel;
  }

  getTypeOfProgram(): string {
    
    if (this.programListForm.value.clinicalTraineeship == true && this.programListForm.value.clinicalResearchTraineeship == true && this.programListForm.value.translationalTraineeship == true && this.programListForm.value.basicTranslationalTraineeship == true)
      this.typeOfProgram = "1,2,3,4";
    else if (this.programListForm.value.clinicalTraineeship == true && this.programListForm.value.clinicalResearchTraineeship == true && this.programListForm.value.translationalTraineeship == true && this.programListForm.value.basicTranslationalTraineeship == null)
      this.typeOfProgram = "1,2,3";
    else if (this.programListForm.value.clinicalTraineeship == true && this.programListForm.value.clinicalResearchTraineeship == true && this.programListForm.value.translationalTraineeship == null && this.programListForm.value.basicTranslationalTraineeship == null)
      this.typeOfProgram = "1,2";
    else if (this.programListForm.value.clinicalTraineeship == true && this.programListForm.value.clinicalResearchTraineeship == null && this.programListForm.value.translationalTraineeship == null && this.programListForm.value.basicTranslationalTraineeship == null)
      this.typeOfProgram = "1";
    else if (this.programListForm.value.clinicalTraineeship == null && this.programListForm.value.clinicalResearchTraineeship == true && this.programListForm.value.translationalTraineeship == true && this.programListForm.value.basicTranslationalTraineeship == true)
      this.typeOfProgram = "2,3,4";
    else if (this.programListForm.value.clinicalTraineeship == null && this.programListForm.value.clinicalResearchTraineeship == true && this.programListForm.value.translationalTraineeship == true && this.programListForm.value.basicTranslationalTraineeship == null)
      this.typeOfProgram = "2,3";
    else if (this.programListForm.value.clinicalTraineeship == true && this.programListForm.value.clinicalResearchTraineeship == null && this.programListForm.value.translationalTraineeship == true && this.programListForm.value.basicTranslationalTraineeship == null)
      this.typeOfProgram = "1,3";
    else if (this.programListForm.value.clinicalTraineeship == true && this.programListForm.value.clinicalResearchTraineeship == null && this.programListForm.value.translationalTraineeship == null && this.programListForm.value.basicTranslationalTraineeship == null)
      this.typeOfProgram = "2";
    else if (this.programListForm.value.clinicalTraineeship == true && this.programListForm.value.clinicalResearchTraineeship == null && this.programListForm.value.translationalTraineeship == true && this.programListForm.value.basicTranslationalTraineeship == true)
      this.typeOfProgram = "1,3,4";
    else if (this.programListForm.value.clinicalTraineeship == null && this.programListForm.value.clinicalResearchTraineeship == null && this.programListForm.value.translationalTraineeship == true && this.programListForm.value.basicTranslationalTraineeship == true)
      this.typeOfProgram = "3,4";
    else if (this.programListForm.value.clinicalTraineeship == null && this.programListForm.value.clinicalResearchTraineeship == null && this.programListForm.value.translationalTraineeship == true && this.programListForm.value.basicTranslationalTraineeship == null)
      this.typeOfProgram = "3";
    else
      this.typeOfProgram = "";

    //alert(this.typeOfProgram);
    return this.typeOfProgram;
  }

  getProfession(): string {
    let profession = "";
    if (this.programListForm.value.doctorCheck == true && this.programListForm.value.biomedicalCheck == true && this.programListForm.value.otherMedicalCheck == true)
      profession = "1,2,3";
    else if (this.programListForm.value.doctorCheck == true && this.programListForm.value.biomedicalCheck == true)
      profession = "1,2";
    else if (this.programListForm.value.doctorCheck == true && this.programListForm.value.otherMedicalCheck == true)
      profession = "1,3";
    else if (this.programListForm.value.biomedicalCheck == true && this.programListForm.value.otherMedicalCheck == true)
      profession = "2,3";
    else if (this.programListForm.value.doctorCheck == true)
      profession = "1";
    else if (this.programListForm.value.biomedicalCheck == true)
      profession = "2";
    else if (this.programListForm.value.otherMedicalCheck == true)
      profession = "3";

    return profession;

  }

  getTraineeshipType(): string {

    let traineeship = "";
    if (this.programListForm.value.onlineTraineeship == true && this.programListForm.value.onlineMentorship == true && this.programListForm.value.onsiteTraineeship == true)
      traineeship = "1,2,3";
    else if (this.programListForm.value.onlineTraineeship == true && this.programListForm.value.onlineMentorship == true && (this.programListForm.value.onsiteTraineeship == null || this.programListForm.value.onsiteTraineeship == false))
      traineeship = "1,2";
    else if (this.programListForm.value.onlineTraineeship == true && (this.programListForm.value.onlineMentorship == null || this.programListForm.value.onlineMentorship == false) && (this.programListForm.value.onsiteTraineeship == null || this.programListForm.value.onsiteTraineeship == false))
      traineeship = "1";
    else if ((this.programListForm.value.onlineTraineeship == null || this.programListForm.value.onlineTraineeship == false) && this.programListForm.value.onlineMentorship == true && this.programListForm.value.onsiteTraineeship == true)
      traineeship = "2,3";
    else if ((this.programListForm.value.onlineTraineeship == true || this.programListForm.value.onlineTraineeship == true) && this.programListForm.value.onlineMentorship == false && this.programListForm.value.onsiteTraineeship == true)
      traineeship = "1,3";
    else if ((this.programListForm.value.onlineTraineeship == null || this.programListForm.value.onlineTraineeship == false) && (this.programListForm.value.onlineMentorship == null || this.programListForm.value.onlineMentorship == false) && this.programListForm.value.onsiteTraineeship == true)
      traineeship = "3";
    else if ((this.programListForm.value.onlineTraineeship == null || this.programListForm.value.onlineTraineeship == false) && this.programListForm.value.onlineMentorship == true && (this.programListForm.value.onsiteTraineeship == null || this.programListForm.value.onsiteTraineeship == false))
      traineeship = "2";


    return traineeship;
  }

  getSelectedFieldOfInterest123() {

    var finalStringnew: string = null;
    if (this.SelectedAccountEmployerData && this.SelectedAccountEmployerData.length > 0) {
      this.SelectedAccountEmployerData.forEach(element => {
        if (!finalStringnew)
          finalStringnew = element.Text;
        else {
          if (this.chkSearchAll) {
            finalStringnew = "'"+finalStringnew+"'" + "+" + "'"+element.Text+"'"
          } else {
            finalStringnew = finalStringnew + "," + element.Text
          }
        }
        
      });
    }
   
    if (finalStringnew == null) {
      finalStringnew = "";
    }
    return finalStringnew;

  }
  getSelectedFieldOfInterest() {

    var selectedData = this.SelectedAccountEmployerData.map(sar=> "'"+sar.Text+"'" );
    if (this.chkSearchAll) {
      return selectedData.join('+');
    } else {
      return selectedData.join(',');
    }
  }

  submitFilterdata(refresh: boolean = false) {
    this.isLoading = true;
    this.isClicked = true;
    let selectedFieldOfInterest = this.getSelectedFieldOfInterest();
    let selectedCountry = $("#ddlCountry option:selected").text();
    let selectedSorting = $("#ddlSorting option:selected").text();
    window.scrollTo(0, 0);
    if (selectedSorting == "Active") {
      selectedSorting = "active"
    }
    else if (selectedSorting == "All") {
      selectedSorting = "all"
    }
    else if (selectedSorting == "Upcoming") {
      selectedSorting = "upcoming"
    }
    else if (selectedSorting == "Draft") {
      selectedSorting = "draft"
    }
    if (this.careerSelected == "" || this.careerSelected == undefined) {
      this.careerSelected = "";
    }
    else if (selectedCountry == "Select") {
      selectedCountry = ""

    }
    if (this.selectedCountry == undefined) {
      this.selectedCountry = ""

    }

    if (refresh) {
      this.PageIndex = 1;
      this.PaginationOptions.currentPage = this.PageIndex;
    } else {
      if (this.PageIndex && this.PageIndex > 0)
        this.PaginationOptions.currentPage = this.PageIndex;
    }
    this.FetchPrograms(this.PaginationOptions.currentPage, this.PaginationOptions.itemsPerPage, true);

  }

  onChange_SortBy() {
    this.isLoading = true;
    this.isClicked = true;
    this.selectedSorting = $("#ddlSorting option:selected").text();
    this.selectedfilterCountry = $("#ddlCountry option:selected").text();

    if (this.selectedSorting == "Active") {
      this.selectedSorting = "active"
    }
    else if (this.selectedSorting == "All") {
      this.selectedSorting = "all"
    }
    else if (this.selectedSorting == "Upcoming") {
      this.selectedSorting = "upcoming"
    }
    else if (this.selectedSorting == "Draft") {
      this.selectedSorting = "draft"
    }

   
    if (this.PageIndex && this.PageIndex > 0)
      this.PaginationOptions.currentPage = this.PageIndex;

    this.FetchPrograms(this.PaginationOptions.currentPage, this.PaginationOptions.itemsPerPage, true);


  }
  
  professionOpenClose(professionIsOpen: boolean): void {
    this.professionIsOpen = !professionIsOpen;

  }
  traineeshipOpenClose(traineeshipIsOpen: boolean): void {
    this.traineeshipIsOpen = !traineeshipIsOpen;

  }
  locationOpenClose(locationIsOpen: boolean): void {
    this.locationIsOpen = !locationIsOpen;

  }
  fieldofInterestOpenClose(fieldofInterestIsOpen: boolean): void {
    this.fieldofInterestIsOpen = !fieldofInterestIsOpen;

  }
  typeofProgramOpenClose(typeofProgramIsOpen: boolean): void {
    this.typeofProgramIsOpen = !typeofProgramIsOpen;

  }
  careerlevelOpenClose(careerlevelIsOpen: boolean): void {
    this.careerlevelIsOpen = !careerlevelIsOpen;

  }

  OnEdit(ProgramId: any, PrograTypeId: any): void {
    var policy_check: any = localStorage.getItem("policy_check")
    if (policy_check=="yes") {
      this.ShowModalPopUp = false;
    } else
      this.ShowModalPopUp = true;
      
   // this.router.navigate(['program-creation-data', ProgramId, PrograTypeId])
  }


  OnInPut(key: any) {
    // if (this.SelectedAccountEmployerData && this.SelectedAccountEmployerData.length > 0)

    this.SelectedAccountEmployerData = [];
  }

  OnAccountFilter(event: any): void {
    this.isLoading=true;

    if (event && event.length>2) {
      this.getUserJsonData(event);
      this.traineeshipService.getSearchFieldOfIntrestBySearchTerm('' + JSON.stringify(this.userDetails) + '').subscribe(
        (response) => {
          this.isLoading=false;

          this.AccountEmployerNameData = AppMethodModel.AppMethods.ToDDLDataItemsFromAccountQuickResults(response.dataRows);;
        });
    }
    else{
      this.AccountEmployerNameData=[];
    }
  }

  getUserJsonData(searchtext: any): any {
    this.userDetails =
      {
        "username": "" + localStorage.getItem("email") + "",
        "token": "" + localStorage.getItem("token_Id") + "",
        "login_status": "" + localStorage.getItem("status") + "",
        "search_field": "" + searchtext + "",
      }
    return this.userDetails;
  }



  PopulateBranchNameData(items: any): void {
    if (items && items.length > 0) {

      this.AccountEmployerNameData = AppMethodModel.AppMethods.ToDDLDataItemsFromAccountQuickResults(items);
    } else {

      this.AccountEmployerNameData = null;
    }
  }


  OnProgramedit(PrograType: any, ProgramId: number): void {
  
  this.router.navigate(['/', 'program-creation-data', ProgramId, PrograType])
    //this.router.navigate(['program-creation-data'])
  }

  programdetailsbrief(programid:number){
    this.ShowModalPopUp = true;
    this.ProgramId=programid;
    
  }




  OnchkSearchAll(chkSearchAll: boolean) {
    this.chkSearchAll = !this.chkSearchAll;
  }
  OnAccountEmployernameSelection(args: AppModel.DDLData[]): void {

    if (args && args.length > 0) {

      this.SelectedAccountEmployerData = args;

    }
    else {

    }
  }


  OnSave() {

    this.ShowModalPopUp = false;

  }

  OnModelClose() {
    if(this.checkTerms==false){
      this.conditionErrorMessage="please accept terms and condtions"

    }

    this.ShowModalPopUp = false;
  }



  OnAgreeSave(item: any): void {
    if (localStorage.getItem("userId")) {
      this.isAgree = item;
      if (item) {

        this.traineeshipService.agreesavepost('' + JSON.stringify(this.getAgreeUserJsonData()) + '').subscribe(
          (response) => {
            // alert(response.message)
            if (response.message == "Successfully updated") {
              this.ShowModalPopUp = false;
              localStorage.setItem("policy_check", 'yes')
              //program-details page
              this.router.navigate(['/',this.ProgramId , 'program-details'])
            }
            
          });
      }
    }
    else{
      //  alert("else on Agreesave")
        //program-details brief page
    // this.router.navigate(['/',this.ProgramId , 'program-details-brief'])
    this.router.navigate(['/',this.ProgramId , 'program-details'])
    }
  }

  getAgreeUserJsonData(): any {
    var atext = "";
    if (this.isAgree) {
      atext = "yes"
    } else {
      atext = "no"
    }
    this.userDetails =
      {
        "user_id": localStorage.getItem("userId"),
        "username": "" + localStorage.getItem("email") + "",
        "token": "" + localStorage.getItem("token_Id") + "",
        "login_status": "" + localStorage.getItem("status") + "",

        "policy_check": "" + atext + "",
      }
    return this.userDetails;
  }

resetData(){
  this.ngOnInit();
  this.programListForm.reset();
  this.SelectedAccountEmployerData = [];
  this.AccountEmployerNameData=[];
  this.isClicked=false;

}
removeDarkness(){
  $('#ModalAgreement').css('display','none')
}


}
