export class ProgramCreationRequest {
    constructor(
        public email: string,
        public password: string
    ) {
    }
}