import { Injectable } from '@angular/core';
import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
  HttpResponse
} from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Router, NavigationEnd,ActivatedRoute, } from '@angular/router';

@Injectable()
export class MyInterceptor implements HttpInterceptor {
 constructor(private router: Router,
    private route: ActivatedRoute,){}
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(req).map(event => {
            if (event instanceof HttpResponse ) {
                // console.log('helloooo',event);
                if(event.body.statuscode=='401'&& localStorage.getItem('session_check')=="true") {
                    console.log(event);
                    if (confirm("Session has expired please login again")) {
                        localStorage.clear();                                              
                        location.reload();
                        location.href=location.origin + '/';
                       
                    } 
                }
            }         
            return event;
        });
    }
}