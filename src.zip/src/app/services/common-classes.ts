export class UserDto{
    id:number;
    Name:string;
    DisplayName:string;
    IsLogin:boolean=false;
  }