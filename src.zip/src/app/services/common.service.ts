import { Injectable, OnInit } from '@angular/core';
import * as programcreationModel from '../program-creation/program-creation-classes';
import * as UserModel from './common-classes';
@Injectable({
  providedIn: 'root'
})
  
export class CommonService implements OnInit {
 public  ProgramTypeListData: programcreationModel.ProgramType[];
 public  Userdata:UserModel.UserDto=new UserModel.UserDto();
  constructor() {
    this.ProgramTypeListData = [];
    var ProgramTypeData: programcreationModel.ProgramType = new programcreationModel.ProgramType();
    ProgramTypeData.id = 1;
    ProgramTypeData.Name = "Online Trainee Fellowships";
    ProgramTypeData.Code = "onlinetraineeship";
    ProgramTypeData.RouthPath = "program-creation-data";
    this.ProgramTypeListData.push(ProgramTypeData);
    ProgramTypeData = new programcreationModel.ProgramType();
    ProgramTypeData.id = 2;
    ProgramTypeData.Name = "Online Mentorship";
    ProgramTypeData.Code = "onlinementorship";
    ProgramTypeData.RouthPath = "program-creation-data";
    this.ProgramTypeListData.push(ProgramTypeData);
    ProgramTypeData = new programcreationModel.ProgramType();
    ProgramTypeData.id = 3;
    ProgramTypeData.Name = "Onsite Trainee Fellowships";
    ProgramTypeData.Code = "onsitetraineeship";
    ProgramTypeData.RouthPath = "program-creation-data";
    this.ProgramTypeListData.push(ProgramTypeData);

  }
  ngOnInit() {
   
  }

  
  public static APP_URL = "http://172.24.2.52/trialect/"; //For dev environment
  
//public static APP_URL = "/"; //For live environment
  // public static APP_URL=""; //For local

  public static ROUTING_FOLDER_NAME = "/"; //For local
  // public displayHover=false

}
