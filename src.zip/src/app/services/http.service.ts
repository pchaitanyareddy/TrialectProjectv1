import { Injectable } from '@angular/core';
import {
	Http,
	Headers,
	RequestOptionsArgs,
	Request,
	Response,
	ConnectionBackend,
	RequestOptions
} from '@angular/http';
import { Observable } from 'rxjs/observable';
import { from } from 'rxjs';
import { fromPromise } from 'rxjs/observable/fromPromise';
import 'rxjs/add/operator/mergeMap';
declare var AWS: any;

export interface HttpRequestData {
	url: string | Request;
	options?: RequestOptionsArgs;
	body?: any;
	cancelRequest?: boolean;
}
@Injectable()
export class HttpService extends Http {
	
	constructor(protected _backend: ConnectionBackend, protected _defaultOptions: RequestOptions
		) {
		super(_backend, _defaultOptions);
		
	}

    public request(url: string | Request, options?: RequestOptionsArgs): Observable<Response> {
       
		const requestWithAuthorization = fromPromise(this.requestWithToken({ url, options }));

		const response = from(requestWithAuthorization).flatMap((data) => {
			return super.request(data.url, data.options);
		});
        
		return response;
	}

    private requestWithToken(data: HttpRequestData): Promise<HttpRequestData> {
		let API_PATH='https://9gp4i2pgi2.execute-api.us-east-1.amazonaws.com';    
		let token='eyJraWQiOiJDR2lMcE5lY2tGbERuNHZHamNaYnlpczNHTWRoXC9QXC9Gd0srcnY1dXhFOXM9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiI4ZGZiZmI1Yy1jNmMyLTRjYmUtOTFiNC01ZmY0OWVhYWI0ZGYiLCJjb2duaXRvOmdyb3VwcyI6WyJNZWRDb25BZG1pbiJdLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiY29nbml0bzpwcmVmZXJyZWRfcm9sZSI6ImFybjphd3M6aWFtOjo0NDQ0NDcwNDc4NzM6cm9sZVwvdXNlcnBvb2wtbWVkY29uLWFkbWluIiwiaXNzIjoiaHR0cHM6XC9cL2NvZ25pdG8taWRwLnVzLWVhc3QtMS5hbWF6b25hd3MuY29tXC91cy1lYXN0LTFfYktSS0ZjTXFBIiwicGhvbmVfbnVtYmVyX3ZlcmlmaWVkIjpmYWxzZSwiY29nbml0bzp1c2VybmFtZSI6InJhbWVzaC5uQHNtYXJ0aW1zLmNvbSIsImdpdmVuX25hbWUiOiJSYW1lc2giLCJjb2duaXRvOnJvbGVzIjpbImFybjphd3M6aWFtOjo0NDQ0NDcwNDc4NzM6cm9sZVwvdXNlcnBvb2wtbWVkY29uLWFkbWluIl0sImF1ZCI6IjNkNWU0ZmptMWljYWhjYjBycDFycTA2NzE1IiwiZXZlbnRfaWQiOiJkNzhkMmU1Ny00YzcxLTExZTktYThjMi0wYjMxZGJkZWMyNDUiLCJ0b2tlbl91c2UiOiJpZCIsImF1dGhfdGltZSI6MTU1MzIzODc0NCwibmFtZSI6IlJhbWVzaCBOZWVydW1hbGxhIiwicGhvbmVfbnVtYmVyIjoiKzkxOTk4NTQ5ODQ4MyIsImV4cCI6MTU1MzI0MjM0NCwiaWF0IjoxNTUzMjM4NzQ0LCJmYW1pbHlfbmFtZSI6Ik5lZXJ1bWFsbGEiLCJlbWFpbCI6InJhbWVzaC5uQHNtYXJ0aW1zLmNvbSJ9.m13dctqtIzigTMMA9xStW0o6EbgkoWwV_V3wnRqMTR4A-qyvV5_IHyC-Pr-djG4K8gptwTHhD-21_nILz8lh-_obU4uSYP6daaOdHUGmcIGdfaUlTpfPNFDAtk5Hw-NgEHRFiXa3hzR07sfQlLOyY-QcFH4DuPJ4hg6SB9g8yuyTumpcOHba7d6C5RbhVH9Att78qeGAun2rvoZo0sn7iGbCOiNso0ZL3J_sop38wY2rL6hMvka2t_HS6q68LhPyEvuCEYQyORymQqM-uDMlSrMIKSGAQ09wuRgIaoORY8JBlvsf9QFDObIC9K4KL6WbwAjO3UkgXyGbvKo4OqkEZQ';
		return new Promise((resolve) => {
			if (typeof data.url === 'string') {
				if (data.url.startsWith(API_PATH)) {
					if (!data.options) {
						data.options = { headers: new Headers() };
					}
					data.options.headers.set('Authorization', token);
										}
										data.options.headers.set('Authorization', token);
			} else {
				if (data.url.url.startsWith(API_PATH)) {
					// we have to add the token to the url object
					data.url.headers.set('Authorization', token);
					}
										data.url.headers.set('Authorization', token);
			}
			resolve(data);
			
		});
	}
}
