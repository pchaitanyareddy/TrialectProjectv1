import { Injectable } from '@angular/core';
import { Response, Http, URLSearchParams, RequestOptions, RequestMethod } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs-compat/operator/map';
import {ProgramCreationRequest} from '../request/programCreation-request'


@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http: Http) { }
  //Common_URL='http://172.24.4.54/traineeship.trialect/';
  //Common_URL="http://172.24.2.52/traineeship/";
  //Common_URL="http://54.226.10.106/traineeship/";
  Common_URL= "https://www.smartims.com/traineeship/";
  
public validateLoginUser(userName:string)
// public validateLoginUser(request: ProgramCreationRequest): Observable<(any)>
{


 // return this.http.post('https://www.smartims.com/traineeship/user/login_check', userName)
   return this.http.post(this.Common_URL+'user/login_check', userName)
        // .map((res: Response) => res.json())
        .map((res: Response) => res.json())
        .catch((error: any) => Observable.throw(error.json().message || 'Server error'));


}

}
