import { Injectable } from '@angular/core';
import { Response, URLSearchParams, RequestOptions, RequestMethod } from '@angular/http';
import { HttpClient, HttpHeaders }
  from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { map } from 'rxjs-compat/operator/map';

@Injectable()
export class TraineeshipService
{
    headers: any;
    options: any;
    constructor(private http: HttpClient) {
    }
    //  Common_URL='http://172.24.4.54/traineeship.trialect/';

 Common_URL="http://172.24.2.52/traineeship/";
 //Common_URL="/traineeship/";//live 
//Common_URL="http://3.212.209.96/traineeship/";

  public validateLoginUser(userName:string)
// public validateLoginUser(request: ProgramCreationRequest): Observable<(any)>
{


 // return this.http.post('https://www.smartims.com/traineeship/user/login_check', userName)
   return this.http.post(this.Common_URL+'user/login_check', userName)
        // .map((res: Response) => res.json())
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));


}
public forgetPassword(email:string):any{
  
        // return this.http.post('https://www.smartims.com/traineeship/user/login_check', userName)
          return this.http.post(this.Common_URL+'user/forget_password', email)
               // .map((res: Response) => res.json())
             
               .catch((error: any) => Observable.throw(error.message || 'Server error'));
       
}


    public getProgramList(programList:string): any {
        
        this.headers = new Headers({'Content-Type': 'application/json'});
        // this.options= new RequestOptions({ headers: this.headers})
        // var requestoptions = new RequestOptions({
        //     method: RequestMethod.Post,
        //     url: 'http://127.0.0.1/traineeship.trialect/programlist/program_list',
        //     headers: this.headers,
        //     body: JSON.stringify(programList)
        // })
        return this.http.post(this.Common_URL+'programlist/program_list', programList)
       // return this.http.post(this.Common_URL+'programlist/program_list',programList)
       
       .catch((error: any) => Observable.throw(error.message || 'Server error'));
    }
    public getSearchFieldOfIntrest(searchField:string):  any {
        
        return this.http.post(this.Common_URL+'filter/filter_list_all',searchField)
       
        .catch((error: any) => Observable.throw(error.message || 'Server error'));
    }

    public getSearchFieldOfIntrestBySearchTerm(searchTerm:string): any {
       
        return this.http.post(this.Common_URL+'filter/filter_list', searchTerm)
      //  .map(res =>{ res})
       
        .catch((error: any) => Observable.throw(error.message || 'Server error'));
    }



    public getProgramView(programId:string): any {
        
        
        return this.http.post(this.Common_URL+'Programview/program_view',programId)
       
        .catch((error: any) => Observable.throw(error.message || 'Server error'));

    }
    public getProgramViewReviews(programId:string): any {
        
        //http://localhost/traineeship.trialect/programview/program_view_reviews
        return this.http.post(this.Common_URL+'Programview/program_view_reviews',programId)
          
            .catch((error: any) => Observable.throw(error.message || 'Server error'));
    }
    public getProgramViewQuestions(programId:string): any {
        
        //http://localhost/traineeship.trialect/programview/program_view_questions
        return this.http.post(this.Common_URL+'Programview/program_view_questions',programId)
          
            .catch((error: any) => Observable.throw(error.message || 'Server error'));
    }

    public getLocations(searchField:string): any {
       
         return this.http.post(this.Common_URL+'filter/country', searchField)
       // return this.http.post(this.Common_URL+'filter/country', searchField)
       
        .catch((error: any) => Observable.throw(error.message || 'Server error'));
    }

    public submitFilterData(submitRequest:string): any {
        return this.http.post(this.Common_URL+'filter/filter_submit', submitRequest)
       // return this.http.post(this.Common_URL+'filter/filter_submit', submitRequest)
      
        .catch((error: any) => Observable.throw(error.error || 'Server error 123'));

    }

    public getFAQs(faqsRequest:string): any {
       
        return this.http.post(this.Common_URL+'faqs/result_list', faqsRequest)
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));
    }

    public getApplicantsList(applicantListRequest:string): any {
       
        return this.http.post(this.Common_URL+'applicants_list/applicant_list', applicantListRequest)
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));
    }

    public programCreation(programCreationRequest:string):any 
    {

        // return this.http.post(this.Common_URL+'programcreate/create', programCreationRequest)
        return this.http.post(this.Common_URL+'programcreate/create', programCreationRequest)
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));

    }
    public programPublish(programCreationRequest:string):any 
    {

        // return this.http.post(this.Common_URL+'programcreate/create', programCreationRequest)
        return this.http.post(this.Common_URL+'programcreate/publish', programCreationRequest)
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));

    }
    public programCareerlevel(programCareerLevel:string):any 
    {

        return this.http.post(this.Common_URL+'filter/career_level', programCareerLevel)
        // return this.http.post(this.Common_URL+'programcreate/create', programCreationRequest)
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));

    }
    public programCareerlevelCreate(programCareerLevel:string):any 
    {

        return this.http.post(this.Common_URL+'filter/career_level_program', programCareerLevel)
        // return this.http.post(this.Common_URL+'programcreate/create', programCreationRequest)
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));

    }
    public recentPost(recentposts:string):any 
    {

        return this.http.post(this.Common_URL+'filter/recent_posts', recentposts)
        // return this.http.post(this.Common_URL+'programcreate/create', programCreationRequest)
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));

    }
    public recentReviews(recentReviews:string):any 
    {

        return this.http.post(this.Common_URL+'filter/recent_reviews', recentReviews)
        // return this.http.post(this.Common_URL+'programcreate/create', programCreationRequest)
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));

    }
    public applyingForm(recentReviews:string):any 
    {

        return this.http.post(this.Common_URL+'applicants_list/applicant_process', recentReviews)
        // return this.http.post(this.Common_URL+'programcreate/create', programCreationRequest)
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));

    }
    public recentPostProgramWise(recentReviews:string):any 
    {

        return this.http.post(this.Common_URL+'filter/recent_posts_programvise', recentReviews)
        // return this.http.post(this.Common_URL+'programcreate/create', programCreationRequest)
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));

    }
    public ProgramBasedLogistics(programId:string):any 
    {

        return this.http.post(this.Common_URL+'programview/program_based_logistics', programId)
       
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));

    }
    public fieldOfIntrestHome(requestdata:string):any 
    {

        return this.http.post(this.Common_URL+'filter/filter_list_home', requestdata)
       
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));

    }
    public programCreationExtra(extraData:string):any 
    {

        return this.http.post(this.Common_URL+'programedit/edit', extraData)
       
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));

    }
    public applicantList(Data:string):any 
    {

        return this.http.post(this.Common_URL+'applicants_list/applicants_display', Data)
       
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));

    }
    public programviewPreview(Data:string):any 
    {

        return this.http.post(this.Common_URL+'programview/program_view_preview', Data)
       
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));

    }

    public filter_list_save(Data:string):any 
    {

        return this.http.post(this.Common_URL+'filter/filter_list_save', Data)
       
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));

    }
   
    public registration(Data:string):any 
    {

        return this.http.post(this.Common_URL+'registration/register', Data)
       
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));

    }
    public programDeleteImage(programDeletionRequest:string):any{
        return this.http.post(this.Common_URL+'programedit/delete_file', programDeletionRequest)
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));
        }
    public askQuestion(askquestionRequest:string):any{
            return this.http.post(this.Common_URL+'programcreate/program_questions_create', askquestionRequest)
          
            .catch((error: any) => Observable.throw(error.message || 'Server error'));
    }
    public askQuestionUpdate(askquestionUpdateRequest:string):any{
        return this.http.post(this.Common_URL+'programcreate/program_questions_update', askquestionUpdateRequest)
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));
    }
    public contactUs(contactUsRequest:string):any{
        return this.http.post(this.Common_URL+'contact_us/create', contactUsRequest)
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));
    }
    public sendtoHost(askquestionUpdateRequest:string):any{
        // http://172.24.2.52/trialect/programcreate/send_host
        return this.http.post(this.Common_URL+'programcreate/send_host', askquestionUpdateRequest)
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));
    }
    public recentPostProgramwise(Request:string):any{
        // http://172.24.2.52/trialect/programcreate/send_host
        return this.http.post(this.Common_URL+'filter/recent_posts_programvise', Request)
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));
    }
    public otherRelaventFiles(Request:string):any{
        // http://172.24.2.52/trialect/programcreate/send_host
        return this.http.post(this.Common_URL+'applicants_list/applicants_display_otherdocs', Request)
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));
    }
 

    public applicantStatus(Request:string):any{
        // http://172.24.2.52/trialect/programcreate/send_host
        return this.http.post(this.Common_URL+'applicants_process/program_applicant_status', Request)
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));
    }
    public applicantAprove(Request:string):any{
        // http://172.24.2.52/traineeship/applicants_process/approve
        return this.http.post(this.Common_URL+'applicants_process/approve', Request)
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));
    }
    public applicantSendAll(Request:string):any{
       
        return this.http.post(this.Common_URL+'applicants_process/send_all', Request)
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));
    }
    public reviewAprove(Request:string):any{
        //http://172.24.2.52/traineeship/review/review_approve
            return this.http.post(this.Common_URL+'review/review_approve', Request)
          
            .catch((error: any) => Observable.throw(error.message || 'Server error'));
        }
public reviewImagesAprove(Request:string):any{
//http://172.24.2.52/traineeship/review/review_approve_images
    return this.http.post(this.Common_URL+'review/review_approve_images', Request)
  
    .catch((error: any) => Observable.throw(error.message || 'Server error'));
}
public reviewImagesDelete(Request:string):any{
    //http://172.24.2.52/traineeship/review/review_delete_images
        return this.http.post(this.Common_URL+'/review/review_delete_images', Request)
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));
    }

    public resizeImage(img, callback) {
		return img.onload = () => {
            
			 let width = img.width;
			 let height = img.height;
			// let MAX_HEIGHT = 250;
			// let MAX_WIDTH = 250;
			// let MIN_HEIGHT = 125;
			// let MIN_WIDTH = 125;
			// let ratio;

			// Set the WxH to fit the min and max values (but maintain proportions)
			// if (width >= height) {
			// 	if (width >= MAX_WIDTH) {
			// 		height *= MAX_WIDTH / width;

			// 		if (height <= MIN_HEIGHT) {
			// 			ratio = MIN_HEIGHT / height;
			// 			height = MIN_HEIGHT;
			// 			width = MAX_WIDTH * ratio;
			// 		} else {
			// 			width = MAX_WIDTH;
			// 		}
			// 	}
			// } else {
			// 	if (height >= MAX_HEIGHT) {
			// 		width *= MAX_HEIGHT / height;

			// 		if (width <= MIN_WIDTH) {
			// 			ratio = MIN_WIDTH / width;
			// 			width = MIN_WIDTH;
			// 			height = MIN_HEIGHT * ratio;
			// 		} else {
			// 			height = MAX_HEIGHT;
			// 		}
			// 	}
			// }

			// Create a canvas object
            let canvas = document.createElement('canvas');
            if(width<250){
                canvas.width=width;
            }
            else{
                canvas.width = 250;
            }
            if(height<200){
                canvas.height=height;
            }
            else{
                canvas.height = 250;
            }
			
			// canvas.height = height;

			let ctx = canvas.getContext('2d');
			ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

			// Get this encoded as a png
			let dataUrl = canvas.toDataURL('image/png');

			// Callback with the results
			callback(dataUrl);
		};
    }
    
    public agreesavepost(Data:string):any 
    {

        return this.http.post(this.Common_URL+'programview/program_view_update_policy', Data)
       
      
        .catch((error: any) => Observable.throw(error.message || 'Server error'));

    }

   
    
}
