import { Component, OnDestroy, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { UUID } from 'angular2-uuid';




import * as AppModel from '../shared-classes';

//declare var _: any;
import * as _ from 'underscore';



@Component({
    selector: 'my-auto-select',
    templateUrl: './my-auto-select.component.html'
})
export class MyAutoSelectComponent implements OnDestroy, OnInit {
    private _items: AppModel.DDLData[] = [];

    @Output() OnSetLocation: EventEmitter<any> = new EventEmitter<any>();
    @Output() OnSelectedItem: EventEmitter<any> = new EventEmitter<any>();
    @Output() OnFilterItem: EventEmitter<any> = new EventEmitter<any>();

    @Input() ParentName: string = '';
    @Input() ControlId: string = UUID.UUID();
    @Input() Multiple: boolean = false;
    @Input() EnableRemoteSearch: boolean = false;
    @Input() SelectedItems: AppModel.DDLData[];
    @Input() Disabled: boolean = false;
    @Input() EnforceMinCharCheck: boolean = true;
    @Input() MaxAllowed: number = -1;
    @Input() AllowDefaultSelect: boolean = false;
    selectany: string = "Type three characters"
    @Input() set Items(value: AppModel.DDLData[]) {
        this._items = value;
        this.BindFilteredData(this.EnableRemoteSearch);
    }
    get Items(): AppModel.DDLData[] {
        return this._items;
    }

    FilteredItems: AppModel.DDLData[];

    ShowItems: boolean = false;
    Query: string = '';
    IsMouseActive: boolean = false;
    IsMaxReached: boolean = false;

    constructor(
    ) {

    }

    ngOnDestroy() {

    }

    ngOnInit() {

        // this.broadcastService.On(AppModel.BroadcastEventType.Reset)

        //     .subscribe((args: any) => {
        //         this.Reset(args);
        //     });
    }


    Reset(parentName: string): void {
        if (parentName && this.ParentName && parentName.length > 0 && this.ParentName.length > 0 && parentName === this.ParentName) {
            var tt = this.Items;
            if (this.SelectedItems && this.SelectedItems.length > 0) {
                this.SelectedItems = null;
                this.Query = "";
                this.OnSelectionChanged();
            }
        }
    }

    OnSelected(value: AppModel.DDLData): void {
        if (value && (value.Id > 0 || (this.AllowDefaultSelect && value.Id === -1))) {
            if (!this.SelectedItems || (!this.Multiple))
                this.SelectedItems = [];
            if (this.SelectedItems.indexOf(value) == -1) {
                var Notexist: boolean = true;
                this.SelectedItems.forEach(element => {
                    if (element.Id == value.Id) {
                        Notexist = false;
                    }
                });
                if (!_.findWhere(this.SelectedItems, { Id: value.Id }))
                    this.SelectedItems.push(value);
                // if (Notexist)
                //     this.SelectedItems.push(value);
            }
            this.Query = '';
            this.ShowItems = false;
        }

        this.OnSelectionChanged();
    }

    OnRemoved(value: AppModel.DDLData): void {
        if (value && (value.Id > 0 || (this.AllowDefaultSelect && value.Id === -1))) {
            this.SelectedItems.splice(this.SelectedItems.indexOf(value), 1);
            this.ShowItems = false;
        }

        this.OnSelectionChanged();
    }

    OnMouseEvent(active: boolean): void {
        this.IsMouseActive = active;
    }

    BindFilteredData(hasFocus: boolean): void {
        var qryText: string = this.Query;
        if (qryText != "") {
            this.FilteredItems = _.filter(this.Items, (t: AppModel.DDLData) => {
                return t.Text.toLowerCase().indexOf(qryText.toLowerCase()) > -1;
            });
            // this.FilteredItems=[]
            // this.Items.forEach(element => {
            //     this.FilteredItems.push()
            // });
        }
        else {
            this.FilteredItems = this.Items;
        }

        if (hasFocus && this.FilteredItems && this.FilteredItems.length > 0) {
            this.ShowItems = true;

        } else {
            this.ShowItems = this.IsMouseActive;
        }

    }

    OnFilter(hasFocus: boolean): void {

        if (this.EnableRemoteSearch) {
            if (this.EnforceMinCharCheck) {
                if (this.Query.length >= 3) {
                    this.OnFilterItem.next(this.Query);
                }
            } else {
                this.OnFilterItem.next(this.Query);
            }

        } else {
            this.BindFilteredData(hasFocus);
        }


    }


    OnSelectionChanged(): void {
        if (this.MaxAllowed > 0 && this.SelectedItems && this.SelectedItems.length === this.MaxAllowed) {
            this.IsMaxReached = true;
        } else {
            this.IsMaxReached = false;
        }
        this.OnSelectedItem.next(this.SelectedItems);
    }

    OnSetLocationChanged(item: AppModel.DDLData): void {
        if (item && item.SetLocation !== undefined && item.SetLocation !== null) {
            item.SetLocation = !item.SetLocation;
            this.OnSetLocation.next(item);
        }
    }

    GetSendRequestTooltip(sendRequest?: boolean): string {
        if (sendRequest !== undefined && sendRequest !== null) {
            return sendRequest ? 'LABEL.REQUEST_WILLBE_SENT' : 'LABEL.REQUEST_WILLNOTBE_SENT';
        } else {
            return '';
        }
    }

    GetDoneTooltip(done?: boolean): string {
        if (done !== undefined && done !== null) {
            return done ? 'LABEL.DONE' : 'LABEL.NOT_DONE';
        } else {
            return '';
        }
    }

    GetAssignedTooltip(assigned?: boolean): string {
        if (assigned !== undefined && assigned !== null) {
            return assigned ? 'LABEL.ASSIGNED' : 'LABEL.NOT_ASSIGNED';
        } else {
            return '';
        }
    }
}