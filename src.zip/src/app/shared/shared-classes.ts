
export class DDLData  {
    Id: number;
    Text: string;
    Code: string;
    ParentId?: number;
    SecondaryText?: string;
    ParentText?: string;
    Done?: boolean;
    Assigned?: boolean;
    SetLocation?: boolean;
    SendRequest?: boolean;
    DisplayOrder: number;
    IsSelected: boolean;

    constructor(id: number, text: string, parentId?: number, secondaryText?: string, done?: boolean, assigned?: boolean, setLocation?: boolean, sendRequest?: boolean, parentText?: string) {
        this.Id = id;
        this.Text = text;
        this.ParentId = parentId;
        this.SecondaryText = secondaryText;
        this.ParentText = parentText;
        this.Done = done;
        this.Assigned = assigned
        this.SetLocation = setLocation;
        this.SendRequest = sendRequest;
    }
}

export class Textid  {
    id:number;
    text:string;
}