 
    import * as AppModel from './shared-classes';
       
    
    export class AppMethods {
    
    
    
    static ToDDLDataItemsFromAccountQuickResults(items: AppModel.Textid[]): AppModel.DDLData[] {
        if (items && items.length > 0) {
            var result: AppModel.DDLData[] = [];
            items.forEach(item => {
                var retItem = this.ToDDLDataFromAccountQuickResult(item);
                if (retItem)
                    result.push(retItem);
            });
            return result;
        }
        return null;
    }

    static ToDDLDataFromAccountQuickResult(item: AppModel.Textid): AppModel.DDLData {
        if (item && item.id && item.id > 0)
            return new AppModel.DDLData(Number(item.id), item.text);
        return null;
    }
}