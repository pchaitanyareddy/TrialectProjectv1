import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-my-select',
  templateUrl: './my-select.component.html',
  styleUrls: ['./my-select.component.css']
})
export class MySelectComponent implements OnInit {
  selectedCountryId:number;
    constructor() { }

  ngOnInit() {
  }
  @Input()
  ddlData: any;
  @Input() selectedItemId: number;
  @Output() Changed: EventEmitter<any> = new EventEmitter<any>()

  onChange1(event: any) {
    var tempddlData: any;
    this.ddlData.forEach(element => {
      if(element.id=== event){
        tempddlData=element;
      }
    });
    this.Changed.emit(tempddlData);
  }
}
