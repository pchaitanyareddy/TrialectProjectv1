import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrePriorityWeekSelectComponent } from './pre-priority-week-select.component';

describe('PrePriorityWeekSelectComponent', () => {
  let component: PrePriorityWeekSelectComponent;
  let fixture: ComponentFixture<PrePriorityWeekSelectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrePriorityWeekSelectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrePriorityWeekSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
