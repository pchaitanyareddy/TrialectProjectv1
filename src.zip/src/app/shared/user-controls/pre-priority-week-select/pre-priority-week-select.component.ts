
import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';
import  * as PCModel from '../../../program-creation/program-creation.classes'
@Component({
  selector: 'app-pre-priority-week-select',
  templateUrl: './pre-priority-week-select.component.html',
  styleUrls: ['./pre-priority-week-select.component.css']
})
export class PrePriorityWeekSelectComponent implements OnInit {
  selectedItemId:number;
  constructor() { }

  ngOnInit() {
  }
  @Input()
  priorityMeritddlData:any;
  @Output() Changed:EventEmitter<PCModel.PriorityMeritmodel>=new EventEmitter<PCModel.PriorityMeritmodel>()
  onChange(event: any) {
    var tempddlData: PCModel.PriorityMeritmodel;
    this.priorityMeritddlData.forEach(element => {
      if(element.id== event){
        tempddlData=element;
      }
    });
    this.Changed.emit(tempddlData);
  }
}

 