import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PriorityWeekSelectComponent } from './priority-week-select.component';

describe('PriorityWeekSelectComponent', () => {
  let component: PriorityWeekSelectComponent;
  let fixture: ComponentFixture<PriorityWeekSelectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PriorityWeekSelectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PriorityWeekSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
