import { Component, HostListener, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute ,ParamMap,RoutesRecognized} from '@angular/router';
import { LocationStrategy } from '@angular/common';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { LoginService } from '../services/login.service';
import { ProgramCreationRequest } from '../request/programCreation-request';
import { TraineeshipService } from '../services/traineeship.service'
import '../../assets/js/crawler.js';
import { CommonService } from '../services/common.service';
import * as _ from 'underscore';
import * as AppModel from '../shared/shared-classes';
import * as AppMethodModel from '../shared/shared-methods';
import * as programcreationModel from '../program-creation/program-creation-classes';
import {NgxCaptchaModule,ReCaptcha2Component} from 'ngx-captcha';
import { OnlineMentorshipCreationComponent } from '../online-mentorship-creation/online-mentorship-creation.component';
var marqueeInit

@Component({
	selector: 'navigation-template',
	templateUrl: './template-navigation.component.html'
})

export class TemplateNavigationComponent implements OnInit {
	public userMenuExtended = false;
	public signin: FormGroup;
	public signUp:FormGroup;
	public forgotpassword: FormGroup;
	public faqform: FormGroup;
	passwordSignup:string;
	selectedCountry:string;
	selectedCountryId:any;
	countryList:any;
	errorMessage: any;
	userDetails: any;
	searchtext:string;
	generalFAQ:boolean=false;
	userDetailsRequest:any;
	username: any;
	loggedInUserName: string;
	currPopup = 'login';
	userName: string;
	loggedInUserRole: string;
	appUrl: string;
	forgetPasswordRequest: any;
	isLoading: boolean;
	IsUserLogin: boolean = false;
	IsHeaderCover: boolean = false;
	FreAskQuestion: any;
	indvQuestion:any;
	faqFlagData:any;
	otherQuestions:any;
	category: string = null;
	programid: null;
	searchField: string = null;
	selectedfilterCountry:string;
	showModal:boolean=false;
	userDetailsdata:any;
	registrationData:any;
	AccountEmployerNameData: AppModel.DDLData[];
	SelectedAccountEmployerData: AppModel.DDLData[];
	meshtermlistdata: programcreationModel.meshtermModel[] = [];
	ParentName: any;
	selectedQA:any;
	loginFailureMessage:string="";
	RegistrationErrorMessage:string="";
	forgotResponse:any;
	selectedProgramId:any;
	submitted = false;
	CaptchaValidate: boolean = false;
	currentModal='registration';
	//CaptchaKey = '6LeYuSUUAAAAAG9w8ooauQTTGB0sr9jZF5jibmsA';
	Captchakey='6LcQA6oUAAAAAI0-ZADrt1G6MWZT46fcuIOps6yx';
	// api key = 'AIzaSyAX9Kwze82SdGhPboAeycClIxxnpK6E4JU'
	// client key = '869508667029-ad10sg468khiv3gkbf9bm3qjdvf6f02f.apps.googleusercontent.com'
	// client secret = 'pPe1l9wTE_eWBZ5Bt1nZScCG'
	
  captchaSuccess = false;
  regCaptchaSuccess=false;
  @ViewChild('captchaElem') captchaElem: ReCaptcha2Component;
  @ViewChild('captchaRegElem') captchaRegElem: ReCaptcha2Component;
	constructor(private router: Router,
		private fb: FormBuilder,
		
		private route: ActivatedRoute,
		private url: LocationStrategy,
		private loginService: LoginService,
		private traineeshipService: TraineeshipService,

	) {
		setInterval(() => {

		}, 32000);

	}


	public ngOnInit(): void {
		this.SelectedAccountEmployerData = [];
		this.getLocations();
		this.router.events.subscribe(val => {
			

            if (val instanceof RoutesRecognized) {
				

                this.selectedProgramId=val.state.root.firstChild.params['id'];

            }
        });
		//this.getFAQs(null);
		this.getOnlyGeneralFAQs(null);
		// if (localStorage.getItem("email")) {
		// 	this.loggedInUserName = localStorage.getItem("email");
		// 	if (this.loggedInUserName && this.loggedInUserName != null) {
		// 		this.IsUserLogin = true;
		// 	}
		// 	else
		// 		this.IsUserLogin = false;
		// }
		this.fetchSeesionFromLocal();
		this.appUrl = CommonService.APP_URL;
		//alert(this.appUrl);
		this.signin = this.fb.group({
			email: ['', Validators.required],
			password: ['', Validators.required],
			recaptcha:[]

		});
		this.signUp = this.fb.group({
			emailidSignUp: ['', [Validators.required, Validators.email,Validators.pattern('[a-zA-Z0-9.-]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,4}')]],
			pwdSignUp: ['', Validators.required],
			repwdSignUp:[],
			nameSignUp:[],
			organizationSignUp:[],
			titleSignUp:[],
			mobileSignUp:[],
			country:[]	

		});
		this.forgotpassword = this.fb.group({
			ForgotPwdEmail: ['', Validators.required]
		})
		this.faqform = this.fb.group({
			searchField: ['']

		});
		localStorage.setItem("traineeshipTypeonline", "")
		localStorage.setItem("traineeshipTypeOnsite", "")
		localStorage.setItem("traineeshipTypeOnlineMentor", "")
	
	}
	
	get f() {
		
		 return this.signUp.controls; }

	@HostListener('document:click', ['$event'])
	private onClick(event) {
		if (event.target.getAttribute('data-button') !== 'toggle-user-menu') {
			this.userMenuExtended = false;
		}
	}

	@HostListener('window:scroll', ['$event'])
	scrollHandler(event) {

		let header = document.getElementById("myHeader");
		let sticky = header.offsetTop;
		if (window.pageYOffset > sticky) {

			$('#myHeader').addClass('sticky');
		}
		else {
			$('#myHeader').removeClass("sticky");
		}
	}



	public ngAfterViewInit(): void {
	
		// this.loggedInUserName = localStorage.getItem("email");

		// this.loggedInUserRole = localStorage.getItem("role");
		// this.userName = localStorage.getItem("firstname")
		//alert(this.userName);
		this.fetchSeesionFromLocal();
		$("#Result").click(function (e) {

			$("#SearchResult").slideDown(200);
			$("#SearchDetails").slideUp(200);
			e.preventDefault();
		});

		$("#Details").click(function (e) {

			$("#SearchResult").slideUp(200);
			$("#SearchDetails").slideDown(200);
			e.preventDefault();

		});
		$(".dropdown").hover(
			function () {
				$('.dropdown-menu', this).not('.in .dropdown-menu').stop(true, true).slideDown("400");
				$(this).toggleClass('open');
			},
			function () {
				$('.dropdown-menu', this).not('.in .dropdown-menu').stop(true, true).slideUp("400");
				$(this).toggleClass('open');
			}
		);
		$(".menu > ul > li").hover(function (e) {
			if ($(window).width() > 943) {
				$(this).children("ul").stop(true, false).fadeToggle(150);
				e.preventDefault();
			}
		});
		//If width is more than 943px dropdowns are displayed on hover

		$(".menu > ul > li").click(function () {
			if ($(window).width() <= 943) {
				$(this).children("ul").fadeToggle(150);
			}
		});
		//If width is less or equal to 943px dropdowns are displayed on click (thanks Aman Jain from stackoverflow)

		$(".menu-mobile").click(function (e) {
			$(".menu > ul").toggleClass('show-on-mobile');
			e.preventDefault();
		});


		//Start 22nd Mar 2019 scripts
		$("#hide").click(function () {
			$(".faq-div").hide();
			$('#programid').val(""); 
			$('#searchfield').val("");
		});

		//Close on click body
		$("#show").click(function () {
			$(".btn-faq").show();
		});

		$(document).click(function (e) {
			if (!$(e.target).hasClass("btn-faq")
				&& $(e.target).parents(".faq").length === 0) {
				$(".faq").hide();
			}
		});
		// script for Trianeeship
		$('.menu-dark').hover(function () {
			$('#darkness').fadeTo(0, 1);
		}, function () {
			$('#darkness').fadeTo(0, 0, function () {
				$(this).hide();
			});
		});
		// Script for Why not 
		$('.menu-dark').hover(function () {
			$('#darkness').fadeTo(0, 1);
		}, function () {
			$('#darkness').fadeTo(0, 0, function () {
				$(this).hide();
			});
		});

	}


public showGeneralQuestionModel(){
		$(".faq-div").show();
		$('#myModalLabel2').html("<strong>Frequently ask questions</strong>");
		$('#faqflag').val("general");
		$('#programid').val(""); 
		$('#searchfield').val("");
		this.generalFAQ=true;
		this.OnFAQSInput("");		
	};

	public removeDarkness(type) {
		if(type)
			sessionStorage.setItem("selectedTraineeship",type);
		else
		sessionStorage.setItem("selectedTraineeship",'');
		$('#darkness').css("display", "none");
		// $('#darkness').removeClass('.menu-dark')
		//    .addClass('.darkness');
	}
	public removeFade() {
		$('#darkness').removeClass('.modal-backdrop fade in') ;
		// $('#darkness').removeClass('.menu-dark')
		//   
	}
	// keyUpEvent(){


	// 	alert("ENTERED");
	// }
	public login() {
	
		if(!$('#test123').html()){
			this.loginFailureMessage="Please select Captcha";
			return;
		}
		//alert(this.isLoading)
		this.isLoading = true;
		// alert(this.isLoading)
		this.loginFailureMessage="";
		
		let request = new ProgramCreationRequest(
			this.signin.value.email,
			this.signin.value.password
		);
		this.username =

			{
				"username": "" + this.signin.value.email + "",
				// "username":"santosh.d@smartims.com",
				"password": "" + this.signin.value.password + ""
				//"password":"FAmYzqi2wVoXIg67aariZETDn+DQwwBpyPNERw+NHOCVkAc0HsAdNAw4N+FO1gF//ZhhHWLulEM5DOXx7hzjlg=="
			}

		if (this.signin.value.email == "" || this.signin.value.email == undefined) {
			this.isLoading = false;			
			this.loginFailureMessage = "Please Enter your Email to login";
			this.IsHeaderCover = false;
		}
		else if (this.signin.value.password == "" || this.signin.value.password == undefined) {
			this.isLoading = false;
			this.loginFailureMessage = "Please Enter your Password to login";
			this.IsHeaderCover = false;
		}
		// else if(!this.captchaSuccess){
		// 	this.isLoading = false;
		// 	this.loginFailureMessage = "Please check captcha";
		// 	this.IsHeaderCover = false;
		// }
		else {


			this.isLoading = true;
			// this.loginService.validateLoginUser('{"username":"santosh.d@smartims.com","password":"FAmYzqi2wVoXIg67aariZETDn+DQwwBpyPNERw+NHOCVkAc0HsAdNAw4N+FO1gF//ZhhHWLulEM5DOXx7hzjlg=="}').subscribe(
			this.traineeshipService.validateLoginUser('' + JSON.stringify(this.username) + '').subscribe(
				(response) => {
					this.isLoading = false;
					// this.userDetails=response.dataRows;
					this.userDetails = response;

					if (this.userDetails.message == "You have successfully logged in.") {

						localStorage.setItem("email", this.userDetails.email);
						localStorage.setItem("token_Id", this.userDetails.token);
						localStorage.setItem("status", this.userDetails.status);
						localStorage.setItem("fieldOfIntrest", this.userDetails.foi);
						localStorage.setItem("role", this.userDetails.role);
						localStorage.setItem("firstname", this.userDetails.firstname);
						localStorage.setItem("userId", this.userDetails.userid);
						localStorage.setItem("policy_check", this.userDetails.policy_check);
						localStorage.setItem("session_check", "true");
						this.fetchSeesionFromLocal();
						this.IsHeaderCover = false;
						this.loginFailureMessage = "";
						 $("#ModalLogin .close").click()
						
						
						 if(this.router.url.indexOf('/program-creation-data/')>-1){
							location.reload();
						 }
						 else if(this.router.url.indexOf('/program-details-brief')>-1){
						
							this.router.navigate(['/', this.selectedProgramId, 'program-details'])
							// location.reload();
						 }
						 else if(this.userDetails.role=='HOST'){
							 this.router.navigate(['/','program-list'])

						 }
						 else
							this.router.navigate(['/']);
					
						//location.reload();
					}
					else {
						this.isLoading = false;
						this.loginFailureMessage = this.userDetails.message;
						this.signin.value.password="";
						this.IsHeaderCover = false;
					}
				},
				(err) => {
					this.isLoading = false;
					this.IsHeaderCover = false;
					this.errorMessage = err;
					this.loginFailureMessage="Internal Server error, try again.";
					this.signin.value.password="";
				});
		}

	}

	public signOut() {

		localStorage.clear();
		sessionStorage.clear();
		this.loggedInUserName = null;
		this.loggedInUserRole = null;
		this.userName = null;
		location.reload();
		//this.router.navigate(['/']);
		
		// if(this.router.url.indexOf('/application-list')>-1){
			
		
		// 	this.router.navigate(['/']);
		// 	location.reload();
			
		//  }
		
		 		
	}
	public alertClosed(): void {
		// this.successMessage = null;
		this.errorMessage = null;
	}


	public OnFAQSInput(search: string) {
		
		if (search.length >= 3) {
			this.getFAQs(search, true);
			$('#SearchDetails').css('display','none')
		} else if(!search.length || search.length<3) {
			this.getFAQs(search, true);
		}
	}
	public getOnlyGeneralFAQs(search: string) {
		var faqflag = $('#faqflag').val();
		var programid = $('#programid').val();
		if (search == null || (search != null && search.trim() == ''))
			this.category = faqflag
		else {

			this.category = faqflag
		}
		let faqRequest =
		{
			"search_field": search,
			"category":this.category,
			"programid": programid,
			// "username":"santosh.d@smartims.com",
			// "token":"1bmn6xv4udwk40kkkww4ss4gwg8k40g",
			// "login_status":"0"
			"username": "" + localStorage.getItem("email") + "",
			"token": "" + localStorage.getItem("token_Id") + "",
			"login_status": "" + localStorage.getItem("status") + ""
		};

		this.traineeshipService.getFAQs('' + JSON.stringify(faqRequest) + '').subscribe(
			(response) => {

				this.FreAskQuestion = response.general;
				//this.indvQuestion=response.individual
				

			},
			(err) => {
				this.errorMessage = err;

			});

	}

	public searchFAQ(search: string, onLoad: boolean) {
		this.generalFAQ = false;
		this.getFAQs(search, onLoad);
	}


	public getFAQs(search: string, onLoad: boolean) {
		
		var faqflag = $('#faqflag').val();
		var programid = $('#programid').val();
		
		if (!onload) this.searchField = "";

		//alert(faqflag);

		/*
		faqflag = general
			all general questions
		faqflag = individual
			perticular to program id
		faqflag = others
			perticular to all other program questions

		*/
		if (search == null || (search != null && search.trim() == ''))
			this.category = faqflag
		else {

			this.category = faqflag
		}
		let faqRequest =
		{
			"search_field": search,
			"category":this.category,
			"programid": programid,
			// "username":"santosh.d@smartims.com",
			// "token":"1bmn6xv4udwk40kkkww4ss4gwg8k40g",
			// "login_status":"0"
			"username": "" + localStorage.getItem("email") + "",
			"token": "" + localStorage.getItem("token_Id") + "",
			"login_status": "" + localStorage.getItem("status") + ""
		};

		this.traineeshipService.getFAQs('' + JSON.stringify(faqRequest) + '').subscribe(
			(response) => {
				
				if(onLoad)
				this.FreAskQuestion = response.general;
				else 
				this.FreAskQuestion = [];

				// alert(search);
				// alert(this.category);
				if(search!=null || (search != null && search.trim() == '') ||this.category!=""){
					
				this.indvQuestion=response.individual;
				}
				
				 this.otherQuestions=response.others;

				 if(onLoad && !this.generalFAQ){
					this.FreAskQuestion = response.individual;
					this.indvQuestion=response.general;
				}

			},
			(err) => {
				this.errorMessage = err;

			});

	}


	fetchSeesionFromLocal() {
		this.loggedInUserRole = localStorage.getItem("role")
		this.loggedInUserName = localStorage.getItem("email");
		this.userName = localStorage.getItem("firstname");
		if (this.loggedInUserName && this.loggedInUserName != null) {
			this.IsUserLogin = true;
		}
		else
			this.IsUserLogin = false;
		//	alert(localStorage.getItem("role"));
	}

	handleReset(){
		
		return true;
	}

	testnow():void{
		
		this.currPopup='register';
	}

	OnSignIn(): void {
		
		this.currPopup='login';
		this.IsHeaderCover = false;
		this.loginFailureMessage="";
		this.forgotResponse="";
		this.signin.reset();
		// this.captchaElem.resetCaptcha();
		this.captchaSuccess = false 
	}
	OnClose(): void {
		this.signin.value.password="";
		this.IsHeaderCover = false;
		this.signin.reset();
	}
	ResetPwdFields():void{
		this.forgotResponse="";
		this.forgotpassword.value.ForgotPwdEmail.Reset();
	}
	forgetpassword(): void {
		this.forgotResponse="";
		this.isLoading = true;
		this.forgetPasswordRequest =
			{
				"username": this.forgotpassword.value.ForgotPwdEmail
			}

		this.traineeshipService.forgetPassword('' + JSON.stringify(this.forgetPasswordRequest) + '').subscribe(
			(response) => {
				
				 this.forgotResponse=response.message;
				this.isLoading = false;
				
				this.IsHeaderCover = false;

			},
			(err) => {
				this.forgotResponse="Please enter valid emailId.";
				this.isLoading = false;
				this.errorMessage = err;
				this.IsHeaderCover = false;
			});
	}

	OnQAExpand(item){
		$('#SearchDetails').css('display','block')
		this.showModal=true;
		this.selectedQA=item;
	}
	OnBack(){
		
		this.showModal=false;
		this.selectedQA=null;
	}

	
	handleSuccess(event: any) {
	  this.captchaSuccess = true;
	}

	handleExpire(): void {
    this.captchaSuccess = false;
  }
  handleRegSuccess(event: any) {
	this.regCaptchaSuccess = true;
  }

  handleRegExpire(): void {
  this.regCaptchaSuccess = false;
}


	onChange(selectedValue) {
		this.selectedCountry = selectedValue;
	
	  }
	  getLocations() {
		this.userDetailsRequest =
		{
		  "username": "" + localStorage.getItem("email") + "",
		  "token": "" + localStorage.getItem("token_Id") + "",
		  "login_status": "" + localStorage.getItem("status") + "",
  
		}

		this.isLoading = true;
		//this.traineeshipService.getLocations('{"username":"santosh.d@smartims.com"}').subscribe(
		this.traineeshipService.getLocations('' + JSON.stringify(this.userDetailsRequest) + '').subscribe(
		  (response) => {
			this.isLoading = false;
			this.countryList = response.dataRows;
	
		  },
		  (err) => {
			// this.errorMessage = err;
			this.isLoading = false;
			this.errorMessage = "Session has been expired, please sigout and Relogin";
	
		  });
	
	  }
	  OnAccountFilter(event: any): void {
		this.searchtext = event

		if (event) {
		  this.getUserJsonData(event);
		  this.traineeshipService.getSearchFieldOfIntrestBySearchTerm('' + JSON.stringify(this.userDetailsdata) + '').subscribe(
			(response) => {
	
			  this.AccountEmployerNameData = AppMethodModel.AppMethods.ToDDLDataItemsFromAccountQuickResults(response.dataRows);;
			});
		}
	  }
	
	
	
	
	
	  PopulateBranchNameData(items: any): void {
		if (items && items.length > 0) {
	
		  this.AccountEmployerNameData = AppMethodModel.AppMethods.ToDDLDataItemsFromAccountQuickResults(items);
		} 
		else {
	
		  this.AccountEmployerNameData = null;
		}
	  }
	  OnAccountEmployernameSelection(args: AppModel.DDLData[]): void {

		if (args && args.length > 0) {
	
		  this.SelectedAccountEmployerData = args;
	
		}
		else {
	
		}
	  }
	  signUpform(){
		

		this.currentModal='registration';
		this.captchaRegElem.resetCaptcha();
		this.regCaptchaSuccess = false 
	  }
	  SubmitsignUp(){
		this.RegistrationErrorMessage="";
		if(!$('#registerCaptcha').html()){
			this.RegistrationErrorMessage="Please select Captcha";
			return;
		}
	
		this.submitted = true;
		this.isLoading = true;
		  // alert(this.selectedCountry)
		  // alert("dcda"+this.selectedCountryId)
		this.selectedfilterCountry = $("#ddlCountry option:selected").text();
		var selectedFieldOfInterestnew = null;
		
		if (this.meshtermlistdata == null)
		  this.meshtermlistdata == [];
		if (this.SelectedAccountEmployerData && this.SelectedAccountEmployerData.length > 0) {
		  this.SelectedAccountEmployerData.forEach(element => {
			if (!this.CheckInterestexist(element.Text)) {
			  var meshtermdata: programcreationModel.meshtermModel = new programcreationModel.meshtermModel();
			  meshtermdata.meshterm_id = element.Id;
			  meshtermdata.name = element.Text;
			  this.meshtermlistdata.push(meshtermdata);
			}
			var foiRegister=this.SelectedAccountEmployerData.map(sar=> "'"+sar.Text+"'" );
			foiRegister.join(',');
			if (selectedFieldOfInterestnew == null)
			  selectedFieldOfInterestnew = element.Text;
			else
			  selectedFieldOfInterestnew = selectedFieldOfInterestnew + ',' + element.Text;
	
		  });
	
		}
		
		//  if(!this.captchaSuccess){
		// 	this.isLoading = false;
		// 	this.RegistrationErrorMessage = "Please check captcha";
		// 	this.IsHeaderCover = false;
		// 	return
		// }
		if(this.signUp.value.emailidSignUp==""||this.signUp.value.emailidSignUp==undefined){
			this.IsHeaderCover = false;
			this.isLoading = false;
			this.RegistrationErrorMessage = "Please enter Email Id. ";
			return;
		}
		if(this.signUp.value.nameSignUp==""||this.signUp.value.nameSignUp==undefined){
			this.IsHeaderCover = false;
			this.isLoading = false;
			this.RegistrationErrorMessage = "Please enter name . ";
			return;
		}
		if(selectedFieldOfInterestnew==""||selectedFieldOfInterestnew==undefined){
			this.IsHeaderCover = false;
			this.isLoading = false;
			this.RegistrationErrorMessage = "Please enter field of intrest . ";
			return;
		}
		if(this.selectedCountry==""||this.selectedCountry==undefined){
			this.IsHeaderCover = false;
			this.isLoading = false;
			this.RegistrationErrorMessage = "Please select country . ";
			return;
		}
		if(this.signUp.value.pwdSignUp==""||this.signUp.value.pwdSignUp==undefined){
			this.IsHeaderCover = false;
			this.isLoading = false;
			this.RegistrationErrorMessage = "Please enter password . ";
			return;
		}
		if(this.signUp.value.repwdSignUp==""||this.signUp.value.repwdSignUp==undefined){
			this.IsHeaderCover = false;
			this.isLoading = false;
			this.RegistrationErrorMessage = "Please enter re-enter password . ";
			return;
		}

		if(this.signUp.value.pwdSignUp && this.signUp.value.pwdSignUp==this.signUp.value.repwdSignUp){
			this.passwordSignup=this.signUp.value.pwdSignUp
		}
		else{
			this.IsHeaderCover = false;
			this.isLoading = false;
			this.RegistrationErrorMessage = "Password mismatch, Please re-enter. ";
			return;
		}
	  this.registrationData =
	  {
		
		"mesh_term_list": selectedFieldOfInterestnew,
		"email":this.signUp.value.emailidSignUp,
		"password":this.passwordSignup,
		"name":this.signUp.value.nameSignUp,
		"cell_phone":this.signUp.value.mobileSignUp,
		"company":this.signUp.value.organizationSignUp,
		"title":this.signUp.value.titleSignUp,
		 "country_id":this.selectedCountry
		

		
	  }

	  if (this.signUp.invalid) {
		return;
	}



	 
	  this.traineeshipService.registration('' + JSON.stringify(this.registrationData) + '').subscribe(
		(response) => {
			this.removeFade();
			this.IsHeaderCover = false;
			this.isLoading=false;
			alert(response.message);
			$("#ModalSignup .close").click();
			$("#ModalSignup").click();
		},
		(err) => {
		
			this.isLoading=false;
			this.removeFade();
			this.errorMessage = err;
			this.IsHeaderCover = false;

		});



	  }
	  
  filter_list_save(): void {
	this.isLoading=true;
	
    if (this.searchtext != null && this.searchtext != "") {
	  this.getUserJsonData(event);
	  this.userDetails =
      {
        "username": "" + localStorage.getItem("email") + "",
        "token": "" + localStorage.getItem("token_Id") + "",
        "login_status": "" + localStorage.getItem("status") + "",
        "search_field": "" + this.searchtext + "",
      }
      this.traineeshipService.filter_list_save('' + JSON.stringify(this.userDetails) + '').subscribe(
        (response) => {
		  this.isLoading=false;
		 

		  this.AccountEmployerNameData = AppMethodModel.AppMethods.ToDDLDataItemsFromAccountQuickResults(response.dataRows);;
		  alert("sucessfully saved your interest. please search again to get")
          // this.SelectedAccountEmployerData = AppMethodModel.AppMethods.ToDDLDataItemsFromAccountQuickResults(response.dataRows);;

        });
    }
  }
	  CheckInterestexist(Name: string): boolean {
		var isexist = false;
	
		if (this.meshtermlistdata != null && this.meshtermlistdata.length > 0) {
		  this.meshtermlistdata.forEach(element => {
			if (element.name == Name) {
			  element.flag=false;
			  isexist = true;
			}
		  });
		}
		return isexist;
	  }
	  getUserJsonData(searchtext: any): any {
		this.userDetailsdata =
		  {
			"username": "" + localStorage.getItem("email") + "",
			"token": "" + localStorage.getItem("token_Id") + "",
			"login_status": "" + localStorage.getItem("status") + "",
			"search_field": "" + this.searchtext + "",
		  }
		return this.userDetails;
	  }

}
