import { Component, OnInit,HostListener,ChangeDetectorRef ,ElementRef, ViewChild,Renderer2 } from '@angular/core';
import { CommonService} from '../services/common.service';
@Component({
  selector: 'app-terms-and-services',
  templateUrl: './terms-and-services.component.html',
  styleUrls: ['./terms-and-services.component.css']
})
export class TermsAndServicesComponent implements OnInit {
  appUrl:string;
  constructor() { }

  ngOnInit() {
    this.appUrl= CommonService.APP_URL;
  }
  moveScroll(el: HTMLElement){
    var top = el.offsetTop;
    //el.scrollTop = 400;
    //el.scroll(0, 200);
    // el.scroll({
    //   top: top,
    //   behavior: 'smooth'
    // });
   el.scrollIntoView();
  }

}
