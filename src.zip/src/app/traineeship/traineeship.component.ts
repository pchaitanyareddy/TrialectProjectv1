import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { TemplateNavigationComponent} from '../template/template-navigation.component';
import { TraineeshipService} from '../services/traineeship.service'
import { CommonService} from '../services/common.service';
import * as programcreationModel from '../program-creation/program-creation-classes';
@Component({
  selector: 'app-traineeship',
  templateUrl: './traineeship.component.html',
  styleUrls: ['./traineeship.component.css'],
//  providers:[CommonService]
})

export class TraineeshipComponent implements OnInit {
  ProgramTypeListData: programcreationModel.ProgramType[];
  appUrl:string;
  constructor(private router: Router, private traineeshipService:TraineeshipService,commonservice:CommonService) {
    this.ProgramTypeListData=commonservice.ProgramTypeListData;
   }
  allmedicationTypeList:any;

  errorMessage:any;
  ngOnInit() {
    window.scrollTo(0,0);
    this.appUrl= CommonService.APP_URL;
  }
  
  onlineTraineeship(){
    localStorage.setItem("onlineTraineeshipType","onlineTraineeship");
    // localStorage.setItem("onsiteTraineeshipType","");
    // localStorage.setItem("onlineMentorTraineeshipType","");
    this.router.navigate(['/','program-creation','onlineTraineeship'])
  }
  onsiteTraineeship(){
    localStorage.setItem("onsiteTraineeshipType","onsiteTraineeship");
    // localStorage.setItem("onlineTraineeshipType","");
    // localStorage.setItem("onlineMentorTraineeshipType","");
    this.router.navigate(['/','program-creation','onsiteTraineeship'])
  }
  onlineMentorTraineeship(){
    localStorage.setItem("onlineMentorTraineeshipType","onlineMentorTraineeship");
    // localStorage.setItem("onlineTraineeshipType","");
    // localStorage.setItem("onsiteTraineeshipType","");
    this.router.navigate(['/','program-creation','onlineMentorTraineeship'])
  }

OnProgramcreation(PrograType:any):void{
  
 // this.router.navigate(['/','program-creation-data'], navigationExtras);
     this.router.navigate(['/','program-creation-data',-1,PrograType])
     //this.router.navigate(['program-creation-data'])
  }
  onGrantsCreation(PrograType:any){
    
    this.router.navigate(['/','program-grants-creation',-1,PrograType])
  }
}
