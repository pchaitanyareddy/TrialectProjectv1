import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TraineeshipsComponent } from './traineeships.component';

describe('TraineeshipsComponent', () => {
  let component: TraineeshipsComponent;
  let fixture: ComponentFixture<TraineeshipsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TraineeshipsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TraineeshipsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
