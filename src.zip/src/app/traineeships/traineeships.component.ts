import { Component, OnInit } from '@angular/core';
import { CommonService} from '../services/common.service';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-traineeships',
  templateUrl: './traineeships.component.html',
  styleUrls: ['./traineeships.component.css']
})
export class TraineeshipsComponent implements OnInit {
  appUrl:string; 
  constructor(private router: Router) { }

  ngOnInit() {
    this.appUrl= CommonService.APP_URL;
  }
  exploreOnlineTraineeship(){
    sessionStorage.setItem('programListIsDefault','exploreTraineship');
    localStorage.setItem("traineeshipTypeonline","onlineTraineeshipDetailpage")
    this.router.navigate(['/', 'program-list']);
  }
  exploreMentorships(){
    localStorage.setItem("traineeshipTypeOnlineMentor","onlinementorshipDetailpage")
    sessionStorage.setItem('programListIsDefault','exploreTraineship');
    this.router.navigate(['/', 'program-list']);
  }
exploreOnsiteTraineeship(){
  sessionStorage.setItem('programListIsDefault','exploreTraineship');
  localStorage.setItem("traineeshipTypeOnsite","onsiteTraineeshipDetailpage")
  this.router.navigate(['/', 'program-list']);
}
}
