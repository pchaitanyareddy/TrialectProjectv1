import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WhyToApplyTraineeshipComponent } from './why-to-apply-traineeship.component';

describe('WhyToApplyTraineeshipComponent', () => {
  let component: WhyToApplyTraineeshipComponent;
  let fixture: ComponentFixture<WhyToApplyTraineeshipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WhyToApplyTraineeshipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WhyToApplyTraineeshipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
