import { Component, OnInit } from '@angular/core';
import { CommonService} from '../services/common.service';
@Component({
  selector: 'app-why-to-apply-traineeship',
  templateUrl: './why-to-apply-traineeship.component.html',
  styleUrls: ['./why-to-apply-traineeship.component.css']
})
export class WhyToApplyTraineeshipComponent implements OnInit {
  appUrl:string;
  constructor() { }

  ngOnInit() {
    this.appUrl= CommonService.APP_URL;
  }

}
