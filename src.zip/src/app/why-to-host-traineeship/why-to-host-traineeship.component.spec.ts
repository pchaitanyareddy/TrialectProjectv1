import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WhyToHostTraineeshipComponent } from './why-to-host-traineeship.component';

describe('WhyToHostTraineeshipComponent', () => {
  let component: WhyToHostTraineeshipComponent;
  let fixture: ComponentFixture<WhyToHostTraineeshipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WhyToHostTraineeshipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WhyToHostTraineeshipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
