import { Component, OnInit } from '@angular/core';
import { CommonService} from '../services/common.service';
@Component({
  selector: 'app-why-to-host-traineeship',
  templateUrl: './why-to-host-traineeship.component.html',
  styleUrls: ['./why-to-host-traineeship.component.css']
})
export class WhyToHostTraineeshipComponent implements OnInit {
  appUrl:string;
  constructor() { }
  
  ngOnInit() {
    this.appUrl= CommonService.APP_URL;
  }

}
