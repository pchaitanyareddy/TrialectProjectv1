import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-write-review',
  templateUrl: './write-review.component.html',
  styleUrls: ['./write-review.component.css']
})
export class WriteReviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
